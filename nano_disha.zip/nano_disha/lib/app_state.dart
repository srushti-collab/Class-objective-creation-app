import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  List<String> _fileNames = [];
  List<String> get fileNames => _fileNames;
  set fileNames(List<String> value) {
    _fileNames = value;
  }

  void addToFileNames(String value) {
    fileNames.add(value);
  }

  void removeFromFileNames(String value) {
    fileNames.remove(value);
  }

  void removeAtIndexFromFileNames(int index) {
    fileNames.removeAt(index);
  }

  void updateFileNamesAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    fileNames[index] = updateFn(_fileNames[index]);
  }

  void insertAtIndexInFileNames(int index, String value) {
    fileNames.insert(index, value);
  }
}
