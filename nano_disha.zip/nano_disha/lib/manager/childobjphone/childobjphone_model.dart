import '';
import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/manager/add_child_obj/add_child_obj_widget.dart';
import '/manager/edit_o_b_j/edit_o_b_j_widget.dart';
import '/manager/notesog/notesog_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'childobjphone_widget.dart' show ChildobjphoneWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ChildobjphoneModel extends FlutterFlowModel<ChildobjphoneWidget> {
  ///  Local state fields for this page.

  int total = 0;

  ///  State fields for stateful widgets in this page.

  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    tabBarController?.dispose();
  }
}
