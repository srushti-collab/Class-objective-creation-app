import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:text_search/text_search.dart';
import 'managerobjphone2_model.dart';
export 'managerobjphone2_model.dart';

class Managerobjphone2Widget extends StatefulWidget {
  const Managerobjphone2Widget({super.key});

  static String routeName = 'Managerobjphone2';
  static String routePath = '/managerobjphone2';

  @override
  State<Managerobjphone2Widget> createState() => _Managerobjphone2WidgetState();
}

class _Managerobjphone2WidgetState extends State<Managerobjphone2Widget>
    with TickerProviderStateMixin {
  late Managerobjphone2Model _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Managerobjphone2Model());

    _model.tabBarController = TabController(
      vsync: this,
      length: 2,
      initialIndex: 0,
    )..addListener(() => safeSetState(() {}));
    _model.textController1 ??= TextEditingController();
    _model.textFieldFocusNode1 ??= FocusNode();

    _model.textController2 ??= TextEditingController();
    _model.textFieldFocusNode2 ??= FocusNode();

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: Color(0xFF1A237E),
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Visibility(
            visible: responsiveVisibility(
              context: context,
              tabletLandscape: false,
              desktop: false,
            ),
            child: Text(
              FFLocalizations.of(context).getText(
                '43u9b4e5' /* Objectives */,
              ),
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Urbanist',
                    color: Colors.white,
                    fontSize: 20.0,
                    letterSpacing: 0.0,
                    fontWeight: FontWeight.normal,
                  ),
            ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: Column(
            children: [
              Align(
                alignment: Alignment(0.0, 0),
                child: TabBar(
                  labelColor: FlutterFlowTheme.of(context).primaryText,
                  unselectedLabelColor:
                      FlutterFlowTheme.of(context).secondaryText,
                  labelStyle: FlutterFlowTheme.of(context).titleMedium.override(
                        fontFamily: 'Manrope',
                        fontSize: 14.0,
                        letterSpacing: 0.0,
                      ),
                  unselectedLabelStyle:
                      FlutterFlowTheme.of(context).titleMedium.override(
                            fontFamily: 'Manrope',
                            fontSize: 12.0,
                            letterSpacing: 0.0,
                          ),
                  indicatorColor: FlutterFlowTheme.of(context).primary,
                  tabs: [
                    Tab(
                      text: FFLocalizations.of(context).getText(
                        'pikmyj34' /* Private Objectives */,
                      ),
                    ),
                    Tab(
                      text: FFLocalizations.of(context).getText(
                        'y4t972cc' /* Public Objectives */,
                      ),
                    ),
                  ],
                  controller: _model.tabBarController,
                  onTap: (i) async {
                    [() async {}, () async {}][i]();
                  },
                ),
              ),
              Expanded(
                child: TabBarView(
                  controller: _model.tabBarController,
                  children: [
                    SingleChildScrollView(
                      primary: false,
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 5.0, 0.0, 0.0),
                            child: Material(
                              color: Colors.transparent,
                              elevation: 2.0,
                              child: Container(
                                width: MediaQuery.sizeOf(context).width * 1.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                ),
                                child: Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      24.0, 0.0, 24.0, 0.0),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        width:
                                            MediaQuery.sizeOf(context).width *
                                                1.07,
                                        height: 45.21,
                                        decoration: BoxDecoration(
                                          color: FlutterFlowTheme.of(context)
                                              .secondaryBackground,
                                          borderRadius:
                                              BorderRadius.circular(25.0),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            Expanded(
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        10.0, 0.0, 0.0, 5.0),
                                                child: TextFormField(
                                                  controller:
                                                      _model.textController1,
                                                  focusNode: _model
                                                      .textFieldFocusNode1,
                                                  onFieldSubmitted: (_) async {
                                                    await queryProjectsRecordOnce()
                                                        .then(
                                                          (records) => _model
                                                                  .simpleSearchResults1 =
                                                              TextSearch(
                                                            records
                                                                .map(
                                                                  (record) => TextSearchItem
                                                                      .fromTerms(
                                                                          record,
                                                                          [
                                                                        record
                                                                            .title!,
                                                                        record
                                                                            .ownerName!,
                                                                        record
                                                                            .description!
                                                                      ]),
                                                                )
                                                                .toList(),
                                                          )
                                                                  .search(_model
                                                                      .textController1
                                                                      .text)
                                                                  .map((r) =>
                                                                      r.object)
                                                                  .toList(),
                                                        )
                                                        .onError((_, __) =>
                                                            _model.simpleSearchResults1 =
                                                                [])
                                                        .whenComplete(() =>
                                                            safeSetState(
                                                                () {}));
                                                  },
                                                  autofocus: false,
                                                  obscureText: false,
                                                  decoration: InputDecoration(
                                                    hintText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getText(
                                                      '349wfk5p' /* Search objectives... */,
                                                    ),
                                                    hintStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Manrope',
                                                          letterSpacing: 0.0,
                                                        ),
                                                    enabledBorder:
                                                        InputBorder.none,
                                                    focusedBorder:
                                                        InputBorder.none,
                                                    errorBorder:
                                                        InputBorder.none,
                                                    focusedErrorBorder:
                                                        InputBorder.none,
                                                    suffixIcon: Icon(
                                                      Icons.search_sharp,
                                                      color:
                                                          FlutterFlowTheme.of(
                                                                  context)
                                                              .secondaryText,
                                                      size: 20.0,
                                                    ),
                                                  ),
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Manrope',
                                                        letterSpacing: 0.0,
                                                      ),
                                                  minLines: 1,
                                                  validator: _model
                                                      .textController1Validator
                                                      .asValidator(context),
                                                ),
                                              ),
                                            ),
                                            if (_model.textController1.text !=
                                                    null &&
                                                _model.textController1.text !=
                                                    '')
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 0.0, 20.0, 0.0),
                                                child: InkWell(
                                                  splashColor:
                                                      Colors.transparent,
                                                  focusColor:
                                                      Colors.transparent,
                                                  hoverColor:
                                                      Colors.transparent,
                                                  highlightColor:
                                                      Colors.transparent,
                                                  onTap: () async {
                                                    safeSetState(() {
                                                      _model.textController1
                                                          ?.clear();
                                                    });
                                                  },
                                                  child: Icon(
                                                    Icons.clear_rounded,
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .error,
                                                    size: 25.0,
                                                  ),
                                                ),
                                              ),
                                          ].divide(SizedBox(width: 12.0)),
                                        ),
                                      ),
                                    ].divide(SizedBox(height: 16.0)),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                10.0, 0.0, 10.0, 0.0),
                            child: SingleChildScrollView(
                              primary: false,
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  if ((_model.textController1.text == null ||
                                          _model.textController1.text == '') &&
                                      responsiveVisibility(
                                        context: context,
                                        phone: false,
                                        tablet: false,
                                      ))
                                    StreamBuilder<List<ProjectsRecord>>(
                                      stream: queryProjectsRecord(
                                        queryBuilder: (projectsRecord) =>
                                            projectsRecord
                                                .where(Filter.or(
                                                  Filter(
                                                    'owner',
                                                    isEqualTo:
                                                        currentUserReference,
                                                  ),
                                                  Filter(
                                                    'project_creator',
                                                    isEqualTo:
                                                        currentUserReference,
                                                  ),
                                                ))
                                                .orderBy('start_date'),
                                      ),
                                      builder: (context, snapshot) {
                                        // Customize what your widget looks like when it's loading.
                                        if (!snapshot.hasData) {
                                          return Center(
                                            child: SizedBox(
                                              width: 50.0,
                                              height: 50.0,
                                              child: CircularProgressIndicator(
                                                valueColor:
                                                    AlwaysStoppedAnimation<
                                                        Color>(
                                                  Color(0xFF7364FC),
                                                ),
                                              ),
                                            ),
                                          );
                                        }
                                        List<ProjectsRecord>
                                            listViewProjectsRecordList =
                                            snapshot.data!;

                                        return ListView.builder(
                                          padding: EdgeInsets.zero,
                                          shrinkWrap: true,
                                          scrollDirection: Axis.vertical,
                                          itemCount:
                                              listViewProjectsRecordList.length,
                                          itemBuilder:
                                              (context, listViewIndex) {
                                            final listViewProjectsRecord =
                                                listViewProjectsRecordList[
                                                    listViewIndex];
                                            return Visibility(
                                              visible: ((listViewProjectsRecord
                                                              .owner?.id ==
                                                          currentUserReference
                                                              ?.id) &&
                                                      (listViewProjectsRecord
                                                              .type ==
                                                          'Private')) ||
                                                  ((listViewProjectsRecord
                                                              .projectCreator?.id ==
                                                          currentUserReference
                                                              ?.id) &&
                                                      (listViewProjectsRecord
                                                              .underOrg ==
                                                          true) &&
                                                      (listViewProjectsRecord
                                                              .type !=
                                                          'Public')),
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 0.0, 0.0, 10.0),
                                                child: Material(
                                                  color: Colors.transparent,
                                                  elevation: 2.0,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16.0),
                                                  ),
                                                  child: Container(
                                                    width: MediaQuery.sizeOf(
                                                                context)
                                                            .width *
                                                        1.0,
                                                    decoration: BoxDecoration(
                                                      color: FlutterFlowTheme
                                                              .of(context)
                                                          .secondaryBackground,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              16.0),
                                                    ),
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  20.0,
                                                                  10.0,
                                                                  20.0,
                                                                  10.0),
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        12.0,
                                                                        0.0,
                                                                        12.0,
                                                                        0.0),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              children: [
                                                                Text(
                                                                  listViewProjectsRecord
                                                                      .title,
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleLarge
                                                                      .override(
                                                                        fontFamily:
                                                                            'Manrope',
                                                                        color: Color(
                                                                            0xFF1A237E),
                                                                        fontSize:
                                                                            20.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        12.0,
                                                                        0.0,
                                                                        12.0,
                                                                        0.0),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              children: [
                                                                Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      'Start Date: ${dateTimeFormat(
                                                                        "yMMMd",
                                                                        listViewProjectsRecord
                                                                            .startDate,
                                                                        locale:
                                                                            FFLocalizations.of(context).languageCode,
                                                                      )}',
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .override(
                                                                            fontFamily:
                                                                                'Manrope',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).secondaryText,
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                    ),
                                                                    Text(
                                                                      'End Date: ${dateTimeFormat(
                                                                        "yMMMd",
                                                                        listViewProjectsRecord
                                                                            .dueDate,
                                                                        locale:
                                                                            FFLocalizations.of(context).languageCode,
                                                                      )}',
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .override(
                                                                            fontFamily:
                                                                                'Manrope',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).secondaryText,
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                StreamBuilder<
                                                                    List<
                                                                        TaskRecord>>(
                                                                  stream:
                                                                      queryTaskRecord(
                                                                    singleRecord:
                                                                        true,
                                                                  ),
                                                                  builder: (context,
                                                                      snapshot) {
                                                                    // Customize what your widget looks like when it's loading.
                                                                    if (!snapshot
                                                                        .hasData) {
                                                                      return Center(
                                                                        child:
                                                                            SizedBox(
                                                                          width:
                                                                              50.0,
                                                                          height:
                                                                              50.0,
                                                                          child:
                                                                              CircularProgressIndicator(
                                                                            valueColor:
                                                                                AlwaysStoppedAnimation<Color>(
                                                                              Color(0xFF7364FC),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }
                                                                    List<TaskRecord>
                                                                        buttonTaskRecordList =
                                                                        snapshot
                                                                            .data!;
                                                                    // Return an empty Container when the item does not exist.
                                                                    if (snapshot
                                                                        .data!
                                                                        .isEmpty) {
                                                                      return Container();
                                                                    }
                                                                    final buttonTaskRecord = buttonTaskRecordList
                                                                            .isNotEmpty
                                                                        ? buttonTaskRecordList
                                                                            .first
                                                                        : null;

                                                                    return FFButtonWidget(
                                                                      onPressed:
                                                                          () async {
                                                                        context
                                                                            .pushNamed(
                                                                          ChilObjWidget
                                                                              .routeName,
                                                                          queryParameters:
                                                                              {
                                                                            'projectRef':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.reference,
                                                                              ParamType.DocumentReference,
                                                                            ),
                                                                            'projTitle':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.title,
                                                                              ParamType.String,
                                                                            ),
                                                                            'projDesc':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.description,
                                                                              ParamType.String,
                                                                            ),
                                                                            'startDate':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.startDate,
                                                                              ParamType.DateTime,
                                                                            ),
                                                                            'endDate':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.dueDate,
                                                                              ParamType.DateTime,
                                                                            ),
                                                                            'progress':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.progress,
                                                                              ParamType.int,
                                                                            ),
                                                                            'projOwn':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.owner,
                                                                              ParamType.DocumentReference,
                                                                            ),
                                                                            'ownername':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.ownerName,
                                                                              ParamType.String,
                                                                            ),
                                                                            'parentOwn':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.parentOwner,
                                                                              ParamType.DocumentReference,
                                                                            ),
                                                                            'orgObj':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.organisational,
                                                                              ParamType.bool,
                                                                            ),
                                                                            'parentList':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.parentOBJS,
                                                                              ParamType.DocumentReference,
                                                                              isList: true,
                                                                            ),
                                                                            'parentIds':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.parentIDS,
                                                                              ParamType.String,
                                                                              isList: true,
                                                                            ),
                                                                            'type':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.type,
                                                                              ParamType.String,
                                                                            ),
                                                                            'weighatage':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.weightage,
                                                                              ParamType.int,
                                                                            ),
                                                                          }.withoutNulls,
                                                                        );
                                                                      },
                                                                      text: FFLocalizations.of(
                                                                              context)
                                                                          .getText(
                                                                        'npr57f2e' /* View Details */,
                                                                      ),
                                                                      options:
                                                                          FFButtonOptions(
                                                                        width:
                                                                            120.0,
                                                                        height:
                                                                            36.0,
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                        iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                        color: Color(
                                                                            0xFF1A237E),
                                                                        textStyle: FlutterFlowTheme.of(context)
                                                                            .bodyMedium
                                                                            .override(
                                                                              fontFamily: 'Manrope',
                                                                              color: FlutterFlowTheme.of(context).info,
                                                                              letterSpacing: 0.0,
                                                                            ),
                                                                        elevation:
                                                                            0.0,
                                                                        borderRadius:
                                                                            BorderRadius.circular(18.0),
                                                                      ),
                                                                    );
                                                                  },
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ].divide(SizedBox(
                                                            height: 16.0)),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        );
                                      },
                                    ),
                                  if ((_model.textController1.text == null ||
                                          _model.textController1.text == '') &&
                                      responsiveVisibility(
                                        context: context,
                                        tabletLandscape: false,
                                        desktop: false,
                                      ))
                                    StreamBuilder<List<ProjectsRecord>>(
                                      stream: queryProjectsRecord(
                                        queryBuilder: (projectsRecord) =>
                                            projectsRecord
                                                .where(Filter.or(
                                                  Filter(
                                                    'owner',
                                                    isEqualTo:
                                                        currentUserReference,
                                                  ),
                                                  Filter(
                                                    'project_creator',
                                                    isEqualTo:
                                                        currentUserReference,
                                                  ),
                                                ))
                                                .orderBy('start_date',
                                                    descending: true),
                                      ),
                                      builder: (context, snapshot) {
                                        // Customize what your widget looks like when it's loading.
                                        if (!snapshot.hasData) {
                                          return Center(
                                            child: SizedBox(
                                              width: 50.0,
                                              height: 50.0,
                                              child: CircularProgressIndicator(
                                                valueColor:
                                                    AlwaysStoppedAnimation<
                                                        Color>(
                                                  Color(0xFF7364FC),
                                                ),
                                              ),
                                            ),
                                          );
                                        }
                                        List<ProjectsRecord>
                                            listViewProjectsRecordList =
                                            snapshot.data!;

                                        return ListView.builder(
                                          padding: EdgeInsets.zero,
                                          shrinkWrap: true,
                                          scrollDirection: Axis.vertical,
                                          itemCount:
                                              listViewProjectsRecordList.length,
                                          itemBuilder:
                                              (context, listViewIndex) {
                                            final listViewProjectsRecord =
                                                listViewProjectsRecordList[
                                                    listViewIndex];
                                            return Visibility(
                                              visible: ((listViewProjectsRecord
                                                              .owner?.id ==
                                                          currentUserReference
                                                              ?.id) &&
                                                      (listViewProjectsRecord
                                                              .type ==
                                                          'Private')) ||
                                                  ((listViewProjectsRecord
                                                              .projectCreator?.id ==
                                                          currentUserReference
                                                              ?.id) &&
                                                      (listViewProjectsRecord
                                                              .underOrg ==
                                                          true) &&
                                                      (listViewProjectsRecord
                                                              .type !=
                                                          'Public')),
                                              child: Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 0.0, 0.0, 10.0),
                                                child: Material(
                                                  color: Colors.transparent,
                                                  elevation: 2.0,
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16.0),
                                                  ),
                                                  child: Container(
                                                    width: MediaQuery.sizeOf(
                                                                context)
                                                            .width *
                                                        1.0,
                                                    decoration: BoxDecoration(
                                                      color: FlutterFlowTheme
                                                              .of(context)
                                                          .secondaryBackground,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              16.0),
                                                    ),
                                                    child: InkWell(
                                                      splashColor:
                                                          Colors.transparent,
                                                      focusColor:
                                                          Colors.transparent,
                                                      hoverColor:
                                                          Colors.transparent,
                                                      highlightColor:
                                                          Colors.transparent,
                                                      onTap: () async {
                                                        context.pushNamed(
                                                          ChilObjWidget
                                                              .routeName,
                                                          queryParameters: {
                                                            'projectRef':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .reference,
                                                              ParamType
                                                                  .DocumentReference,
                                                            ),
                                                            'projTitle':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .title,
                                                              ParamType.String,
                                                            ),
                                                            'projDesc':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .description,
                                                              ParamType.String,
                                                            ),
                                                            'startDate':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .startDate,
                                                              ParamType
                                                                  .DateTime,
                                                            ),
                                                            'endDate':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .dueDate,
                                                              ParamType
                                                                  .DateTime,
                                                            ),
                                                            'progress':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .progress,
                                                              ParamType.int,
                                                            ),
                                                            'projOwn':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .owner,
                                                              ParamType
                                                                  .DocumentReference,
                                                            ),
                                                            'ownername':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .ownerName,
                                                              ParamType.String,
                                                            ),
                                                            'parentOwn':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .parentOwner,
                                                              ParamType
                                                                  .DocumentReference,
                                                            ),
                                                            'orgObj':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .organisational,
                                                              ParamType.bool,
                                                            ),
                                                            'parentList':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .parentOBJS,
                                                              ParamType
                                                                  .DocumentReference,
                                                              isList: true,
                                                            ),
                                                            'parentIds':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .parentIDS,
                                                              ParamType.String,
                                                              isList: true,
                                                            ),
                                                            'type':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .type,
                                                              ParamType.String,
                                                            ),
                                                            'weighatage':
                                                                serializeParam(
                                                              listViewProjectsRecord
                                                                  .weightage,
                                                              ParamType.int,
                                                            ),
                                                          }.withoutNulls,
                                                        );
                                                      },
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        12.0,
                                                                        10.0,
                                                                        12.0,
                                                                        10.0),
                                                            child: Row(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Text(
                                                                      listViewProjectsRecord
                                                                          .title
                                                                          .maybeHandleOverflow(
                                                                        maxChars:
                                                                            15,
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .titleLarge
                                                                          .override(
                                                                            fontFamily:
                                                                                'Manrope',
                                                                            color:
                                                                                Color(0xFF1A237E),
                                                                            fontSize:
                                                                                16.0,
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                    ),
                                                                    Text(
                                                                      'Start Date: ${dateTimeFormat(
                                                                        "d/M/y",
                                                                        listViewProjectsRecord
                                                                            .startDate,
                                                                        locale:
                                                                            FFLocalizations.of(context).languageCode,
                                                                      )}'
                                                                          .maybeHandleOverflow(
                                                                        maxChars:
                                                                            15,
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .titleLarge
                                                                          .override(
                                                                            fontFamily:
                                                                                'Manrope',
                                                                            color:
                                                                                Color(0xFF1A237E),
                                                                            fontSize:
                                                                                12.0,
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                    ),
                                                                    Text(
                                                                      'Due Date: ${dateTimeFormat(
                                                                        "d/M/y",
                                                                        listViewProjectsRecord
                                                                            .dueDate,
                                                                        locale:
                                                                            FFLocalizations.of(context).languageCode,
                                                                      )}'
                                                                          .maybeHandleOverflow(
                                                                        maxChars:
                                                                            15,
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .titleLarge
                                                                          .override(
                                                                            fontFamily:
                                                                                'Manrope',
                                                                            color:
                                                                                Color(0xFF1A237E),
                                                                            fontSize:
                                                                                12.0,
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                StreamBuilder<
                                                                    List<
                                                                        TaskRecord>>(
                                                                  stream:
                                                                      queryTaskRecord(
                                                                    singleRecord:
                                                                        true,
                                                                  ),
                                                                  builder: (context,
                                                                      snapshot) {
                                                                    // Customize what your widget looks like when it's loading.
                                                                    if (!snapshot
                                                                        .hasData) {
                                                                      return Center(
                                                                        child:
                                                                            SizedBox(
                                                                          width:
                                                                              50.0,
                                                                          height:
                                                                              50.0,
                                                                          child:
                                                                              CircularProgressIndicator(
                                                                            valueColor:
                                                                                AlwaysStoppedAnimation<Color>(
                                                                              Color(0xFF7364FC),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }
                                                                    List<TaskRecord>
                                                                        iconButtonTaskRecordList =
                                                                        snapshot
                                                                            .data!;
                                                                    // Return an empty Container when the item does not exist.
                                                                    if (snapshot
                                                                        .data!
                                                                        .isEmpty) {
                                                                      return Container();
                                                                    }
                                                                    final iconButtonTaskRecord = iconButtonTaskRecordList
                                                                            .isNotEmpty
                                                                        ? iconButtonTaskRecordList
                                                                            .first
                                                                        : null;

                                                                    return FlutterFlowIconButton(
                                                                      borderRadius:
                                                                          8.0,
                                                                      buttonSize:
                                                                          30.0,
                                                                      fillColor:
                                                                          Color(
                                                                              0xFF1A237E),
                                                                      icon:
                                                                          Icon(
                                                                        Icons
                                                                            .info_outline,
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .info,
                                                                        size:
                                                                            15.0,
                                                                      ),
                                                                      onPressed:
                                                                          () async {
                                                                        context
                                                                            .pushNamed(
                                                                          ChildobjphoneWidget
                                                                              .routeName,
                                                                          queryParameters:
                                                                              {
                                                                            'projectRef':
                                                                                serializeParam(
                                                                              iconButtonTaskRecord?.projectRef,
                                                                              ParamType.DocumentReference,
                                                                            ),
                                                                            'projTitle':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.title,
                                                                              ParamType.String,
                                                                            ),
                                                                            'projDesc':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.description,
                                                                              ParamType.String,
                                                                            ),
                                                                            'startDate':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.startDate,
                                                                              ParamType.DateTime,
                                                                            ),
                                                                            'endDate':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.dueDate,
                                                                              ParamType.DateTime,
                                                                            ),
                                                                            'progress':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.progress,
                                                                              ParamType.int,
                                                                            ),
                                                                            'projOwn':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.owner,
                                                                              ParamType.DocumentReference,
                                                                            ),
                                                                            'ownername':
                                                                                serializeParam(
                                                                              listViewProjectsRecord.ownerName,
                                                                              ParamType.String,
                                                                            ),
                                                                          }.withoutNulls,
                                                                        );
                                                                      },
                                                                    );
                                                                  },
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ].divide(SizedBox(
                                                            height: 16.0)),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        );
                                      },
                                    ),
                                  if ((_model.textController1.text != null &&
                                          _model.textController1.text != '') &&
                                      responsiveVisibility(
                                        context: context,
                                        phone: false,
                                        tablet: false,
                                      ))
                                    Builder(
                                      builder: (context) {
                                        final seae = _model.simpleSearchResults1
                                            .map((e) => e)
                                            .toList();

                                        return ListView.builder(
                                          padding: EdgeInsets.zero,
                                          shrinkWrap: true,
                                          scrollDirection: Axis.vertical,
                                          itemCount: seae.length,
                                          itemBuilder: (context, seaeIndex) {
                                            final seaeItem = seae[seaeIndex];
                                            return Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      0.0, 0.0, 0.0, 10.0),
                                              child: Material(
                                                color: Colors.transparent,
                                                elevation: 2.0,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          16.0),
                                                ),
                                                child: Container(
                                                  width:
                                                      MediaQuery.sizeOf(context)
                                                              .width *
                                                          1.0,
                                                  decoration: BoxDecoration(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryBackground,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16.0),
                                                  ),
                                                  child: Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                20.0,
                                                                10.0,
                                                                20.0,
                                                                10.0),
                                                    child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      12.0,
                                                                      0.0,
                                                                      12.0,
                                                                      0.0),
                                                          child: Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Text(
                                                                seaeItem.title,
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleLarge
                                                                    .override(
                                                                      fontFamily:
                                                                          'Manrope',
                                                                      color: Color(
                                                                          0xFF1A237E),
                                                                      fontSize:
                                                                          20.0,
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      12.0,
                                                                      0.0,
                                                                      12.0,
                                                                      0.0),
                                                          child: Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .max,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Text(
                                                                    'Start Date: ${dateTimeFormat(
                                                                      "yMMMd",
                                                                      seaeItem
                                                                          .startDate,
                                                                      locale: FFLocalizations.of(
                                                                              context)
                                                                          .languageCode,
                                                                    )}',
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Manrope',
                                                                          color:
                                                                              FlutterFlowTheme.of(context).secondaryText,
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                  Text(
                                                                    'End Date: ${dateTimeFormat(
                                                                      "yMMMd",
                                                                      seaeItem
                                                                          .dueDate,
                                                                      locale: FFLocalizations.of(
                                                                              context)
                                                                          .languageCode,
                                                                    )}',
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Manrope',
                                                                          color:
                                                                              FlutterFlowTheme.of(context).secondaryText,
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                ],
                                                              ),
                                                              StreamBuilder<
                                                                  List<
                                                                      TaskRecord>>(
                                                                stream:
                                                                    queryTaskRecord(
                                                                  singleRecord:
                                                                      true,
                                                                ),
                                                                builder: (context,
                                                                    snapshot) {
                                                                  // Customize what your widget looks like when it's loading.
                                                                  if (!snapshot
                                                                      .hasData) {
                                                                    return Center(
                                                                      child:
                                                                          SizedBox(
                                                                        width:
                                                                            50.0,
                                                                        height:
                                                                            50.0,
                                                                        child:
                                                                            CircularProgressIndicator(
                                                                          valueColor:
                                                                              AlwaysStoppedAnimation<Color>(
                                                                            Color(0xFF7364FC),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    );
                                                                  }
                                                                  List<TaskRecord>
                                                                      buttonTaskRecordList =
                                                                      snapshot
                                                                          .data!;
                                                                  // Return an empty Container when the item does not exist.
                                                                  if (snapshot
                                                                      .data!
                                                                      .isEmpty) {
                                                                    return Container();
                                                                  }
                                                                  final buttonTaskRecord = buttonTaskRecordList
                                                                          .isNotEmpty
                                                                      ? buttonTaskRecordList
                                                                          .first
                                                                      : null;

                                                                  return FFButtonWidget(
                                                                    onPressed:
                                                                        () async {
                                                                      context
                                                                          .pushNamed(
                                                                        DetailyyyWidget
                                                                            .routeName,
                                                                        queryParameters:
                                                                            {
                                                                          'projectRef':
                                                                              serializeParam(
                                                                            seaeItem.reference,
                                                                            ParamType.DocumentReference,
                                                                          ),
                                                                          'projTitle':
                                                                              serializeParam(
                                                                            seaeItem.title,
                                                                            ParamType.String,
                                                                          ),
                                                                          'projDesc':
                                                                              serializeParam(
                                                                            seaeItem.description,
                                                                            ParamType.String,
                                                                          ),
                                                                          'startDate':
                                                                              serializeParam(
                                                                            seaeItem.startDate,
                                                                            ParamType.DateTime,
                                                                          ),
                                                                          'endDate':
                                                                              serializeParam(
                                                                            seaeItem.dueDate,
                                                                            ParamType.DateTime,
                                                                          ),
                                                                          'progress':
                                                                              serializeParam(
                                                                            seaeItem.progress,
                                                                            ParamType.int,
                                                                          ),
                                                                          'projOwn':
                                                                              serializeParam(
                                                                            seaeItem.owner,
                                                                            ParamType.DocumentReference,
                                                                          ),
                                                                          'ownername':
                                                                              serializeParam(
                                                                            seaeItem.ownerName,
                                                                            ParamType.String,
                                                                          ),
                                                                          'parentOwn':
                                                                              serializeParam(
                                                                            seaeItem.parentOwner,
                                                                            ParamType.DocumentReference,
                                                                          ),
                                                                          'taskrefrence':
                                                                              serializeParam(
                                                                            buttonTaskRecord?.reference,
                                                                            ParamType.DocumentReference,
                                                                          ),
                                                                        }.withoutNulls,
                                                                      );
                                                                    },
                                                                    text: FFLocalizations.of(
                                                                            context)
                                                                        .getText(
                                                                      'acem05ql' /* View Details */,
                                                                    ),
                                                                    options:
                                                                        FFButtonOptions(
                                                                      width:
                                                                          120.0,
                                                                      height:
                                                                          36.0,
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                      iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                      color: Color(
                                                                          0xFF1A237E),
                                                                      textStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .override(
                                                                            fontFamily:
                                                                                'Manrope',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).info,
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                      elevation:
                                                                          0.0,
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              18.0),
                                                                    ),
                                                                  );
                                                                },
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ].divide(SizedBox(
                                                          height: 16.0)),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        );
                                      },
                                    ),
                                  if ((_model.textController1.text != null &&
                                          _model.textController1.text != '') &&
                                      responsiveVisibility(
                                        context: context,
                                        tabletLandscape: false,
                                        desktop: false,
                                      ))
                                    Builder(
                                      builder: (context) {
                                        final seae = _model.simpleSearchResults1
                                            .map((e) => e)
                                            .toList();

                                        return ListView.builder(
                                          padding: EdgeInsets.zero,
                                          shrinkWrap: true,
                                          scrollDirection: Axis.vertical,
                                          itemCount: seae.length,
                                          itemBuilder: (context, seaeIndex) {
                                            final seaeItem = seae[seaeIndex];
                                            return Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      0.0, 0.0, 0.0, 10.0),
                                              child: Material(
                                                color: Colors.transparent,
                                                elevation: 2.0,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          16.0),
                                                ),
                                                child: Container(
                                                  width:
                                                      MediaQuery.sizeOf(context)
                                                              .width *
                                                          1.0,
                                                  decoration: BoxDecoration(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryBackground,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16.0),
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    12.0,
                                                                    0.0,
                                                                    12.0,
                                                                    0.0),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Column(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              children: [
                                                                if (seaeItem
                                                                        .type ==
                                                                    'Private')
                                                                  Container(
                                                                    width:
                                                                        100.0,
                                                                    height:
                                                                        32.0,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Color(
                                                                          0xFF95BAFF),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              16.0),
                                                                    ),
                                                                    child:
                                                                        Align(
                                                                      alignment:
                                                                          AlignmentDirectional(
                                                                              0.0,
                                                                              0.0),
                                                                      child:
                                                                          Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            8.0,
                                                                            0.0,
                                                                            8.0,
                                                                            0.0),
                                                                        child:
                                                                            Text(
                                                                          seaeItem
                                                                              .type,
                                                                          textAlign:
                                                                              TextAlign.center,
                                                                          style: FlutterFlowTheme.of(context)
                                                                              .bodySmall
                                                                              .override(
                                                                                fontFamily: 'Manrope',
                                                                                color: Color(0xFF2E437D),
                                                                                letterSpacing: 0.0,
                                                                              ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    12.0,
                                                                    0.0,
                                                                    12.0,
                                                                    10.0),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Column(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              children: [
                                                                Align(
                                                                  alignment:
                                                                      AlignmentDirectional(
                                                                          -1.0,
                                                                          -1.0),
                                                                  child: Text(
                                                                    seaeItem
                                                                        .title,
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .titleLarge
                                                                        .override(
                                                                          fontFamily:
                                                                              'Manrope',
                                                                          color:
                                                                              Color(0xFF1A237E),
                                                                          fontSize:
                                                                              14.0,
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                ),
                                                                Text(
                                                                  'Start Date: ${dateTimeFormat(
                                                                    "d/M/y",
                                                                    seaeItem
                                                                        .startDate,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  )}'
                                                                      .maybeHandleOverflow(
                                                                    maxChars:
                                                                        15,
                                                                  ),
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleLarge
                                                                      .override(
                                                                        fontFamily:
                                                                            'Manrope',
                                                                        color: Color(
                                                                            0xFF1A237E),
                                                                        fontSize:
                                                                            12.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                ),
                                                                Text(
                                                                  'Due Date: ${dateTimeFormat(
                                                                    "d/M/y",
                                                                    seaeItem
                                                                        .dueDate,
                                                                    locale: FFLocalizations.of(
                                                                            context)
                                                                        .languageCode,
                                                                  )}'
                                                                      .maybeHandleOverflow(
                                                                    maxChars:
                                                                        15,
                                                                  ),
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .titleLarge
                                                                      .override(
                                                                        fontFamily:
                                                                            'Manrope',
                                                                        color: Color(
                                                                            0xFF1A237E),
                                                                        fontSize:
                                                                            12.0,
                                                                        letterSpacing:
                                                                            0.0,
                                                                      ),
                                                                ),
                                                              ],
                                                            ),
                                                            StreamBuilder<
                                                                List<
                                                                    TaskRecord>>(
                                                              stream:
                                                                  queryTaskRecord(
                                                                singleRecord:
                                                                    true,
                                                              ),
                                                              builder: (context,
                                                                  snapshot) {
                                                                // Customize what your widget looks like when it's loading.
                                                                if (!snapshot
                                                                    .hasData) {
                                                                  return Center(
                                                                    child:
                                                                        SizedBox(
                                                                      width:
                                                                          50.0,
                                                                      height:
                                                                          50.0,
                                                                      child:
                                                                          CircularProgressIndicator(
                                                                        valueColor:
                                                                            AlwaysStoppedAnimation<Color>(
                                                                          Color(
                                                                              0xFF7364FC),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  );
                                                                }
                                                                List<TaskRecord>
                                                                    iconButtonTaskRecordList =
                                                                    snapshot
                                                                        .data!;
                                                                // Return an empty Container when the item does not exist.
                                                                if (snapshot
                                                                    .data!
                                                                    .isEmpty) {
                                                                  return Container();
                                                                }
                                                                final iconButtonTaskRecord =
                                                                    iconButtonTaskRecordList
                                                                            .isNotEmpty
                                                                        ? iconButtonTaskRecordList
                                                                            .first
                                                                        : null;

                                                                return FlutterFlowIconButton(
                                                                  borderRadius:
                                                                      8.0,
                                                                  buttonSize:
                                                                      30.0,
                                                                  fillColor: Color(
                                                                      0xFF1A237E),
                                                                  icon: Icon(
                                                                    Icons
                                                                        .info_outline,
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .info,
                                                                    size: 15.0,
                                                                  ),
                                                                  onPressed:
                                                                      () async {
                                                                    context
                                                                        .pushNamed(
                                                                      ChildobjphoneWidget
                                                                          .routeName,
                                                                      queryParameters:
                                                                          {
                                                                        'projectRef':
                                                                            serializeParam(
                                                                          seaeItem
                                                                              .parentProj,
                                                                          ParamType
                                                                              .DocumentReference,
                                                                        ),
                                                                        'projTitle':
                                                                            serializeParam(
                                                                          seaeItem
                                                                              .title,
                                                                          ParamType
                                                                              .String,
                                                                        ),
                                                                        'projDesc':
                                                                            serializeParam(
                                                                          seaeItem
                                                                              .description,
                                                                          ParamType
                                                                              .String,
                                                                        ),
                                                                        'startDate':
                                                                            serializeParam(
                                                                          seaeItem
                                                                              .startDate,
                                                                          ParamType
                                                                              .DateTime,
                                                                        ),
                                                                        'endDate':
                                                                            serializeParam(
                                                                          seaeItem
                                                                              .dueDate,
                                                                          ParamType
                                                                              .DateTime,
                                                                        ),
                                                                        'progress':
                                                                            serializeParam(
                                                                          iconButtonTaskRecord
                                                                              ?.progress,
                                                                          ParamType
                                                                              .int,
                                                                        ),
                                                                        'projOwn':
                                                                            serializeParam(
                                                                          seaeItem
                                                                              .projectCreator,
                                                                          ParamType
                                                                              .DocumentReference,
                                                                        ),
                                                                        'ownername':
                                                                            serializeParam(
                                                                          seaeItem
                                                                              .ownerName,
                                                                          ParamType
                                                                              .String,
                                                                        ),
                                                                        'parentOwn':
                                                                            serializeParam(
                                                                          seaeItem
                                                                              .parentOwner,
                                                                          ParamType
                                                                              .DocumentReference,
                                                                        ),
                                                                        'parentList':
                                                                            serializeParam(
                                                                          seaeItem
                                                                              .parentOBJS,
                                                                          ParamType
                                                                              .DocumentReference,
                                                                          isList:
                                                                              true,
                                                                        ),
                                                                        'orgObj':
                                                                            serializeParam(
                                                                          seaeItem
                                                                              .organisational,
                                                                          ParamType
                                                                              .bool,
                                                                        ),
                                                                        'parentIds':
                                                                            serializeParam(
                                                                          seaeItem
                                                                              .parentIDS,
                                                                          ParamType
                                                                              .String,
                                                                          isList:
                                                                              true,
                                                                        ),
                                                                        'type':
                                                                            serializeParam(
                                                                          seaeItem
                                                                              .type,
                                                                          ParamType
                                                                              .String,
                                                                        ),
                                                                        'weighatage':
                                                                            serializeParam(
                                                                          seaeItem
                                                                              .weightage,
                                                                          ParamType
                                                                              .int,
                                                                        ),
                                                                      }.withoutNulls,
                                                                    );
                                                                  },
                                                                );
                                                              },
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ].divide(
                                                        SizedBox(height: 16.0)),
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        );
                                      },
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ].divide(SizedBox(height: 24.0)),
                      ),
                    ),
                    SingleChildScrollView(
                      primary: false,
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 5.0, 0.0, 0.0),
                            child: Container(
                              width: double.infinity,
                              height: 46.46,
                              decoration: BoxDecoration(
                                color: FlutterFlowTheme.of(context)
                                    .secondaryBackground,
                                borderRadius: BorderRadius.only(
                                  bottomLeft: Radius.circular(10.0),
                                  bottomRight: Radius.circular(10.0),
                                  topLeft: Radius.circular(10.0),
                                  topRight: Radius.circular(10.0),
                                ),
                              ),
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 10.0, 0.0, 10.0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Expanded(
                                      child: Container(
                                        width: 100.0,
                                        height: 50.2,
                                        decoration: BoxDecoration(),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  10.0, 0.0, 0.0, 5.0),
                                          child: TextFormField(
                                            controller: _model.textController2,
                                            focusNode:
                                                _model.textFieldFocusNode2,
                                            onFieldSubmitted: (_) async {
                                              await queryProjectsRecordOnce()
                                                  .then(
                                                    (records) => _model
                                                            .simpleSearchResults2 =
                                                        TextSearch(
                                                      records
                                                          .map(
                                                            (record) =>
                                                                TextSearchItem
                                                                    .fromTerms(
                                                                        record,
                                                                        [
                                                                  record.title!,
                                                                  record
                                                                      .ownerName!,
                                                                  record
                                                                      .description!
                                                                ]),
                                                          )
                                                          .toList(),
                                                    )
                                                            .search(_model
                                                                .textController2
                                                                .text)
                                                            .map(
                                                                (r) => r.object)
                                                            .toList(),
                                                  )
                                                  .onError((_, __) => _model
                                                          .simpleSearchResults2 =
                                                      [])
                                                  .whenComplete(() =>
                                                      safeSetState(() {}));
                                            },
                                            autofocus: false,
                                            obscureText: false,
                                            decoration: InputDecoration(
                                              hintText:
                                                  FFLocalizations.of(context)
                                                      .getText(
                                                'fmhivb1p' /* Search objectives... */,
                                              ),
                                              hintStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Manrope',
                                                        letterSpacing: 0.0,
                                                      ),
                                              enabledBorder: InputBorder.none,
                                              focusedBorder: InputBorder.none,
                                              errorBorder: InputBorder.none,
                                              focusedErrorBorder:
                                                  InputBorder.none,
                                              suffixIcon: Icon(
                                                Icons.search_sharp,
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondaryText,
                                                size: 20.0,
                                              ),
                                            ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Manrope',
                                                  letterSpacing: 0.0,
                                                ),
                                            minLines: 1,
                                            validator: _model
                                                .textController2Validator
                                                .asValidator(context),
                                          ),
                                        ),
                                      ),
                                    ),
                                    if (_model.textController2.text != null &&
                                        _model.textController2.text != '')
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 0.0, 20.0, 0.0),
                                        child: InkWell(
                                          splashColor: Colors.transparent,
                                          focusColor: Colors.transparent,
                                          hoverColor: Colors.transparent,
                                          highlightColor: Colors.transparent,
                                          onTap: () async {
                                            safeSetState(() {
                                              _model.textController2?.clear();
                                            });
                                          },
                                          child: Icon(
                                            Icons.clear_rounded,
                                            color: FlutterFlowTheme.of(context)
                                                .error,
                                            size: 25.0,
                                          ),
                                        ),
                                      ),
                                  ].divide(SizedBox(width: 12.0)),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                10.0, 0.0, 10.0, 0.0),
                            child: SingleChildScrollView(
                              primary: false,
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  if (responsiveVisibility(
                                    context: context,
                                    tabletLandscape: false,
                                    desktop: false,
                                  ))
                                    StreamBuilder<List<ProjectsRecord>>(
                                      stream: queryProjectsRecord(
                                        queryBuilder: (projectsRecord) =>
                                            projectsRecord
                                                .where(
                                                  'Type',
                                                  isEqualTo: 'Public',
                                                )
                                                .orderBy('start_date',
                                                    descending: true),
                                      ),
                                      builder: (context, snapshot) {
                                        // Customize what your widget looks like when it's loading.
                                        if (!snapshot.hasData) {
                                          return Center(
                                            child: SizedBox(
                                              width: 50.0,
                                              height: 50.0,
                                              child: CircularProgressIndicator(
                                                valueColor:
                                                    AlwaysStoppedAnimation<
                                                        Color>(
                                                  Color(0xFF7364FC),
                                                ),
                                              ),
                                            ),
                                          );
                                        }
                                        List<ProjectsRecord>
                                            listViewProjectsRecordList =
                                            snapshot.data!;

                                        return ListView.builder(
                                          padding: EdgeInsets.zero,
                                          shrinkWrap: true,
                                          scrollDirection: Axis.vertical,
                                          itemCount:
                                              listViewProjectsRecordList.length,
                                          itemBuilder:
                                              (context, listViewIndex) {
                                            final listViewProjectsRecord =
                                                listViewProjectsRecordList[
                                                    listViewIndex];
                                            return Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      0.0, 0.0, 0.0, 10.0),
                                              child: Material(
                                                color: Colors.transparent,
                                                elevation: 2.0,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          16.0),
                                                ),
                                                child: Container(
                                                  width:
                                                      MediaQuery.sizeOf(context)
                                                              .width *
                                                          1.0,
                                                  decoration: BoxDecoration(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryBackground,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16.0),
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    12.0,
                                                                    0.0,
                                                                    12.0,
                                                                    0.0),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Column(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              children: [
                                                                Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  children: [
                                                                    if (listViewProjectsRecord
                                                                            .type ==
                                                                        'Private')
                                                                      Container(
                                                                        width:
                                                                            100.0,
                                                                        height:
                                                                            32.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              Color(0xFF95BAFF),
                                                                          borderRadius:
                                                                              BorderRadius.circular(16.0),
                                                                        ),
                                                                        child:
                                                                            Align(
                                                                          alignment: AlignmentDirectional(
                                                                              0.0,
                                                                              0.0),
                                                                          child:
                                                                              Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                8.0,
                                                                                0.0,
                                                                                8.0,
                                                                                0.0),
                                                                            child:
                                                                                Text(
                                                                              listViewProjectsRecord.type,
                                                                              textAlign: TextAlign.center,
                                                                              style: FlutterFlowTheme.of(context).bodySmall.override(
                                                                                    fontFamily: 'Manrope',
                                                                                    color: Color(0xFF2E437D),
                                                                                    letterSpacing: 0.0,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    12.0,
                                                                    0.0,
                                                                    12.0,
                                                                    10.0),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Text(
                                                              listViewProjectsRecord
                                                                  .title,
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .titleLarge
                                                                  .override(
                                                                    fontFamily:
                                                                        'Manrope',
                                                                    color: Color(
                                                                        0xFF1A237E),
                                                                    fontSize:
                                                                        16.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                  ),
                                                            ),
                                                            StreamBuilder<
                                                                List<
                                                                    TaskRecord>>(
                                                              stream:
                                                                  queryTaskRecord(
                                                                singleRecord:
                                                                    true,
                                                              ),
                                                              builder: (context,
                                                                  snapshot) {
                                                                // Customize what your widget looks like when it's loading.
                                                                if (!snapshot
                                                                    .hasData) {
                                                                  return Center(
                                                                    child:
                                                                        SizedBox(
                                                                      width:
                                                                          50.0,
                                                                      height:
                                                                          50.0,
                                                                      child:
                                                                          CircularProgressIndicator(
                                                                        valueColor:
                                                                            AlwaysStoppedAnimation<Color>(
                                                                          Color(
                                                                              0xFF7364FC),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  );
                                                                }
                                                                List<TaskRecord>
                                                                    iconButtonTaskRecordList =
                                                                    snapshot
                                                                        .data!;
                                                                // Return an empty Container when the item does not exist.
                                                                if (snapshot
                                                                    .data!
                                                                    .isEmpty) {
                                                                  return Container();
                                                                }
                                                                final iconButtonTaskRecord =
                                                                    iconButtonTaskRecordList
                                                                            .isNotEmpty
                                                                        ? iconButtonTaskRecordList
                                                                            .first
                                                                        : null;

                                                                return FlutterFlowIconButton(
                                                                  borderRadius:
                                                                      8.0,
                                                                  buttonSize:
                                                                      30.0,
                                                                  fillColor: Color(
                                                                      0xFF1A237E),
                                                                  icon: Icon(
                                                                    Icons
                                                                        .info_outline,
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .info,
                                                                    size: 15.0,
                                                                  ),
                                                                  onPressed:
                                                                      () async {
                                                                    context
                                                                        .pushNamed(
                                                                      ChildobjphoneWidget
                                                                          .routeName,
                                                                      queryParameters:
                                                                          {
                                                                        'projectRef':
                                                                            serializeParam(
                                                                          listViewProjectsRecord
                                                                              .reference,
                                                                          ParamType
                                                                              .DocumentReference,
                                                                        ),
                                                                        'projTitle':
                                                                            serializeParam(
                                                                          listViewProjectsRecord
                                                                              .title,
                                                                          ParamType
                                                                              .String,
                                                                        ),
                                                                        'projDesc':
                                                                            serializeParam(
                                                                          listViewProjectsRecord
                                                                              .description,
                                                                          ParamType
                                                                              .String,
                                                                        ),
                                                                        'startDate':
                                                                            serializeParam(
                                                                          listViewProjectsRecord
                                                                              .startDate,
                                                                          ParamType
                                                                              .DateTime,
                                                                        ),
                                                                        'endDate':
                                                                            serializeParam(
                                                                          listViewProjectsRecord
                                                                              .dueDate,
                                                                          ParamType
                                                                              .DateTime,
                                                                        ),
                                                                        'progress':
                                                                            serializeParam(
                                                                          listViewProjectsRecord
                                                                              .progress,
                                                                          ParamType
                                                                              .int,
                                                                        ),
                                                                        'projOwn':
                                                                            serializeParam(
                                                                          listViewProjectsRecord
                                                                              .owner,
                                                                          ParamType
                                                                              .DocumentReference,
                                                                        ),
                                                                        'ownername':
                                                                            serializeParam(
                                                                          listViewProjectsRecord
                                                                              .ownerName,
                                                                          ParamType
                                                                              .String,
                                                                        ),
                                                                        'parentOwn':
                                                                            serializeParam(
                                                                          listViewProjectsRecord
                                                                              .parentOwner,
                                                                          ParamType
                                                                              .DocumentReference,
                                                                        ),
                                                                      }.withoutNulls,
                                                                    );
                                                                  },
                                                                );
                                                              },
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ].divide(
                                                        SizedBox(height: 16.0)),
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        );
                                      },
                                    ),
                                  if ((_model.textController2.text != null &&
                                          _model.textController2.text != '') &&
                                      responsiveVisibility(
                                        context: context,
                                        tabletLandscape: false,
                                        desktop: false,
                                      ))
                                    Builder(
                                      builder: (context) {
                                        final search2 = _model
                                            .simpleSearchResults2
                                            .toList();

                                        return ListView.builder(
                                          padding: EdgeInsets.zero,
                                          shrinkWrap: true,
                                          scrollDirection: Axis.vertical,
                                          itemCount: search2.length,
                                          itemBuilder: (context, search2Index) {
                                            final search2Item =
                                                search2[search2Index];
                                            return Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      0.0, 0.0, 0.0, 10.0),
                                              child: Material(
                                                color: Colors.transparent,
                                                elevation: 2.0,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          16.0),
                                                ),
                                                child: Container(
                                                  width:
                                                      MediaQuery.sizeOf(context)
                                                              .width *
                                                          1.0,
                                                  decoration: BoxDecoration(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryBackground,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16.0),
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    12.0,
                                                                    0.0,
                                                                    12.0,
                                                                    0.0),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Column(
                                                              mainAxisSize:
                                                                  MainAxisSize
                                                                      .max,
                                                              children: [
                                                                Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  children: [
                                                                    if (search2Item
                                                                            .type ==
                                                                        'Private')
                                                                      Container(
                                                                        width:
                                                                            100.0,
                                                                        height:
                                                                            32.0,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              Color(0xFF95BAFF),
                                                                          borderRadius:
                                                                              BorderRadius.circular(16.0),
                                                                        ),
                                                                        child:
                                                                            Align(
                                                                          alignment: AlignmentDirectional(
                                                                              0.0,
                                                                              0.0),
                                                                          child:
                                                                              Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                8.0,
                                                                                0.0,
                                                                                8.0,
                                                                                0.0),
                                                                            child:
                                                                                Text(
                                                                              search2Item.title,
                                                                              textAlign: TextAlign.center,
                                                                              style: FlutterFlowTheme.of(context).bodySmall.override(
                                                                                    fontFamily: 'Manrope',
                                                                                    color: Color(0xFF2E437D),
                                                                                    letterSpacing: 0.0,
                                                                                  ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    12.0,
                                                                    0.0,
                                                                    12.0,
                                                                    10.0),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Text(
                                                              search2Item.title,
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .titleLarge
                                                                  .override(
                                                                    fontFamily:
                                                                        'Manrope',
                                                                    color: Color(
                                                                        0xFF1A237E),
                                                                    fontSize:
                                                                        16.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                  ),
                                                            ),
                                                            StreamBuilder<
                                                                List<
                                                                    TaskRecord>>(
                                                              stream:
                                                                  queryTaskRecord(
                                                                singleRecord:
                                                                    true,
                                                              ),
                                                              builder: (context,
                                                                  snapshot) {
                                                                // Customize what your widget looks like when it's loading.
                                                                if (!snapshot
                                                                    .hasData) {
                                                                  return Center(
                                                                    child:
                                                                        SizedBox(
                                                                      width:
                                                                          50.0,
                                                                      height:
                                                                          50.0,
                                                                      child:
                                                                          CircularProgressIndicator(
                                                                        valueColor:
                                                                            AlwaysStoppedAnimation<Color>(
                                                                          Color(
                                                                              0xFF7364FC),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  );
                                                                }
                                                                List<TaskRecord>
                                                                    iconButtonTaskRecordList =
                                                                    snapshot
                                                                        .data!;
                                                                // Return an empty Container when the item does not exist.
                                                                if (snapshot
                                                                    .data!
                                                                    .isEmpty) {
                                                                  return Container();
                                                                }
                                                                final iconButtonTaskRecord =
                                                                    iconButtonTaskRecordList
                                                                            .isNotEmpty
                                                                        ? iconButtonTaskRecordList
                                                                            .first
                                                                        : null;

                                                                return FlutterFlowIconButton(
                                                                  borderRadius:
                                                                      8.0,
                                                                  buttonSize:
                                                                      30.0,
                                                                  fillColor: Color(
                                                                      0xFF1A237E),
                                                                  icon: Icon(
                                                                    Icons
                                                                        .info_outline,
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .info,
                                                                    size: 15.0,
                                                                  ),
                                                                  onPressed:
                                                                      () async {
                                                                    context
                                                                        .pushNamed(
                                                                      ChilObjWidget
                                                                          .routeName,
                                                                      queryParameters:
                                                                          {
                                                                        'projectRef':
                                                                            serializeParam(
                                                                          iconButtonTaskRecord
                                                                              ?.projectRef,
                                                                          ParamType
                                                                              .DocumentReference,
                                                                        ),
                                                                        'projTitle':
                                                                            serializeParam(
                                                                          search2Item
                                                                              .title,
                                                                          ParamType
                                                                              .String,
                                                                        ),
                                                                        'projDesc':
                                                                            serializeParam(
                                                                          search2Item
                                                                              .description,
                                                                          ParamType
                                                                              .String,
                                                                        ),
                                                                        'startDate':
                                                                            serializeParam(
                                                                          search2Item
                                                                              .startDate,
                                                                          ParamType
                                                                              .DateTime,
                                                                        ),
                                                                        'endDate':
                                                                            serializeParam(
                                                                          search2Item
                                                                              .dueDate,
                                                                          ParamType
                                                                              .DateTime,
                                                                        ),
                                                                        'progress':
                                                                            serializeParam(
                                                                          search2Item
                                                                              .progress,
                                                                          ParamType
                                                                              .int,
                                                                        ),
                                                                        'projOwn':
                                                                            serializeParam(
                                                                          search2Item
                                                                              .projectCreator,
                                                                          ParamType
                                                                              .DocumentReference,
                                                                        ),
                                                                        'ownername':
                                                                            serializeParam(
                                                                          search2Item
                                                                              .ownerName,
                                                                          ParamType
                                                                              .String,
                                                                        ),
                                                                        'parentOwn':
                                                                            serializeParam(
                                                                          search2Item
                                                                              .parentOwner,
                                                                          ParamType
                                                                              .DocumentReference,
                                                                        ),
                                                                        'orgObj':
                                                                            serializeParam(
                                                                          search2Item
                                                                              .organisational,
                                                                          ParamType
                                                                              .bool,
                                                                        ),
                                                                        'parentList':
                                                                            serializeParam(
                                                                          search2Item
                                                                              .parentOBJS,
                                                                          ParamType
                                                                              .DocumentReference,
                                                                          isList:
                                                                              true,
                                                                        ),
                                                                        'parentIds':
                                                                            serializeParam(
                                                                          search2Item
                                                                              .parentIDS,
                                                                          ParamType
                                                                              .String,
                                                                          isList:
                                                                              true,
                                                                        ),
                                                                      }.withoutNulls,
                                                                    );
                                                                  },
                                                                );
                                                              },
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ].divide(
                                                        SizedBox(height: 16.0)),
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        );
                                      },
                                    ),
                                  if (responsiveVisibility(
                                    context: context,
                                    phone: false,
                                    tablet: false,
                                  ))
                                    StreamBuilder<List<ProjectsRecord>>(
                                      stream: queryProjectsRecord(
                                        queryBuilder: (projectsRecord) =>
                                            projectsRecord
                                                .where(
                                                  'Type',
                                                  isEqualTo: 'Public',
                                                )
                                                .orderBy('start_date'),
                                      ),
                                      builder: (context, snapshot) {
                                        // Customize what your widget looks like when it's loading.
                                        if (!snapshot.hasData) {
                                          return Center(
                                            child: SizedBox(
                                              width: 50.0,
                                              height: 50.0,
                                              child: CircularProgressIndicator(
                                                valueColor:
                                                    AlwaysStoppedAnimation<
                                                        Color>(
                                                  Color(0xFF7364FC),
                                                ),
                                              ),
                                            ),
                                          );
                                        }
                                        List<ProjectsRecord>
                                            listViewProjectsRecordList =
                                            snapshot.data!;

                                        return ListView.builder(
                                          padding: EdgeInsets.zero,
                                          shrinkWrap: true,
                                          scrollDirection: Axis.vertical,
                                          itemCount:
                                              listViewProjectsRecordList.length,
                                          itemBuilder:
                                              (context, listViewIndex) {
                                            final listViewProjectsRecord =
                                                listViewProjectsRecordList[
                                                    listViewIndex];
                                            return Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      0.0, 0.0, 0.0, 10.0),
                                              child: Material(
                                                color: Colors.transparent,
                                                elevation: 2.0,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          16.0),
                                                ),
                                                child: Container(
                                                  width:
                                                      MediaQuery.sizeOf(context)
                                                              .width *
                                                          1.0,
                                                  decoration: BoxDecoration(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryBackground,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16.0),
                                                  ),
                                                  child: Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                20.0,
                                                                10.0,
                                                                20.0,
                                                                10.0),
                                                    child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      12.0,
                                                                      0.0,
                                                                      12.0,
                                                                      0.0),
                                                          child: Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Text(
                                                                listViewProjectsRecord
                                                                    .title,
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleLarge
                                                                    .override(
                                                                      fontFamily:
                                                                          'Manrope',
                                                                      color: Color(
                                                                          0xFF1A237E),
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      12.0,
                                                                      0.0,
                                                                      12.0,
                                                                      0.0),
                                                          child: Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .max,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  if (responsiveVisibility(
                                                                    context:
                                                                        context,
                                                                    phone:
                                                                        false,
                                                                    tablet:
                                                                        false,
                                                                  ))
                                                                    Text(
                                                                      'Start Date: ${dateTimeFormat(
                                                                        "yMMMd",
                                                                        listViewProjectsRecord
                                                                            .startDate,
                                                                        locale:
                                                                            FFLocalizations.of(context).languageCode,
                                                                      )}',
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .override(
                                                                            fontFamily:
                                                                                'Manrope',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).secondaryText,
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                    ),
                                                                  if (responsiveVisibility(
                                                                    context:
                                                                        context,
                                                                    phone:
                                                                        false,
                                                                    tablet:
                                                                        false,
                                                                  ))
                                                                    Text(
                                                                      'End Date: ${dateTimeFormat(
                                                                        "yMMMd",
                                                                        listViewProjectsRecord
                                                                            .dueDate,
                                                                        locale:
                                                                            FFLocalizations.of(context).languageCode,
                                                                      )}',
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .override(
                                                                            fontFamily:
                                                                                'Manrope',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).secondaryText,
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                    ),
                                                                  if (responsiveVisibility(
                                                                    context:
                                                                        context,
                                                                    phone:
                                                                        false,
                                                                    tablet:
                                                                        false,
                                                                  ))
                                                                    Text(
                                                                      'Owner: ${listViewProjectsRecord.ownerName}',
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .override(
                                                                            fontFamily:
                                                                                'Manrope',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).secondaryText,
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                    ),
                                                                ],
                                                              ),
                                                              StreamBuilder<
                                                                  List<
                                                                      TaskRecord>>(
                                                                stream:
                                                                    queryTaskRecord(
                                                                  singleRecord:
                                                                      true,
                                                                ),
                                                                builder: (context,
                                                                    snapshot) {
                                                                  // Customize what your widget looks like when it's loading.
                                                                  if (!snapshot
                                                                      .hasData) {
                                                                    return Center(
                                                                      child:
                                                                          SizedBox(
                                                                        width:
                                                                            50.0,
                                                                        height:
                                                                            50.0,
                                                                        child:
                                                                            CircularProgressIndicator(
                                                                          valueColor:
                                                                              AlwaysStoppedAnimation<Color>(
                                                                            Color(0xFF7364FC),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    );
                                                                  }
                                                                  List<TaskRecord>
                                                                      buttonTaskRecordList =
                                                                      snapshot
                                                                          .data!;
                                                                  // Return an empty Container when the item does not exist.
                                                                  if (snapshot
                                                                      .data!
                                                                      .isEmpty) {
                                                                    return Container();
                                                                  }
                                                                  final buttonTaskRecord = buttonTaskRecordList
                                                                          .isNotEmpty
                                                                      ? buttonTaskRecordList
                                                                          .first
                                                                      : null;

                                                                  return FFButtonWidget(
                                                                    onPressed:
                                                                        () async {
                                                                      context
                                                                          .pushNamed(
                                                                        ChilObjWidget
                                                                            .routeName,
                                                                        queryParameters:
                                                                            {
                                                                          'projectRef':
                                                                              serializeParam(
                                                                            listViewProjectsRecord.reference,
                                                                            ParamType.DocumentReference,
                                                                          ),
                                                                          'projTitle':
                                                                              serializeParam(
                                                                            listViewProjectsRecord.title,
                                                                            ParamType.String,
                                                                          ),
                                                                          'projDesc':
                                                                              serializeParam(
                                                                            listViewProjectsRecord.description,
                                                                            ParamType.String,
                                                                          ),
                                                                          'startDate':
                                                                              serializeParam(
                                                                            listViewProjectsRecord.startDate,
                                                                            ParamType.DateTime,
                                                                          ),
                                                                          'endDate':
                                                                              serializeParam(
                                                                            listViewProjectsRecord.dueDate,
                                                                            ParamType.DateTime,
                                                                          ),
                                                                          'progress':
                                                                              serializeParam(
                                                                            listViewProjectsRecord.progress,
                                                                            ParamType.int,
                                                                          ),
                                                                          'projOwn':
                                                                              serializeParam(
                                                                            listViewProjectsRecord.owner,
                                                                            ParamType.DocumentReference,
                                                                          ),
                                                                          'ownername':
                                                                              serializeParam(
                                                                            listViewProjectsRecord.ownerName,
                                                                            ParamType.String,
                                                                          ),
                                                                          'parentOwn':
                                                                              serializeParam(
                                                                            listViewProjectsRecord.parentOwner,
                                                                            ParamType.DocumentReference,
                                                                          ),
                                                                          'orgObj':
                                                                              serializeParam(
                                                                            listViewProjectsRecord.organisational,
                                                                            ParamType.bool,
                                                                          ),
                                                                          'parentList':
                                                                              serializeParam(
                                                                            listViewProjectsRecord.parentOBJS,
                                                                            ParamType.DocumentReference,
                                                                            isList:
                                                                                true,
                                                                          ),
                                                                          'parentIds':
                                                                              serializeParam(
                                                                            listViewProjectsRecord.parentIDS,
                                                                            ParamType.String,
                                                                            isList:
                                                                                true,
                                                                          ),
                                                                        }.withoutNulls,
                                                                      );
                                                                    },
                                                                    text: FFLocalizations.of(
                                                                            context)
                                                                        .getText(
                                                                      '1svfo4ps' /* View Details */,
                                                                    ),
                                                                    options:
                                                                        FFButtonOptions(
                                                                      width:
                                                                          120.0,
                                                                      height:
                                                                          36.0,
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                      iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                      color: Color(
                                                                          0xFF1A237E),
                                                                      textStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .override(
                                                                            fontFamily:
                                                                                'Manrope',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).info,
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                      elevation:
                                                                          0.0,
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              18.0),
                                                                    ),
                                                                  );
                                                                },
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ].divide(SizedBox(
                                                          height: 16.0)),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        );
                                      },
                                    ),
                                  if ((_model.textController2.text != null &&
                                          _model.textController2.text != '') &&
                                      responsiveVisibility(
                                        context: context,
                                        phone: false,
                                        tablet: false,
                                      ))
                                    Builder(
                                      builder: (context) {
                                        final seae = _model.simpleSearchResults1
                                            .toList();

                                        return ListView.builder(
                                          padding: EdgeInsets.zero,
                                          shrinkWrap: true,
                                          scrollDirection: Axis.vertical,
                                          itemCount: seae.length,
                                          itemBuilder: (context, seaeIndex) {
                                            final seaeItem = seae[seaeIndex];
                                            return Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(
                                                      0.0, 0.0, 0.0, 10.0),
                                              child: Material(
                                                color: Colors.transparent,
                                                elevation: 2.0,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          16.0),
                                                ),
                                                child: Container(
                                                  width:
                                                      MediaQuery.sizeOf(context)
                                                              .width *
                                                          1.0,
                                                  decoration: BoxDecoration(
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .secondaryBackground,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16.0),
                                                  ),
                                                  child: Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                20.0,
                                                                10.0,
                                                                20.0,
                                                                10.0),
                                                    child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      12.0,
                                                                      0.0,
                                                                      12.0,
                                                                      0.0),
                                                          child: Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Text(
                                                                seaeItem.title,
                                                                style: FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleLarge
                                                                    .override(
                                                                      fontFamily:
                                                                          'Manrope',
                                                                      color: Color(
                                                                          0xFF1A237E),
                                                                      letterSpacing:
                                                                          0.0,
                                                                    ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      12.0,
                                                                      0.0,
                                                                      12.0,
                                                                      0.0),
                                                          child: Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Column(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .max,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Text(
                                                                    'Start Date: ${dateTimeFormat(
                                                                      "yMMMd",
                                                                      seaeItem
                                                                          .startDate,
                                                                      locale: FFLocalizations.of(
                                                                              context)
                                                                          .languageCode,
                                                                    )}',
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Manrope',
                                                                          color:
                                                                              FlutterFlowTheme.of(context).secondaryText,
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                  Text(
                                                                    'End Date: ${dateTimeFormat(
                                                                      "yMMMd",
                                                                      seaeItem
                                                                          .dueDate,
                                                                      locale: FFLocalizations.of(
                                                                              context)
                                                                          .languageCode,
                                                                    )}',
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Manrope',
                                                                          color:
                                                                              FlutterFlowTheme.of(context).secondaryText,
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                  Text(
                                                                    seaeItem
                                                                        .ownerName,
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyMedium
                                                                        .override(
                                                                          fontFamily:
                                                                              'Manrope',
                                                                          color:
                                                                              FlutterFlowTheme.of(context).secondaryText,
                                                                          letterSpacing:
                                                                              0.0,
                                                                        ),
                                                                  ),
                                                                ],
                                                              ),
                                                              StreamBuilder<
                                                                  List<
                                                                      TaskRecord>>(
                                                                stream:
                                                                    queryTaskRecord(
                                                                  singleRecord:
                                                                      true,
                                                                ),
                                                                builder: (context,
                                                                    snapshot) {
                                                                  // Customize what your widget looks like when it's loading.
                                                                  if (!snapshot
                                                                      .hasData) {
                                                                    return Center(
                                                                      child:
                                                                          SizedBox(
                                                                        width:
                                                                            50.0,
                                                                        height:
                                                                            50.0,
                                                                        child:
                                                                            CircularProgressIndicator(
                                                                          valueColor:
                                                                              AlwaysStoppedAnimation<Color>(
                                                                            Color(0xFF7364FC),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    );
                                                                  }
                                                                  List<TaskRecord>
                                                                      buttonTaskRecordList =
                                                                      snapshot
                                                                          .data!;
                                                                  // Return an empty Container when the item does not exist.
                                                                  if (snapshot
                                                                      .data!
                                                                      .isEmpty) {
                                                                    return Container();
                                                                  }
                                                                  final buttonTaskRecord = buttonTaskRecordList
                                                                          .isNotEmpty
                                                                      ? buttonTaskRecordList
                                                                          .first
                                                                      : null;

                                                                  return FFButtonWidget(
                                                                    onPressed:
                                                                        () async {
                                                                      context
                                                                          .pushNamed(
                                                                        DetailyyyWidget
                                                                            .routeName,
                                                                        queryParameters:
                                                                            {
                                                                          'projectRef':
                                                                              serializeParam(
                                                                            buttonTaskRecord?.projectRef,
                                                                            ParamType.DocumentReference,
                                                                          ),
                                                                          'projTitle':
                                                                              serializeParam(
                                                                            buttonTaskRecord?.taskTitle,
                                                                            ParamType.String,
                                                                          ),
                                                                          'projDesc':
                                                                              serializeParam(
                                                                            buttonTaskRecord?.taskDesc,
                                                                            ParamType.String,
                                                                          ),
                                                                          'startDate':
                                                                              serializeParam(
                                                                            buttonTaskRecord?.craeteddate,
                                                                            ParamType.DateTime,
                                                                          ),
                                                                          'endDate':
                                                                              serializeParam(
                                                                            buttonTaskRecord?.dueDate,
                                                                            ParamType.DateTime,
                                                                          ),
                                                                          'progress':
                                                                              serializeParam(
                                                                            buttonTaskRecord?.progress,
                                                                            ParamType.int,
                                                                          ),
                                                                          'projOwn':
                                                                              serializeParam(
                                                                            seaeItem.owner,
                                                                            ParamType.DocumentReference,
                                                                          ),
                                                                          'ownername':
                                                                              serializeParam(
                                                                            seaeItem.ownerName,
                                                                            ParamType.String,
                                                                          ),
                                                                          'parentOwn':
                                                                              serializeParam(
                                                                            seaeItem.parentOwner,
                                                                            ParamType.DocumentReference,
                                                                          ),
                                                                          'taskrefrence':
                                                                              serializeParam(
                                                                            buttonTaskRecord?.reference,
                                                                            ParamType.DocumentReference,
                                                                          ),
                                                                        }.withoutNulls,
                                                                      );
                                                                    },
                                                                    text: FFLocalizations.of(
                                                                            context)
                                                                        .getText(
                                                                      'xq6scj2i' /* View Details */,
                                                                    ),
                                                                    options:
                                                                        FFButtonOptions(
                                                                      width:
                                                                          120.0,
                                                                      height:
                                                                          36.0,
                                                                      padding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                      iconPadding: EdgeInsetsDirectional.fromSTEB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                      color: Color(
                                                                          0xFF1A237E),
                                                                      textStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyMedium
                                                                          .override(
                                                                            fontFamily:
                                                                                'Manrope',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).info,
                                                                            letterSpacing:
                                                                                0.0,
                                                                          ),
                                                                      elevation:
                                                                          0.0,
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              18.0),
                                                                    ),
                                                                  );
                                                                },
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ].divide(SizedBox(
                                                          height: 16.0)),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        );
                                      },
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ].divide(SizedBox(height: 24.0)),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
