import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'task_update_model.dart';
export 'task_update_model.dart';

class TaskUpdateWidget extends StatefulWidget {
  const TaskUpdateWidget({
    super.key,
    required this.taskref,
    this.status,
    this.reviewable,
  });

  final DocumentReference? taskref;
  final String? status;
  final bool? reviewable;

  @override
  State<TaskUpdateWidget> createState() => _TaskUpdateWidgetState();
}

class _TaskUpdateWidgetState extends State<TaskUpdateWidget> {
  late TaskUpdateModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TaskUpdateModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).secondaryBackground,
            boxShadow: [
              BoxShadow(
                blurRadius: 3.0,
                color: Color(0x33000000),
                offset: Offset(
                  0.0,
                  1.0,
                ),
                spreadRadius: 0.0,
              )
            ],
            borderRadius: BorderRadius.circular(12.0),
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(16.0, 16.0, 16.0, 16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  FFLocalizations.of(context).getText(
                    'ne5pdpy3' /* Update Task Status */,
                  ),
                  style: FlutterFlowTheme.of(context).headlineSmall.override(
                        fontFamily: 'Urbanist',
                        letterSpacing: 0.0,
                      ),
                ),
                Text(
                  FFLocalizations.of(context).getText(
                    'qbod09z1' /* Select the current status of y... */,
                  ),
                  style: FlutterFlowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Manrope',
                        color: FlutterFlowTheme.of(context).secondaryText,
                        letterSpacing: 0.0,
                      ),
                ),
                FlutterFlowChoiceChips(
                  options: [
                    ChipData(FFLocalizations.of(context).getText(
                      'f332dg74' /* Not Started */,
                    )),
                    ChipData(FFLocalizations.of(context).getText(
                      'fy44rlzj' /* In Progress */,
                    )),
                    ChipData(FFLocalizations.of(context).getText(
                      'x76179g0' /* Completed */,
                    ))
                  ],
                  onChanged: (val) => safeSetState(
                      () => _model.choiceChipsValue = val?.firstOrNull),
                  selectedChipStyle: ChipStyle(
                    backgroundColor: FlutterFlowTheme.of(context).primary,
                    textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Manrope',
                          color: FlutterFlowTheme.of(context).info,
                          fontSize: 14.0,
                          letterSpacing: 0.0,
                        ),
                    iconColor: FlutterFlowTheme.of(context).primaryText,
                    iconSize: 18.0,
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  unselectedChipStyle: ChipStyle(
                    backgroundColor: Color(0x66CFD9DD),
                    textStyle: FlutterFlowTheme.of(context).bodySmall.override(
                          fontFamily: 'Manrope',
                          color: FlutterFlowTheme.of(context).secondaryText,
                          fontSize: 14.0,
                          letterSpacing: 0.0,
                        ),
                    iconColor: FlutterFlowTheme.of(context).primaryText,
                    iconSize: 18.0,
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  chipSpacing: 12.0,
                  rowSpacing: 12.0,
                  multiselect: false,
                  initialized: _model.choiceChipsValue != null,
                  alignment: WrapAlignment.start,
                  controller: _model.choiceChipsValueController ??=
                      FormFieldController<List<String>>(
                    [widget!.status!],
                  ),
                  wrapped: true,
                ),
                FlutterFlowChoiceChips(
                  options: [
                    ChipData(FFLocalizations.of(context).getText(
                      '9nrv246m' /* Not Started */,
                    )),
                    ChipData(FFLocalizations.of(context).getText(
                      'pt6yvm5x' /* In Progress */,
                    )),
                    ChipData(FFLocalizations.of(context).getText(
                      'v1udyv84' /* Send for Review */,
                    ))
                  ],
                  onChanged: (val) => safeSetState(
                      () => _model.choiceChipsRevValue = val?.firstOrNull),
                  selectedChipStyle: ChipStyle(
                    backgroundColor: FlutterFlowTheme.of(context).primary,
                    textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Manrope',
                          color: FlutterFlowTheme.of(context).info,
                          fontSize: 14.0,
                          letterSpacing: 0.0,
                        ),
                    iconColor: FlutterFlowTheme.of(context).primaryText,
                    iconSize: 18.0,
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  unselectedChipStyle: ChipStyle(
                    backgroundColor: Color(0x66CFD9DD),
                    textStyle: FlutterFlowTheme.of(context).bodySmall.override(
                          fontFamily: 'Manrope',
                          color: FlutterFlowTheme.of(context).secondaryText,
                          fontSize: 14.0,
                          letterSpacing: 0.0,
                        ),
                    iconColor: FlutterFlowTheme.of(context).primaryText,
                    iconSize: 18.0,
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(20.0),
                  ),
                  chipSpacing: 12.0,
                  rowSpacing: 12.0,
                  multiselect: false,
                  initialized: _model.choiceChipsRevValue != null,
                  alignment: WrapAlignment.start,
                  controller: _model.choiceChipsRevValueController ??=
                      FormFieldController<List<String>>(
                    [widget!.status!],
                  ),
                  wrapped: true,
                ),
                FFButtonWidget(
                  onPressed: () async {
                    if (widget!.reviewable == true) {
                      if (_model.choiceChipsValue == 'Send to Review') {
                        await widget!.taskref!.update(createTaskRecordData(
                          status: _model.choiceChipsValue,
                        ));
                      } else {
                        await widget!.taskref!.update(createTaskRecordData(
                          status: _model.choiceChipsValue,
                        ));
                      }

                      Navigator.pop(context);
                    } else {
                      if (_model.choiceChipsRevValue == 'Send to Review') {
                        await widget!.taskref!.update(createTaskRecordData(
                          status: 'Under Review',
                        ));
                      } else {
                        await widget!.taskref!.update(createTaskRecordData(
                          status: _model.choiceChipsRevValue,
                        ));
                      }

                      Navigator.pop(context);
                    }
                  },
                  text: FFLocalizations.of(context).getText(
                    'fm19yp35' /* Update Status */,
                  ),
                  options: FFButtonOptions(
                    height: 40.0,
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: Color(0xFF1A237E),
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          fontFamily: 'Manrope',
                          color: Colors.white,
                          letterSpacing: 0.0,
                        ),
                    elevation: 0.0,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ].divide(SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
