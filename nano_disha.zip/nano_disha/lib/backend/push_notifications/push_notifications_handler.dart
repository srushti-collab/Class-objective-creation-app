import 'dart:async';
import 'dart:convert';

import 'serialization_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../../index.dart';
import '../../main.dart';

final _handledMessageIds = <String?>{};

class PushNotificationsHandler extends StatefulWidget {
  const PushNotificationsHandler({Key? key, required this.child})
      : super(key: key);

  final Widget child;

  @override
  _PushNotificationsHandlerState createState() =>
      _PushNotificationsHandlerState();
}

class _PushNotificationsHandlerState extends State<PushNotificationsHandler> {
  bool _loading = false;

  Future handleOpenedPushNotification() async {
    if (isWeb) {
      return;
    }

    final notification = await FirebaseMessaging.instance.getInitialMessage();
    if (notification != null) {
      await _handlePushNotification(notification);
    }
    FirebaseMessaging.onMessageOpenedApp.listen(_handlePushNotification);
  }

  Future _handlePushNotification(RemoteMessage message) async {
    if (_handledMessageIds.contains(message.messageId)) {
      return;
    }
    _handledMessageIds.add(message.messageId);

    safeSetState(() => _loading = true);
    try {
      final initialPageName = message.data['initialPageName'] as String;
      final initialParameterData = getInitialParameterData(message.data);
      final parametersBuilder = parametersBuilderMap[initialPageName];
      if (parametersBuilder != null) {
        final parameterData = await parametersBuilder(initialParameterData);
        if (mounted) {
          context.pushNamed(
            initialPageName,
            pathParameters: parameterData.pathParameters,
            extra: parameterData.extra,
          );
        } else {
          appNavigatorKey.currentContext?.pushNamed(
            initialPageName,
            pathParameters: parameterData.pathParameters,
            extra: parameterData.extra,
          );
        }
      }
    } catch (e) {
      print('Error: $e');
    } finally {
      safeSetState(() => _loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    SchedulerBinding.instance.addPostFrameCallback((_) {
      handleOpenedPushNotification();
    });
  }

  @override
  Widget build(BuildContext context) => _loading
      ? Container(
          color: Colors.transparent,
          child: Image.asset(
            'assets/images/nanopix.png',
            fit: BoxFit.contain,
          ),
        )
      : widget.child;
}

class ParameterData {
  const ParameterData(
      {this.requiredParams = const {}, this.allParams = const {}});
  final Map<String, String?> requiredParams;
  final Map<String, dynamic> allParams;

  Map<String, String> get pathParameters => Map.fromEntries(
        requiredParams.entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
  Map<String, dynamic> get extra => Map.fromEntries(
        allParams.entries.where((e) => e.value != null),
      );

  static Future<ParameterData> Function(Map<String, dynamic>) none() =>
      (data) async => ParameterData();
}

final parametersBuilderMap =
    <String, Future<ParameterData> Function(Map<String, dynamic>)>{
  'LoginPage': ParameterData.none(),
  'Reports': ParameterData.none(),
  'subOBJ': ParameterData.none(),
  'DASHHYYY': ParameterData.none(),
  'Objectives': ParameterData.none(),
  'Detailyyy': (data) async => ParameterData(
        allParams: {
          'projectRef': getParameter<DocumentReference>(data, 'projectRef'),
          'projTitle': getParameter<String>(data, 'projTitle'),
          'projDesc': getParameter<String>(data, 'projDesc'),
          'startDate': getParameter<DateTime>(data, 'startDate'),
          'endDate': getParameter<DateTime>(data, 'endDate'),
          'progress': getParameter<int>(data, 'progress'),
          'projOwn': getParameter<DocumentReference>(data, 'projOwn'),
          'ownername': getParameter<String>(data, 'ownername'),
          'parentOwn': getParameter<DocumentReference>(data, 'parentOwn'),
          'progressbar': getParameter<int>(data, 'progressbar'),
          'taskrefrence': getParameter<DocumentReference>(data, 'taskrefrence'),
          'type': getParameter<String>(data, 'type'),
          'weightage': getParameter<int>(data, 'weightage'),
        },
      ),
  'DetailyyyCopy': (data) async => ParameterData(
        allParams: {
          'projectRef': getParameter<DocumentReference>(data, 'projectRef'),
          'projTitle': getParameter<String>(data, 'projTitle'),
          'planTitle': getParameter<String>(data, 'planTitle'),
          'planDesc': getParameter<String>(data, 'planDesc'),
          'startDate': getParameter<DateTime>(data, 'startDate'),
          'endTime': getParameter<DateTime>(data, 'endTime'),
          'planRef': getParameter<DocumentReference>(data, 'planRef'),
          'projMan': getParameter<DocumentReference>(data, 'projMan'),
          'owner': getParameter<DocumentReference>(data, 'owner'),
          'ownerName': getParameter<String>(data, 'ownerName'),
          'parentOwn': getParameter<DocumentReference>(data, 'parentOwn'),
        },
      ),
  'Taskyy': ParameterData.none(),
  'Employeeee': ParameterData.none(),
  'ManagerDashyy': ParameterData.none(),
  'AssignedObj': (data) async => ParameterData(
        allParams: {
          'progress': getParameter<double>(data, 'progress'),
        },
      ),
  'DetailyyOwner': (data) async => ParameterData(
        allParams: {
          'projectRef': getParameter<DocumentReference>(data, 'projectRef'),
          'projTitle': getParameter<String>(data, 'projTitle'),
          'projDesc': getParameter<String>(data, 'projDesc'),
          'startDate': getParameter<DateTime>(data, 'startDate'),
          'endDate': getParameter<DateTime>(data, 'endDate'),
          'progress': getParameter<int>(data, 'progress'),
          'projOwn': getParameter<DocumentReference>(data, 'projOwn'),
          'ownername': getParameter<String>(data, 'ownername'),
          'parentOwn': getParameter<DocumentReference>(data, 'parentOwn'),
        },
      ),
  'DetailyyCopyOwner': (data) async => ParameterData(
        allParams: {
          'projectRef': getParameter<DocumentReference>(data, 'projectRef'),
          'projTitle': getParameter<String>(data, 'projTitle'),
          'planTitle': getParameter<String>(data, 'planTitle'),
          'planDesc': getParameter<String>(data, 'planDesc'),
          'startDate': getParameter<DateTime>(data, 'startDate'),
          'endTime': getParameter<DateTime>(data, 'endTime'),
          'planRef': getParameter<DocumentReference>(data, 'planRef'),
          'projMan': getParameter<DocumentReference>(data, 'projMan'),
          'owner': getParameter<DocumentReference>(data, 'owner'),
          'ownerName': getParameter<String>(data, 'ownerName'),
          'parentOwn': getParameter<DocumentReference>(data, 'parentOwn'),
        },
      ),
  'OBJYYowner': ParameterData.none(),
  'DASHYYowner': ParameterData.none(),
  'chatpag': (data) async => ParameterData(
        allParams: {
          'chatresc': getParameter<DocumentReference>(data, 'chatresc'),
        },
      ),
  'employeedash': ParameterData.none(),
  'Taskyyemployee': (data) async => ParameterData(
        allParams: {
          'tasktitle': getParameter<String>(data, 'tasktitle'),
        },
      ),
  'TaskyyemployeeCopy': (data) async => ParameterData(
        allParams: {
          'tasktitle': getParameter<String>(data, 'tasktitle'),
        },
      ),
  'OBJYYownerCopy': ParameterData.none(),
  'DetailyyyCopyCopy': (data) async => ParameterData(
        allParams: {
          'planTitle': getParameter<String>(data, 'planTitle'),
          'planDesc': getParameter<String>(data, 'planDesc'),
          'startDate': getParameter<DateTime>(data, 'startDate'),
          'endTime': getParameter<DateTime>(data, 'endTime'),
          'owner': getParameter<DocumentReference>(data, 'owner'),
          'ownerName': getParameter<String>(data, 'ownerName'),
          'planref': getParameter<DocumentReference>(data, 'planref'),
          'projectref': getParameter<DocumentReference>(data, 'projectref'),
          'projecttitl': getParameter<String>(data, 'projecttitl'),
        },
      ),
  'TaskyyCopy': (data) async => ParameterData(
        allParams: {
          'title': getParameter<String>(data, 'title'),
          'uploadeddoc': getParameter<String>(data, 'uploadeddoc'),
        },
      ),
  'progress': ParameterData.none(),
  'TaskyyCopy2': ParameterData.none(),
  'noti': ParameterData.none(),
  'Reportsemployee': ParameterData.none(),
  'progressemployee': ParameterData.none(),
  'employeeDashyyy': ParameterData.none(),
  'ChilObj': (data) async => ParameterData(
        allParams: {
          'projectRef': getParameter<DocumentReference>(data, 'projectRef'),
          'projTitle': getParameter<String>(data, 'projTitle'),
          'projDesc': getParameter<String>(data, 'projDesc'),
          'startDate': getParameter<DateTime>(data, 'startDate'),
          'endDate': getParameter<DateTime>(data, 'endDate'),
          'progress': getParameter<int>(data, 'progress'),
          'projOwn': getParameter<DocumentReference>(data, 'projOwn'),
          'ownername': getParameter<String>(data, 'ownername'),
          'parentOwn': getParameter<DocumentReference>(data, 'parentOwn'),
          'orgObj': getParameter<bool>(data, 'orgObj'),
          'type': getParameter<String>(data, 'type'),
          'weighatage': getParameter<int>(data, 'weighatage'),
          'status': getParameter<String>(data, 'status'),
        },
      ),
  'ManagerObjective': ParameterData.none(),
  'calendar': ParameterData.none(),
  'scheduletask': (data) async => ParameterData(
        allParams: {
          'taSK': getParameter<DocumentReference>(data, 'taSK'),
          'starttim': getParameter<DateTime>(data, 'starttim'),
          'endtime': getParameter<DateTime>(data, 'endtime'),
        },
      ),
  'taskProfilePage': (data) async => ParameterData(
        allParams: {
          'taskref': getParameter<DocumentReference>(data, 'taskref'),
          'title': getParameter<String>(data, 'title'),
          'desc': getParameter<String>(data, 'desc'),
          'start': getParameter<DateTime>(data, 'start'),
          'end': getParameter<DateTime>(data, 'end'),
        },
      ),
  'REVIEWPAGE': (data) async => ParameterData(
        allParams: {
          'title': getParameter<String>(data, 'title'),
          'uploadeddoc': getParameter<String>(data, 'uploadeddoc'),
        },
      ),
  'Reviewprofilepage': (data) async => ParameterData(
        allParams: {
          'taskname': getParameter<String>(data, 'taskname'),
          'taskdesc': getParameter<String>(data, 'taskdesc'),
          'priority': getParameter<String>(data, 'priority'),
          'created': getParameter<DateTime>(data, 'created'),
          'duedate': getParameter<DateTime>(data, 'duedate'),
          'assignedby': getParameter<String>(data, 'assignedby'),
          'status': getParameter<String>(data, 'status'),
          'assignedto': getParameter<String>(data, 'assignedto'),
          'taskref': getParameter<DocumentReference>(data, 'taskref'),
          'attachment': getParameter<String>(data, 'attachment'),
          'assignedbypic': getParameter<String>(data, 'assignedbypic'),
          'assignedtoimg': getParameter<String>(data, 'assignedtoimg'),
        },
      ),
  'Employeeprofile': ParameterData.none(),
  'AdminDashboard': ParameterData.none(),
  'DASHHYYYCopyCopy': ParameterData.none(),
  'EmployeeDashboard': ParameterData.none(),
  'ManagerDashboard': ParameterData.none(),
  'EmployeeeManagePage': ParameterData.none(),
  'EmpProfile': (data) async => ParameterData(
        allParams: {
          'empref': getParameter<DocumentReference>(data, 'empref'),
          'name': getParameter<String>(data, 'name'),
          'email': getParameter<String>(data, 'email'),
          'phobe': getParameter<String>(data, 'phobe'),
          'role': getParameter<String>(data, 'role'),
          'photourl': getParameter<String>(data, 'photourl'),
          'staffNumber': getParameter<String>(data, 'staffNumber'),
          'department': getParameter<String>(data, 'department'),
          'active': getParameter<bool>(data, 'active'),
          'reviewability': getParameter<bool>(data, 'reviewability'),
        },
      ),
  'ProfilePage': ParameterData.none(),
  'Adminprofile': (data) async => ParameterData(
        allParams: {
          'authenref': getParameter<DocumentReference>(data, 'authenref'),
        },
      ),
  'HRDashboard': ParameterData.none(),
  'taskAssignorPage': (data) async => ParameterData(
        allParams: {
          'taskref': getParameter<DocumentReference>(data, 'taskref'),
          'taskbame': getParameter<String>(data, 'taskbame'),
          'taskdesc': getParameter<String>(data, 'taskdesc'),
          'due': getParameter<DateTime>(data, 'due'),
          'assigneee': getParameter<DocumentReference>(data, 'assigneee'),
          'status': getParameter<String>(data, 'status'),
          'priority': getParameter<String>(data, 'priority'),
          'projReference':
              getParameter<DocumentReference>(data, 'projReference'),
          'taskAssigneeName': getParameter<String>(data, 'taskAssigneeName'),
          'reviewability': getParameter<bool>(data, 'reviewability'),
          'reviwername': getParameter<String>(data, 'reviwername'),
        },
      ),
  'ReportsAndAnalytics': ParameterData.none(),
  'PublicChildObj': (data) async => ParameterData(
        allParams: {
          'projectRef': getParameter<DocumentReference>(data, 'projectRef'),
          'projTitle': getParameter<String>(data, 'projTitle'),
          'projDesc': getParameter<String>(data, 'projDesc'),
          'startDate': getParameter<DateTime>(data, 'startDate'),
          'endDate': getParameter<DateTime>(data, 'endDate'),
          'progress': getParameter<int>(data, 'progress'),
          'projOwn': getParameter<DocumentReference>(data, 'projOwn'),
          'ownername': getParameter<String>(data, 'ownername'),
          'parentOwn': getParameter<DocumentReference>(data, 'parentOwn'),
          'orgObj': getParameter<bool>(data, 'orgObj'),
          'type': getParameter<String>(data, 'type'),
          'weightage': getParameter<int>(data, 'weightage'),
        },
      ),
  'TaskReview': ParameterData.none(),
  'TaskManagement': ParameterData.none(),
  'TaskyyCopy3': ParameterData.none(),
  'MyTaskPage': (data) async => ParameterData(
        allParams: {
          'taskref': getParameter<DocumentReference>(data, 'taskref'),
          'taskbame': getParameter<String>(data, 'taskbame'),
          'taskdesc': getParameter<String>(data, 'taskdesc'),
          'due': getParameter<DateTime>(data, 'due'),
          'assigneee': getParameter<DocumentReference>(data, 'assigneee'),
          'status': getParameter<String>(data, 'status'),
          'priority': getParameter<String>(data, 'priority'),
          'projReference':
              getParameter<DocumentReference>(data, 'projReference'),
          'taskAssigneeName': getParameter<String>(data, 'taskAssigneeName'),
          'reviewability': getParameter<bool>(data, 'reviewability'),
          'taskAssignedBy': getParameter<String>(data, 'taskAssignedBy'),
          'accept': getParameter<bool>(data, 'accept'),
        },
      ),
  'Mytask1': (data) async => ParameterData(
        allParams: {
          'taskref': getParameter<DocumentReference>(data, 'taskref'),
          'taskname': getParameter<String>(data, 'taskname'),
          'desc': getParameter<String>(data, 'desc'),
          'prior': getParameter<String>(data, 'prior'),
          'due': getParameter<DateTime>(data, 'due'),
          'reviewer': getParameter<String>(data, 'reviewer'),
        },
      ),
  'taskAssigneePage': (data) async => ParameterData(
        allParams: {
          'taskref': getParameter<DocumentReference>(data, 'taskref'),
          'taskbame': getParameter<String>(data, 'taskbame'),
          'taskdesc': getParameter<String>(data, 'taskdesc'),
          'due': getParameter<DateTime>(data, 'due'),
          'assigneee': getParameter<DocumentReference>(data, 'assigneee'),
          'status': getParameter<String>(data, 'status'),
          'priority': getParameter<String>(data, 'priority'),
          'projReference':
              getParameter<DocumentReference>(data, 'projReference'),
          'taskAssigneeName': getParameter<String>(data, 'taskAssigneeName'),
          'reviewability': getParameter<bool>(data, 'reviewability'),
          'reviwername': getParameter<String>(data, 'reviwername'),
        },
      ),
  'taskRevierPage': (data) async => ParameterData(
        allParams: {
          'taskref': getParameter<DocumentReference>(data, 'taskref'),
          'taskbame': getParameter<String>(data, 'taskbame'),
          'taskdesc': getParameter<String>(data, 'taskdesc'),
          'due': getParameter<DateTime>(data, 'due'),
          'assigneee': getParameter<DocumentReference>(data, 'assigneee'),
          'status': getParameter<String>(data, 'status'),
          'priority': getParameter<String>(data, 'priority'),
          'projReference':
              getParameter<DocumentReference>(data, 'projReference'),
          'taskAssigneeName': getParameter<String>(data, 'taskAssigneeName'),
          'reviewability': getParameter<bool>(data, 'reviewability'),
          'reviwername': getParameter<String>(data, 'reviwername'),
        },
      ),
  'JamBoard': ParameterData.none(),
  'JamBoard1': ParameterData.none(),
  'ScribbleProf': (data) async => ParameterData(
        allParams: {
          'scribble': getParameter<String>(data, 'scribble'),
          'notes': getParameter<String>(data, 'notes'),
          'jamRef': getParameter<DocumentReference>(data, 'jamRef'),
          'viewonly': getParameter<bool>(data, 'viewonly'),
        },
      ),
  'Managerobjphone': ParameterData.none(),
  'childobjphone': (data) async => ParameterData(
        allParams: {
          'projectRef': getParameter<DocumentReference>(data, 'projectRef'),
          'projTitle': getParameter<String>(data, 'projTitle'),
          'projDesc': getParameter<String>(data, 'projDesc'),
          'startDate': getParameter<DateTime>(data, 'startDate'),
          'endDate': getParameter<DateTime>(data, 'endDate'),
          'progress': getParameter<int>(data, 'progress'),
          'projOwn': getParameter<DocumentReference>(data, 'projOwn'),
          'ownername': getParameter<String>(data, 'ownername'),
          'parentOwn': getParameter<DocumentReference>(data, 'parentOwn'),
          'orgObj': getParameter<bool>(data, 'orgObj'),
          'type': getParameter<String>(data, 'type'),
          'weighatage': getParameter<int>(data, 'weighatage'),
        },
      ),
  'Objectivesphone': ParameterData.none(),
  'Managerobjphone2': ParameterData.none(),
  'Taskyyphn': ParameterData.none(),
  'taskAssigneephone': (data) async => ParameterData(
        allParams: {
          'taskref': getParameter<DocumentReference>(data, 'taskref'),
          'taskbame': getParameter<String>(data, 'taskbame'),
          'taskdesc': getParameter<String>(data, 'taskdesc'),
          'due': getParameter<DateTime>(data, 'due'),
          'assigneee': getParameter<DocumentReference>(data, 'assigneee'),
          'status': getParameter<String>(data, 'status'),
          'priority': getParameter<String>(data, 'priority'),
          'projReference':
              getParameter<DocumentReference>(data, 'projReference'),
          'taskAssigneeName': getParameter<String>(data, 'taskAssigneeName'),
          'reviewability': getParameter<bool>(data, 'reviewability'),
          'reviwername': getParameter<String>(data, 'reviwername'),
        },
      ),
  'ChilObjCopy': (data) async => ParameterData(
        allParams: {
          'projectRef': getParameter<DocumentReference>(data, 'projectRef'),
          'projTitle': getParameter<String>(data, 'projTitle'),
          'projDesc': getParameter<String>(data, 'projDesc'),
          'startDate': getParameter<DateTime>(data, 'startDate'),
          'endDate': getParameter<DateTime>(data, 'endDate'),
          'progress': getParameter<int>(data, 'progress'),
          'projOwn': getParameter<DocumentReference>(data, 'projOwn'),
          'ownername': getParameter<String>(data, 'ownername'),
          'parentOwn': getParameter<DocumentReference>(data, 'parentOwn'),
          'orgObj': getParameter<bool>(data, 'orgObj'),
          'type': getParameter<String>(data, 'type'),
          'weighatage': getParameter<int>(data, 'weighatage'),
        },
      ),
  'ManageUSersAdminPage': ParameterData.none(),
  'notiCopy': ParameterData.none(),
  'notificationPage': ParameterData.none(),
  'StaffDashboard': ParameterData.none(),
  'TaskyyCopy4': ParameterData.none(),
  'taskAssignorPageCopy': (data) async => ParameterData(
        allParams: {
          'taskref': getParameter<DocumentReference>(data, 'taskref'),
          'taskbame': getParameter<String>(data, 'taskbame'),
          'taskdesc': getParameter<String>(data, 'taskdesc'),
          'due': getParameter<DateTime>(data, 'due'),
          'assigneee': getParameter<DocumentReference>(data, 'assigneee'),
          'status': getParameter<String>(data, 'status'),
          'priority': getParameter<String>(data, 'priority'),
          'projReference':
              getParameter<DocumentReference>(data, 'projReference'),
          'taskAssigneeName': getParameter<String>(data, 'taskAssigneeName'),
          'reviewability': getParameter<bool>(data, 'reviewability'),
          'reviwername': getParameter<String>(data, 'reviwername'),
        },
      ),
  'trail': ParameterData.none(),
  'taskPhoneView': ParameterData.none(),
};

Map<String, dynamic> getInitialParameterData(Map<String, dynamic> data) {
  try {
    final parameterDataStr = data['parameterData'];
    if (parameterDataStr == null ||
        parameterDataStr is! String ||
        parameterDataStr.isEmpty) {
      return {};
    }
    return jsonDecode(parameterDataStr) as Map<String, dynamic>;
  } catch (e) {
    print('Error parsing parameter data: $e');
    return {};
  }
}
