import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ObjprochatRecord extends FirestoreRecord {
  ObjprochatRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  bool hasMessage() => _message != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "senderuid" field.
  DocumentReference? _senderuid;
  DocumentReference? get senderuid => _senderuid;
  bool hasSenderuid() => _senderuid != null;

  // "receivers" field.
  DocumentReference? _receivers;
  DocumentReference? get receivers => _receivers;
  bool hasReceivers() => _receivers != null;

  // "sendername" field.
  String? _sendername;
  String get sendername => _sendername ?? '';
  bool hasSendername() => _sendername != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _message = snapshotData['message'] as String?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _senderuid = snapshotData['senderuid'] as DocumentReference?;
    _receivers = snapshotData['receivers'] as DocumentReference?;
    _sendername = snapshotData['sendername'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('objprochat')
          : FirebaseFirestore.instance.collectionGroup('objprochat');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('objprochat').doc(id);

  static Stream<ObjprochatRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ObjprochatRecord.fromSnapshot(s));

  static Future<ObjprochatRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ObjprochatRecord.fromSnapshot(s));

  static ObjprochatRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ObjprochatRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ObjprochatRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ObjprochatRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ObjprochatRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ObjprochatRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createObjprochatRecordData({
  String? message,
  DateTime? timestamp,
  DocumentReference? senderuid,
  DocumentReference? receivers,
  String? sendername,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'message': message,
      'timestamp': timestamp,
      'senderuid': senderuid,
      'receivers': receivers,
      'sendername': sendername,
    }.withoutNulls,
  );

  return firestoreData;
}

class ObjprochatRecordDocumentEquality implements Equality<ObjprochatRecord> {
  const ObjprochatRecordDocumentEquality();

  @override
  bool equals(ObjprochatRecord? e1, ObjprochatRecord? e2) {
    return e1?.message == e2?.message &&
        e1?.timestamp == e2?.timestamp &&
        e1?.senderuid == e2?.senderuid &&
        e1?.receivers == e2?.receivers &&
        e1?.sendername == e2?.sendername;
  }

  @override
  int hash(ObjprochatRecord? e) => const ListEquality().hash(
      [e?.message, e?.timestamp, e?.senderuid, e?.receivers, e?.sendername]);

  @override
  bool isValidKey(Object? o) => o is ObjprochatRecord;
}
