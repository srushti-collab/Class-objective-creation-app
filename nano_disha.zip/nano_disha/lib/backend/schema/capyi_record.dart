import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CapyiRecord extends FirestoreRecord {
  CapyiRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "comments" field.
  String? _comments;
  String get comments => _comments ?? '';
  bool hasComments() => _comments != null;

  // "created" field.
  DateTime? _created;
  DateTime? get created => _created;
  bool hasCreated() => _created != null;

  // "commentersname" field.
  String? _commentersname;
  String get commentersname => _commentersname ?? '';
  bool hasCommentersname() => _commentersname != null;

  // "chat" field.
  List<DocumentReference>? _chat;
  List<DocumentReference> get chat => _chat ?? const [];
  bool hasChat() => _chat != null;

  // "img" field.
  String? _img;
  String get img => _img ?? '';
  bool hasImg() => _img != null;

  // "tasks" field.
  DocumentReference? _tasks;
  DocumentReference? get tasks => _tasks;
  bool hasTasks() => _tasks != null;

  // "taskid" field.
  String? _taskid;
  String get taskid => _taskid ?? '';
  bool hasTaskid() => _taskid != null;

  // "receiver" field.
  DocumentReference? _receiver;
  DocumentReference? get receiver => _receiver;
  bool hasReceiver() => _receiver != null;

  // "senderid" field.
  String? _senderid;
  String get senderid => _senderid ?? '';
  bool hasSenderid() => _senderid != null;

  // "uploadeddoc" field.
  String? _uploadeddoc;
  String get uploadeddoc => _uploadeddoc ?? '';
  bool hasUploadeddoc() => _uploadeddoc != null;

  // "Attachment" field.
  String? _attachment;
  String get attachment => _attachment ?? '';
  bool hasAttachment() => _attachment != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _comments = snapshotData['comments'] as String?;
    _created = snapshotData['created'] as DateTime?;
    _commentersname = snapshotData['commentersname'] as String?;
    _chat = getDataList(snapshotData['chat']);
    _img = snapshotData['img'] as String?;
    _tasks = snapshotData['tasks'] as DocumentReference?;
    _taskid = snapshotData['taskid'] as String?;
    _receiver = snapshotData['receiver'] as DocumentReference?;
    _senderid = snapshotData['senderid'] as String?;
    _uploadeddoc = snapshotData['uploadeddoc'] as String?;
    _attachment = snapshotData['Attachment'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('capyi')
          : FirebaseFirestore.instance.collectionGroup('capyi');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('capyi').doc(id);

  static Stream<CapyiRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CapyiRecord.fromSnapshot(s));

  static Future<CapyiRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CapyiRecord.fromSnapshot(s));

  static CapyiRecord fromSnapshot(DocumentSnapshot snapshot) => CapyiRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CapyiRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CapyiRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CapyiRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CapyiRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCapyiRecordData({
  String? comments,
  DateTime? created,
  String? commentersname,
  String? img,
  DocumentReference? tasks,
  String? taskid,
  DocumentReference? receiver,
  String? senderid,
  String? uploadeddoc,
  String? attachment,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'comments': comments,
      'created': created,
      'commentersname': commentersname,
      'img': img,
      'tasks': tasks,
      'taskid': taskid,
      'receiver': receiver,
      'senderid': senderid,
      'uploadeddoc': uploadeddoc,
      'Attachment': attachment,
    }.withoutNulls,
  );

  return firestoreData;
}

class CapyiRecordDocumentEquality implements Equality<CapyiRecord> {
  const CapyiRecordDocumentEquality();

  @override
  bool equals(CapyiRecord? e1, CapyiRecord? e2) {
    const listEquality = ListEquality();
    return e1?.comments == e2?.comments &&
        e1?.created == e2?.created &&
        e1?.commentersname == e2?.commentersname &&
        listEquality.equals(e1?.chat, e2?.chat) &&
        e1?.img == e2?.img &&
        e1?.tasks == e2?.tasks &&
        e1?.taskid == e2?.taskid &&
        e1?.receiver == e2?.receiver &&
        e1?.senderid == e2?.senderid &&
        e1?.uploadeddoc == e2?.uploadeddoc &&
        e1?.attachment == e2?.attachment;
  }

  @override
  int hash(CapyiRecord? e) => const ListEquality().hash([
        e?.comments,
        e?.created,
        e?.commentersname,
        e?.chat,
        e?.img,
        e?.tasks,
        e?.taskid,
        e?.receiver,
        e?.senderid,
        e?.uploadeddoc,
        e?.attachment
      ]);

  @override
  bool isValidKey(Object? o) => o is CapyiRecord;
}
