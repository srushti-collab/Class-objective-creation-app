import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PlansRecord extends FirestoreRecord {
  PlansRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "desc" field.
  String? _desc;
  String get desc => _desc ?? '';
  bool hasDesc() => _desc != null;

  // "due_date" field.
  DateTime? _dueDate;
  DateTime? get dueDate => _dueDate;
  bool hasDueDate() => _dueDate != null;

  // "project_ref" field.
  DocumentReference? _projectRef;
  DocumentReference? get projectRef => _projectRef;
  bool hasProjectRef() => _projectRef != null;

  // "parent_plan" field.
  DocumentReference? _parentPlan;
  DocumentReference? get parentPlan => _parentPlan;
  bool hasParentPlan() => _parentPlan != null;

  // "sub_plans" field.
  List<String>? _subPlans;
  List<String> get subPlans => _subPlans ?? const [];
  bool hasSubPlans() => _subPlans != null;

  // "SubPlan" field.
  bool? _subPlan;
  bool get subPlan => _subPlan ?? false;
  bool hasSubPlan() => _subPlan != null;

  // "task" field.
  bool? _task;
  bool get task => _task ?? false;
  bool hasTask() => _task != null;

  // "planID" field.
  String? _planID;
  String get planID => _planID ?? '';
  bool hasPlanID() => _planID != null;

  // "Progress" field.
  int? _progress;
  int get progress => _progress ?? 0;
  bool hasProgress() => _progress != null;

  // "Status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "underOBJ" field.
  bool? _underOBJ;
  bool get underOBJ => _underOBJ ?? false;
  bool hasUnderOBJ() => _underOBJ != null;

  // "startDate" field.
  DateTime? _startDate;
  DateTime? get startDate => _startDate;
  bool hasStartDate() => _startDate != null;

  // "assignedManager" field.
  DocumentReference? _assignedManager;
  DocumentReference? get assignedManager => _assignedManager;
  bool hasAssignedManager() => _assignedManager != null;

  // "owner" field.
  DocumentReference? _owner;
  DocumentReference? get owner => _owner;
  bool hasOwner() => _owner != null;

  // "ownerName" field.
  String? _ownerName;
  String get ownerName => _ownerName ?? '';
  bool hasOwnerName() => _ownerName != null;

  // "parentOwner" field.
  DocumentReference? _parentOwner;
  DocumentReference? get parentOwner => _parentOwner;
  bool hasParentOwner() => _parentOwner != null;

  // "startdate" field.
  DateTime? _startdate;
  DateTime? get startdate => _startdate;
  bool hasStartdate() => _startdate != null;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
    _desc = snapshotData['desc'] as String?;
    _dueDate = snapshotData['due_date'] as DateTime?;
    _projectRef = snapshotData['project_ref'] as DocumentReference?;
    _parentPlan = snapshotData['parent_plan'] as DocumentReference?;
    _subPlans = getDataList(snapshotData['sub_plans']);
    _subPlan = snapshotData['SubPlan'] as bool?;
    _task = snapshotData['task'] as bool?;
    _planID = snapshotData['planID'] as String?;
    _progress = castToType<int>(snapshotData['Progress']);
    _status = snapshotData['Status'] as String?;
    _underOBJ = snapshotData['underOBJ'] as bool?;
    _startDate = snapshotData['startDate'] as DateTime?;
    _assignedManager = snapshotData['assignedManager'] as DocumentReference?;
    _owner = snapshotData['owner'] as DocumentReference?;
    _ownerName = snapshotData['ownerName'] as String?;
    _parentOwner = snapshotData['parentOwner'] as DocumentReference?;
    _startdate = snapshotData['startdate'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('plans');

  static Stream<PlansRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PlansRecord.fromSnapshot(s));

  static Future<PlansRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PlansRecord.fromSnapshot(s));

  static PlansRecord fromSnapshot(DocumentSnapshot snapshot) => PlansRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PlansRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PlansRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PlansRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PlansRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPlansRecordData({
  String? title,
  String? desc,
  DateTime? dueDate,
  DocumentReference? projectRef,
  DocumentReference? parentPlan,
  bool? subPlan,
  bool? task,
  String? planID,
  int? progress,
  String? status,
  bool? underOBJ,
  DateTime? startDate,
  DocumentReference? assignedManager,
  DocumentReference? owner,
  String? ownerName,
  DocumentReference? parentOwner,
  DateTime? startdate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
      'desc': desc,
      'due_date': dueDate,
      'project_ref': projectRef,
      'parent_plan': parentPlan,
      'SubPlan': subPlan,
      'task': task,
      'planID': planID,
      'Progress': progress,
      'Status': status,
      'underOBJ': underOBJ,
      'startDate': startDate,
      'assignedManager': assignedManager,
      'owner': owner,
      'ownerName': ownerName,
      'parentOwner': parentOwner,
      'startdate': startdate,
    }.withoutNulls,
  );

  return firestoreData;
}

class PlansRecordDocumentEquality implements Equality<PlansRecord> {
  const PlansRecordDocumentEquality();

  @override
  bool equals(PlansRecord? e1, PlansRecord? e2) {
    const listEquality = ListEquality();
    return e1?.title == e2?.title &&
        e1?.desc == e2?.desc &&
        e1?.dueDate == e2?.dueDate &&
        e1?.projectRef == e2?.projectRef &&
        e1?.parentPlan == e2?.parentPlan &&
        listEquality.equals(e1?.subPlans, e2?.subPlans) &&
        e1?.subPlan == e2?.subPlan &&
        e1?.task == e2?.task &&
        e1?.planID == e2?.planID &&
        e1?.progress == e2?.progress &&
        e1?.status == e2?.status &&
        e1?.underOBJ == e2?.underOBJ &&
        e1?.startDate == e2?.startDate &&
        e1?.assignedManager == e2?.assignedManager &&
        e1?.owner == e2?.owner &&
        e1?.ownerName == e2?.ownerName &&
        e1?.parentOwner == e2?.parentOwner &&
        e1?.startdate == e2?.startdate;
  }

  @override
  int hash(PlansRecord? e) => const ListEquality().hash([
        e?.title,
        e?.desc,
        e?.dueDate,
        e?.projectRef,
        e?.parentPlan,
        e?.subPlans,
        e?.subPlan,
        e?.task,
        e?.planID,
        e?.progress,
        e?.status,
        e?.underOBJ,
        e?.startDate,
        e?.assignedManager,
        e?.owner,
        e?.ownerName,
        e?.parentOwner,
        e?.startdate
      ]);

  @override
  bool isValidKey(Object? o) => o is PlansRecord;
}
