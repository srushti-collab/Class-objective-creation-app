import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RepetativetaskRecord extends FirestoreRecord {
  RepetativetaskRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "starttime" field.
  DateTime? _starttime;
  DateTime? get starttime => _starttime;
  bool hasStarttime() => _starttime != null;

  // "endtime" field.
  DateTime? _endtime;
  DateTime? get endtime => _endtime;
  bool hasEndtime() => _endtime != null;

  // "daily" field.
  bool? _daily;
  bool get daily => _daily ?? false;
  bool hasDaily() => _daily != null;

  // "weekly" field.
  bool? _weekly;
  bool get weekly => _weekly ?? false;
  bool hasWeekly() => _weekly != null;

  // "monthly" field.
  bool? _monthly;
  bool get monthly => _monthly ?? false;
  bool hasMonthly() => _monthly != null;

  // "repeateuntill" field.
  DateTime? _repeateuntill;
  DateTime? get repeateuntill => _repeateuntill;
  bool hasRepeateuntill() => _repeateuntill != null;

  // "completed" field.
  bool? _completed;
  bool get completed => _completed ?? false;
  bool hasCompleted() => _completed != null;

  // "task_titl" field.
  String? _taskTitl;
  String get taskTitl => _taskTitl ?? '';
  bool hasTaskTitl() => _taskTitl != null;

  // "task_desc" field.
  String? _taskDesc;
  String get taskDesc => _taskDesc ?? '';
  bool hasTaskDesc() => _taskDesc != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _starttime = snapshotData['starttime'] as DateTime?;
    _endtime = snapshotData['endtime'] as DateTime?;
    _daily = snapshotData['daily'] as bool?;
    _weekly = snapshotData['weekly'] as bool?;
    _monthly = snapshotData['monthly'] as bool?;
    _repeateuntill = snapshotData['repeateuntill'] as DateTime?;
    _completed = snapshotData['completed'] as bool?;
    _taskTitl = snapshotData['task_titl'] as String?;
    _taskDesc = snapshotData['task_desc'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('repetativetask')
          : FirebaseFirestore.instance.collectionGroup('repetativetask');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('repetativetask').doc(id);

  static Stream<RepetativetaskRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RepetativetaskRecord.fromSnapshot(s));

  static Future<RepetativetaskRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RepetativetaskRecord.fromSnapshot(s));

  static RepetativetaskRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RepetativetaskRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RepetativetaskRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RepetativetaskRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RepetativetaskRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RepetativetaskRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRepetativetaskRecordData({
  DateTime? starttime,
  DateTime? endtime,
  bool? daily,
  bool? weekly,
  bool? monthly,
  DateTime? repeateuntill,
  bool? completed,
  String? taskTitl,
  String? taskDesc,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'starttime': starttime,
      'endtime': endtime,
      'daily': daily,
      'weekly': weekly,
      'monthly': monthly,
      'repeateuntill': repeateuntill,
      'completed': completed,
      'task_titl': taskTitl,
      'task_desc': taskDesc,
    }.withoutNulls,
  );

  return firestoreData;
}

class RepetativetaskRecordDocumentEquality
    implements Equality<RepetativetaskRecord> {
  const RepetativetaskRecordDocumentEquality();

  @override
  bool equals(RepetativetaskRecord? e1, RepetativetaskRecord? e2) {
    return e1?.starttime == e2?.starttime &&
        e1?.endtime == e2?.endtime &&
        e1?.daily == e2?.daily &&
        e1?.weekly == e2?.weekly &&
        e1?.monthly == e2?.monthly &&
        e1?.repeateuntill == e2?.repeateuntill &&
        e1?.completed == e2?.completed &&
        e1?.taskTitl == e2?.taskTitl &&
        e1?.taskDesc == e2?.taskDesc;
  }

  @override
  int hash(RepetativetaskRecord? e) => const ListEquality().hash([
        e?.starttime,
        e?.endtime,
        e?.daily,
        e?.weekly,
        e?.monthly,
        e?.repeateuntill,
        e?.completed,
        e?.taskTitl,
        e?.taskDesc
      ]);

  @override
  bool isValidKey(Object? o) => o is RepetativetaskRecord;
}
