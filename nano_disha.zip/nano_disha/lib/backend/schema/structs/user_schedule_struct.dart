// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserScheduleStruct extends FFFirebaseStruct {
  UserScheduleStruct({
    List<DateTime>? startTime,
    List<DateTime>? endTime,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _startTime = startTime,
        _endTime = endTime,
        super(firestoreUtilData);

  // "startTime" field.
  List<DateTime>? _startTime;
  List<DateTime> get startTime => _startTime ?? const [];
  set startTime(List<DateTime>? val) => _startTime = val;

  void updateStartTime(Function(List<DateTime>) updateFn) {
    updateFn(_startTime ??= []);
  }

  bool hasStartTime() => _startTime != null;

  // "endTime" field.
  List<DateTime>? _endTime;
  List<DateTime> get endTime => _endTime ?? const [];
  set endTime(List<DateTime>? val) => _endTime = val;

  void updateEndTime(Function(List<DateTime>) updateFn) {
    updateFn(_endTime ??= []);
  }

  bool hasEndTime() => _endTime != null;

  static UserScheduleStruct fromMap(Map<String, dynamic> data) =>
      UserScheduleStruct(
        startTime: getDataList(data['startTime']),
        endTime: getDataList(data['endTime']),
      );

  static UserScheduleStruct? maybeFromMap(dynamic data) => data is Map
      ? UserScheduleStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'startTime': _startTime,
        'endTime': _endTime,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'startTime': serializeParam(
          _startTime,
          ParamType.DateTime,
          isList: true,
        ),
        'endTime': serializeParam(
          _endTime,
          ParamType.DateTime,
          isList: true,
        ),
      }.withoutNulls;

  static UserScheduleStruct fromSerializableMap(Map<String, dynamic> data) =>
      UserScheduleStruct(
        startTime: deserializeParam<DateTime>(
          data['startTime'],
          ParamType.DateTime,
          true,
        ),
        endTime: deserializeParam<DateTime>(
          data['endTime'],
          ParamType.DateTime,
          true,
        ),
      );

  @override
  String toString() => 'UserScheduleStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is UserScheduleStruct &&
        listEquality.equals(startTime, other.startTime) &&
        listEquality.equals(endTime, other.endTime);
  }

  @override
  int get hashCode => const ListEquality().hash([startTime, endTime]);
}

UserScheduleStruct createUserScheduleStruct({
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    UserScheduleStruct(
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

UserScheduleStruct? updateUserScheduleStruct(
  UserScheduleStruct? userSchedule, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    userSchedule
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addUserScheduleStructData(
  Map<String, dynamic> firestoreData,
  UserScheduleStruct? userSchedule,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (userSchedule == null) {
    return;
  }
  if (userSchedule.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && userSchedule.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final userScheduleData =
      getUserScheduleFirestoreData(userSchedule, forFieldValue);
  final nestedData =
      userScheduleData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = userSchedule.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getUserScheduleFirestoreData(
  UserScheduleStruct? userSchedule, [
  bool forFieldValue = false,
]) {
  if (userSchedule == null) {
    return {};
  }
  final firestoreData = mapToFirestore(userSchedule.toMap());

  // Add any Firestore field values
  userSchedule.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getUserScheduleListFirestoreData(
  List<UserScheduleStruct>? userSchedules,
) =>
    userSchedules?.map((e) => getUserScheduleFirestoreData(e, true)).toList() ??
    [];
