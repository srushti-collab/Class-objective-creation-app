// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AttachmentsStruct extends FFFirebaseStruct {
  AttachmentsStruct({
    String? fileURL,
    String? fileName,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _fileURL = fileURL,
        _fileName = fileName,
        super(firestoreUtilData);

  // "FileURL" field.
  String? _fileURL;
  String get fileURL => _fileURL ?? '';
  set fileURL(String? val) => _fileURL = val;

  bool hasFileURL() => _fileURL != null;

  // "FileName" field.
  String? _fileName;
  String get fileName => _fileName ?? '';
  set fileName(String? val) => _fileName = val;

  bool hasFileName() => _fileName != null;

  static AttachmentsStruct fromMap(Map<String, dynamic> data) =>
      AttachmentsStruct(
        fileURL: data['FileURL'] as String?,
        fileName: data['FileName'] as String?,
      );

  static AttachmentsStruct? maybeFromMap(dynamic data) => data is Map
      ? AttachmentsStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'FileURL': _fileURL,
        'FileName': _fileName,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'FileURL': serializeParam(
          _fileURL,
          ParamType.String,
        ),
        'FileName': serializeParam(
          _fileName,
          ParamType.String,
        ),
      }.withoutNulls;

  static AttachmentsStruct fromSerializableMap(Map<String, dynamic> data) =>
      AttachmentsStruct(
        fileURL: deserializeParam(
          data['FileURL'],
          ParamType.String,
          false,
        ),
        fileName: deserializeParam(
          data['FileName'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'AttachmentsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is AttachmentsStruct &&
        fileURL == other.fileURL &&
        fileName == other.fileName;
  }

  @override
  int get hashCode => const ListEquality().hash([fileURL, fileName]);
}

AttachmentsStruct createAttachmentsStruct({
  String? fileURL,
  String? fileName,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    AttachmentsStruct(
      fileURL: fileURL,
      fileName: fileName,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

AttachmentsStruct? updateAttachmentsStruct(
  AttachmentsStruct? attachments, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    attachments
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addAttachmentsStructData(
  Map<String, dynamic> firestoreData,
  AttachmentsStruct? attachments,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (attachments == null) {
    return;
  }
  if (attachments.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && attachments.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final attachmentsData =
      getAttachmentsFirestoreData(attachments, forFieldValue);
  final nestedData =
      attachmentsData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = attachments.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getAttachmentsFirestoreData(
  AttachmentsStruct? attachments, [
  bool forFieldValue = false,
]) {
  if (attachments == null) {
    return {};
  }
  final firestoreData = mapToFirestore(attachments.toMap());

  // Add any Firestore field values
  attachments.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getAttachmentsListFirestoreData(
  List<AttachmentsStruct>? attachmentss,
) =>
    attachmentss?.map((e) => getAttachmentsFirestoreData(e, true)).toList() ??
    [];
