// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SubObjectivesStruct extends FFFirebaseStruct {
  SubObjectivesStruct({
    String? title,
    String? description,
    int? progress,
    String? status,
    List<TaskStruct>? task,
    DocumentReference? createdBy,
    List<SubObjectivesStruct>? subObj,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _title = title,
        _description = description,
        _progress = progress,
        _status = status,
        _task = task,
        _createdBy = createdBy,
        _subObj = subObj,
        super(firestoreUtilData);

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  set title(String? val) => _title = val;

  bool hasTitle() => _title != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  set description(String? val) => _description = val;

  bool hasDescription() => _description != null;

  // "progress" field.
  int? _progress;
  int get progress => _progress ?? 0;
  set progress(int? val) => _progress = val;

  void incrementProgress(int amount) => progress = progress + amount;

  bool hasProgress() => _progress != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  set status(String? val) => _status = val;

  bool hasStatus() => _status != null;

  // "task" field.
  List<TaskStruct>? _task;
  List<TaskStruct> get task => _task ?? const [];
  set task(List<TaskStruct>? val) => _task = val;

  void updateTask(Function(List<TaskStruct>) updateFn) {
    updateFn(_task ??= []);
  }

  bool hasTask() => _task != null;

  // "createdBy" field.
  DocumentReference? _createdBy;
  DocumentReference? get createdBy => _createdBy;
  set createdBy(DocumentReference? val) => _createdBy = val;

  bool hasCreatedBy() => _createdBy != null;

  // "subObj" field.
  List<SubObjectivesStruct>? _subObj;
  List<SubObjectivesStruct> get subObj => _subObj ?? const [];
  set subObj(List<SubObjectivesStruct>? val) => _subObj = val;

  void updateSubObj(Function(List<SubObjectivesStruct>) updateFn) {
    updateFn(_subObj ??= []);
  }

  bool hasSubObj() => _subObj != null;

  static SubObjectivesStruct fromMap(Map<String, dynamic> data) =>
      SubObjectivesStruct(
        title: data['title'] as String?,
        description: data['description'] as String?,
        progress: castToType<int>(data['progress']),
        status: data['status'] as String?,
        task: getStructList(
          data['task'],
          TaskStruct.fromMap,
        ),
        createdBy: data['createdBy'] as DocumentReference?,
        subObj: getStructList(
          data['subObj'],
          SubObjectivesStruct.fromMap,
        ),
      );

  static SubObjectivesStruct? maybeFromMap(dynamic data) => data is Map
      ? SubObjectivesStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'title': _title,
        'description': _description,
        'progress': _progress,
        'status': _status,
        'task': _task?.map((e) => e.toMap()).toList(),
        'createdBy': _createdBy,
        'subObj': _subObj?.map((e) => e.toMap()).toList(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'title': serializeParam(
          _title,
          ParamType.String,
        ),
        'description': serializeParam(
          _description,
          ParamType.String,
        ),
        'progress': serializeParam(
          _progress,
          ParamType.int,
        ),
        'status': serializeParam(
          _status,
          ParamType.String,
        ),
        'task': serializeParam(
          _task,
          ParamType.DataStruct,
          isList: true,
        ),
        'createdBy': serializeParam(
          _createdBy,
          ParamType.DocumentReference,
        ),
        'subObj': serializeParam(
          _subObj,
          ParamType.DataStruct,
          isList: true,
        ),
      }.withoutNulls;

  static SubObjectivesStruct fromSerializableMap(Map<String, dynamic> data) =>
      SubObjectivesStruct(
        title: deserializeParam(
          data['title'],
          ParamType.String,
          false,
        ),
        description: deserializeParam(
          data['description'],
          ParamType.String,
          false,
        ),
        progress: deserializeParam(
          data['progress'],
          ParamType.int,
          false,
        ),
        status: deserializeParam(
          data['status'],
          ParamType.String,
          false,
        ),
        task: deserializeStructParam<TaskStruct>(
          data['task'],
          ParamType.DataStruct,
          true,
          structBuilder: TaskStruct.fromSerializableMap,
        ),
        createdBy: deserializeParam(
          data['createdBy'],
          ParamType.DocumentReference,
          false,
          collectionNamePath: ['users'],
        ),
        subObj: deserializeStructParam<SubObjectivesStruct>(
          data['subObj'],
          ParamType.DataStruct,
          true,
          structBuilder: SubObjectivesStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'SubObjectivesStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is SubObjectivesStruct &&
        title == other.title &&
        description == other.description &&
        progress == other.progress &&
        status == other.status &&
        listEquality.equals(task, other.task) &&
        createdBy == other.createdBy &&
        listEquality.equals(subObj, other.subObj);
  }

  @override
  int get hashCode => const ListEquality()
      .hash([title, description, progress, status, task, createdBy, subObj]);
}

SubObjectivesStruct createSubObjectivesStruct({
  String? title,
  String? description,
  int? progress,
  String? status,
  DocumentReference? createdBy,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    SubObjectivesStruct(
      title: title,
      description: description,
      progress: progress,
      status: status,
      createdBy: createdBy,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

SubObjectivesStruct? updateSubObjectivesStruct(
  SubObjectivesStruct? subObjectives, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    subObjectives
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addSubObjectivesStructData(
  Map<String, dynamic> firestoreData,
  SubObjectivesStruct? subObjectives,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (subObjectives == null) {
    return;
  }
  if (subObjectives.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && subObjectives.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final subObjectivesData =
      getSubObjectivesFirestoreData(subObjectives, forFieldValue);
  final nestedData =
      subObjectivesData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = subObjectives.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getSubObjectivesFirestoreData(
  SubObjectivesStruct? subObjectives, [
  bool forFieldValue = false,
]) {
  if (subObjectives == null) {
    return {};
  }
  final firestoreData = mapToFirestore(subObjectives.toMap());

  // Add any Firestore field values
  subObjectives.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getSubObjectivesListFirestoreData(
  List<SubObjectivesStruct>? subObjectivess,
) =>
    subObjectivess
        ?.map((e) => getSubObjectivesFirestoreData(e, true))
        .toList() ??
    [];
