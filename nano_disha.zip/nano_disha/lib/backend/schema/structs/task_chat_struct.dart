// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TaskChatStruct extends FFFirebaseStruct {
  TaskChatStruct({
    String? displayName,
    String? message,
    DateTime? time,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _displayName = displayName,
        _message = message,
        _time = time,
        super(firestoreUtilData);

  // "displayName" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  set displayName(String? val) => _displayName = val;

  bool hasDisplayName() => _displayName != null;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  set message(String? val) => _message = val;

  bool hasMessage() => _message != null;

  // "time" field.
  DateTime? _time;
  DateTime? get time => _time;
  set time(DateTime? val) => _time = val;

  bool hasTime() => _time != null;

  static TaskChatStruct fromMap(Map<String, dynamic> data) => TaskChatStruct(
        displayName: data['displayName'] as String?,
        message: data['message'] as String?,
        time: data['time'] as DateTime?,
      );

  static TaskChatStruct? maybeFromMap(dynamic data) =>
      data is Map ? TaskChatStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'displayName': _displayName,
        'message': _message,
        'time': _time,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'displayName': serializeParam(
          _displayName,
          ParamType.String,
        ),
        'message': serializeParam(
          _message,
          ParamType.String,
        ),
        'time': serializeParam(
          _time,
          ParamType.DateTime,
        ),
      }.withoutNulls;

  static TaskChatStruct fromSerializableMap(Map<String, dynamic> data) =>
      TaskChatStruct(
        displayName: deserializeParam(
          data['displayName'],
          ParamType.String,
          false,
        ),
        message: deserializeParam(
          data['message'],
          ParamType.String,
          false,
        ),
        time: deserializeParam(
          data['time'],
          ParamType.DateTime,
          false,
        ),
      );

  @override
  String toString() => 'TaskChatStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is TaskChatStruct &&
        displayName == other.displayName &&
        message == other.message &&
        time == other.time;
  }

  @override
  int get hashCode => const ListEquality().hash([displayName, message, time]);
}

TaskChatStruct createTaskChatStruct({
  String? displayName,
  String? message,
  DateTime? time,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    TaskChatStruct(
      displayName: displayName,
      message: message,
      time: time,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

TaskChatStruct? updateTaskChatStruct(
  TaskChatStruct? taskChat, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    taskChat
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addTaskChatStructData(
  Map<String, dynamic> firestoreData,
  TaskChatStruct? taskChat,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (taskChat == null) {
    return;
  }
  if (taskChat.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && taskChat.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final taskChatData = getTaskChatFirestoreData(taskChat, forFieldValue);
  final nestedData = taskChatData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = taskChat.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getTaskChatFirestoreData(
  TaskChatStruct? taskChat, [
  bool forFieldValue = false,
]) {
  if (taskChat == null) {
    return {};
  }
  final firestoreData = mapToFirestore(taskChat.toMap());

  // Add any Firestore field values
  taskChat.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getTaskChatListFirestoreData(
  List<TaskChatStruct>? taskChats,
) =>
    taskChats?.map((e) => getTaskChatFirestoreData(e, true)).toList() ?? [];
