// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ObjectiveNotesStruct extends FFFirebaseStruct {
  ObjectiveNotesStruct({
    String? note,
    DateTime? timestamp,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _note = note,
        _timestamp = timestamp,
        super(firestoreUtilData);

  // "note" field.
  String? _note;
  String get note => _note ?? '';
  set note(String? val) => _note = val;

  bool hasNote() => _note != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  set timestamp(DateTime? val) => _timestamp = val;

  bool hasTimestamp() => _timestamp != null;

  static ObjectiveNotesStruct fromMap(Map<String, dynamic> data) =>
      ObjectiveNotesStruct(
        note: data['note'] as String?,
        timestamp: data['timestamp'] as DateTime?,
      );

  static ObjectiveNotesStruct? maybeFromMap(dynamic data) => data is Map
      ? ObjectiveNotesStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'note': _note,
        'timestamp': _timestamp,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'note': serializeParam(
          _note,
          ParamType.String,
        ),
        'timestamp': serializeParam(
          _timestamp,
          ParamType.DateTime,
        ),
      }.withoutNulls;

  static ObjectiveNotesStruct fromSerializableMap(Map<String, dynamic> data) =>
      ObjectiveNotesStruct(
        note: deserializeParam(
          data['note'],
          ParamType.String,
          false,
        ),
        timestamp: deserializeParam(
          data['timestamp'],
          ParamType.DateTime,
          false,
        ),
      );

  @override
  String toString() => 'ObjectiveNotesStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is ObjectiveNotesStruct &&
        note == other.note &&
        timestamp == other.timestamp;
  }

  @override
  int get hashCode => const ListEquality().hash([note, timestamp]);
}

ObjectiveNotesStruct createObjectiveNotesStruct({
  String? note,
  DateTime? timestamp,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    ObjectiveNotesStruct(
      note: note,
      timestamp: timestamp,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

ObjectiveNotesStruct? updateObjectiveNotesStruct(
  ObjectiveNotesStruct? objectiveNotes, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    objectiveNotes
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addObjectiveNotesStructData(
  Map<String, dynamic> firestoreData,
  ObjectiveNotesStruct? objectiveNotes,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (objectiveNotes == null) {
    return;
  }
  if (objectiveNotes.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && objectiveNotes.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final objectiveNotesData =
      getObjectiveNotesFirestoreData(objectiveNotes, forFieldValue);
  final nestedData =
      objectiveNotesData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = objectiveNotes.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getObjectiveNotesFirestoreData(
  ObjectiveNotesStruct? objectiveNotes, [
  bool forFieldValue = false,
]) {
  if (objectiveNotes == null) {
    return {};
  }
  final firestoreData = mapToFirestore(objectiveNotes.toMap());

  // Add any Firestore field values
  objectiveNotes.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getObjectiveNotesListFirestoreData(
  List<ObjectiveNotesStruct>? objectiveNotess,
) =>
    objectiveNotess
        ?.map((e) => getObjectiveNotesFirestoreData(e, true))
        .toList() ??
    [];
