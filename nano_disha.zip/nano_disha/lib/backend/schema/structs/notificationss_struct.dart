// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class NotificationssStruct extends FFFirebaseStruct {
  NotificationssStruct({
    String? message,
    String? type,
    bool? read,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _message = message,
        _type = type,
        _read = read,
        super(firestoreUtilData);

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  set message(String? val) => _message = val;

  bool hasMessage() => _message != null;

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  set type(String? val) => _type = val;

  bool hasType() => _type != null;

  // "read" field.
  bool? _read;
  bool get read => _read ?? false;
  set read(bool? val) => _read = val;

  bool hasRead() => _read != null;

  static NotificationssStruct fromMap(Map<String, dynamic> data) =>
      NotificationssStruct(
        message: data['message'] as String?,
        type: data['type'] as String?,
        read: data['read'] as bool?,
      );

  static NotificationssStruct? maybeFromMap(dynamic data) => data is Map
      ? NotificationssStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'message': _message,
        'type': _type,
        'read': _read,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'message': serializeParam(
          _message,
          ParamType.String,
        ),
        'type': serializeParam(
          _type,
          ParamType.String,
        ),
        'read': serializeParam(
          _read,
          ParamType.bool,
        ),
      }.withoutNulls;

  static NotificationssStruct fromSerializableMap(Map<String, dynamic> data) =>
      NotificationssStruct(
        message: deserializeParam(
          data['message'],
          ParamType.String,
          false,
        ),
        type: deserializeParam(
          data['type'],
          ParamType.String,
          false,
        ),
        read: deserializeParam(
          data['read'],
          ParamType.bool,
          false,
        ),
      );

  @override
  String toString() => 'NotificationssStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is NotificationssStruct &&
        message == other.message &&
        type == other.type &&
        read == other.read;
  }

  @override
  int get hashCode => const ListEquality().hash([message, type, read]);
}

NotificationssStruct createNotificationssStruct({
  String? message,
  String? type,
  bool? read,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    NotificationssStruct(
      message: message,
      type: type,
      read: read,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

NotificationssStruct? updateNotificationssStruct(
  NotificationssStruct? notificationss, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    notificationss
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addNotificationssStructData(
  Map<String, dynamic> firestoreData,
  NotificationssStruct? notificationss,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (notificationss == null) {
    return;
  }
  if (notificationss.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && notificationss.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final notificationssData =
      getNotificationssFirestoreData(notificationss, forFieldValue);
  final nestedData =
      notificationssData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = notificationss.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getNotificationssFirestoreData(
  NotificationssStruct? notificationss, [
  bool forFieldValue = false,
]) {
  if (notificationss == null) {
    return {};
  }
  final firestoreData = mapToFirestore(notificationss.toMap());

  // Add any Firestore field values
  notificationss.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getNotificationssListFirestoreData(
  List<NotificationssStruct>? notificationsss,
) =>
    notificationsss
        ?.map((e) => getNotificationssFirestoreData(e, true))
        .toList() ??
    [];
