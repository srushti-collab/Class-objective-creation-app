import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CommentsRecord extends FirestoreRecord {
  CommentsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "comments" field.
  String? _comments;
  String get comments => _comments ?? '';
  bool hasComments() => _comments != null;

  // "created" field.
  DateTime? _created;
  DateTime? get created => _created;
  bool hasCreated() => _created != null;

  // "commentersname" field.
  String? _commentersname;
  String get commentersname => _commentersname ?? '';
  bool hasCommentersname() => _commentersname != null;

  // "chat" field.
  List<DocumentReference>? _chat;
  List<DocumentReference> get chat => _chat ?? const [];
  bool hasChat() => _chat != null;

  // "img" field.
  String? _img;
  String get img => _img ?? '';
  bool hasImg() => _img != null;

  // "tasks" field.
  DocumentReference? _tasks;
  DocumentReference? get tasks => _tasks;
  bool hasTasks() => _tasks != null;

  void _initializeFields() {
    _comments = snapshotData['comments'] as String?;
    _created = snapshotData['created'] as DateTime?;
    _commentersname = snapshotData['commentersname'] as String?;
    _chat = getDataList(snapshotData['chat']);
    _img = snapshotData['img'] as String?;
    _tasks = snapshotData['tasks'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('comments');

  static Stream<CommentsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CommentsRecord.fromSnapshot(s));

  static Future<CommentsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CommentsRecord.fromSnapshot(s));

  static CommentsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CommentsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CommentsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CommentsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CommentsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CommentsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCommentsRecordData({
  String? comments,
  DateTime? created,
  String? commentersname,
  String? img,
  DocumentReference? tasks,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'comments': comments,
      'created': created,
      'commentersname': commentersname,
      'img': img,
      'tasks': tasks,
    }.withoutNulls,
  );

  return firestoreData;
}

class CommentsRecordDocumentEquality implements Equality<CommentsRecord> {
  const CommentsRecordDocumentEquality();

  @override
  bool equals(CommentsRecord? e1, CommentsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.comments == e2?.comments &&
        e1?.created == e2?.created &&
        e1?.commentersname == e2?.commentersname &&
        listEquality.equals(e1?.chat, e2?.chat) &&
        e1?.img == e2?.img &&
        e1?.tasks == e2?.tasks;
  }

  @override
  int hash(CommentsRecord? e) => const ListEquality().hash(
      [e?.comments, e?.created, e?.commentersname, e?.chat, e?.img, e?.tasks]);

  @override
  bool isValidKey(Object? o) => o is CommentsRecord;
}
