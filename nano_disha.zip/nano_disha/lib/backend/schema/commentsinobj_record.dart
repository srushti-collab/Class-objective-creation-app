import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CommentsinobjRecord extends FirestoreRecord {
  CommentsinobjRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  bool hasMessage() => _message != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "senderuid" field.
  DocumentReference? _senderuid;
  DocumentReference? get senderuid => _senderuid;
  bool hasSenderuid() => _senderuid != null;

  // "receivers" field.
  DocumentReference? _receivers;
  DocumentReference? get receivers => _receivers;
  bool hasReceivers() => _receivers != null;

  // "sendername" field.
  String? _sendername;
  String get sendername => _sendername ?? '';
  bool hasSendername() => _sendername != null;

  void _initializeFields() {
    _message = snapshotData['message'] as String?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _senderuid = snapshotData['senderuid'] as DocumentReference?;
    _receivers = snapshotData['receivers'] as DocumentReference?;
    _sendername = snapshotData['sendername'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('commentsinobj');

  static Stream<CommentsinobjRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CommentsinobjRecord.fromSnapshot(s));

  static Future<CommentsinobjRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CommentsinobjRecord.fromSnapshot(s));

  static CommentsinobjRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CommentsinobjRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CommentsinobjRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CommentsinobjRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CommentsinobjRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CommentsinobjRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCommentsinobjRecordData({
  String? message,
  DateTime? timestamp,
  DocumentReference? senderuid,
  DocumentReference? receivers,
  String? sendername,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'message': message,
      'timestamp': timestamp,
      'senderuid': senderuid,
      'receivers': receivers,
      'sendername': sendername,
    }.withoutNulls,
  );

  return firestoreData;
}

class CommentsinobjRecordDocumentEquality
    implements Equality<CommentsinobjRecord> {
  const CommentsinobjRecordDocumentEquality();

  @override
  bool equals(CommentsinobjRecord? e1, CommentsinobjRecord? e2) {
    return e1?.message == e2?.message &&
        e1?.timestamp == e2?.timestamp &&
        e1?.senderuid == e2?.senderuid &&
        e1?.receivers == e2?.receivers &&
        e1?.sendername == e2?.sendername;
  }

  @override
  int hash(CommentsinobjRecord? e) => const ListEquality().hash(
      [e?.message, e?.timestamp, e?.senderuid, e?.receivers, e?.sendername]);

  @override
  bool isValidKey(Object? o) => o is CommentsinobjRecord;
}
