import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TaskRecord extends FirestoreRecord {
  TaskRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "task_title" field.
  String? _taskTitle;
  String get taskTitle => _taskTitle ?? '';
  bool hasTaskTitle() => _taskTitle != null;

  // "task_desc" field.
  String? _taskDesc;
  String get taskDesc => _taskDesc ?? '';
  bool hasTaskDesc() => _taskDesc != null;

  // "completed_flag" field.
  bool? _completedFlag;
  bool get completedFlag => _completedFlag ?? false;
  bool hasCompletedFlag() => _completedFlag != null;

  // "due_date" field.
  DateTime? _dueDate;
  DateTime? get dueDate => _dueDate;
  bool hasDueDate() => _dueDate != null;

  // "project_ref" field.
  DocumentReference? _projectRef;
  DocumentReference? get projectRef => _projectRef;
  bool hasProjectRef() => _projectRef != null;

  // "plan_ref" field.
  DocumentReference? _planRef;
  DocumentReference? get planRef => _planRef;
  bool hasPlanRef() => _planRef != null;

  // "task_assignee" field.
  DocumentReference? _taskAssignee;
  DocumentReference? get taskAssignee => _taskAssignee;
  bool hasTaskAssignee() => _taskAssignee != null;

  // "completedDate" field.
  DateTime? _completedDate;
  DateTime? get completedDate => _completedDate;
  bool hasCompletedDate() => _completedDate != null;

  // "assignedEmp" field.
  String? _assignedEmp;
  String get assignedEmp => _assignedEmp ?? '';
  bool hasAssignedEmp() => _assignedEmp != null;

  // "Status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "Progress" field.
  int? _progress;
  int get progress => _progress ?? 0;
  bool hasProgress() => _progress != null;

  // "Priority" field.
  String? _priority;
  String get priority => _priority ?? '';
  bool hasPriority() => _priority != null;

  // "underOBJ" field.
  bool? _underOBJ;
  bool get underOBJ => _underOBJ ?? false;
  bool hasUnderOBJ() => _underOBJ != null;

  // "assignedName" field.
  String? _assignedName;
  String get assignedName => _assignedName ?? '';
  bool hasAssignedName() => _assignedName != null;

  // "respond" field.
  bool? _respond;
  bool get respond => _respond ?? false;
  bool hasRespond() => _respond != null;

  // "accept" field.
  bool? _accept;
  bool get accept => _accept ?? false;
  bool hasAccept() => _accept != null;

  // "completred" field.
  bool? _completred;
  bool get completred => _completred ?? false;
  bool hasCompletred() => _completred != null;

  // "taskref" field.
  List<DocumentReference>? _taskref;
  List<DocumentReference> get taskref => _taskref ?? const [];
  bool hasTaskref() => _taskref != null;

  // "assignedByname" field.
  String? _assignedByname;
  String get assignedByname => _assignedByname ?? '';
  bool hasAssignedByname() => _assignedByname != null;

  // "Document" field.
  String? _document;
  String get document => _document ?? '';
  bool hasDocument() => _document != null;

  // "DocVis" field.
  bool? _docVis;
  bool get docVis => _docVis ?? false;
  bool hasDocVis() => _docVis != null;

  // "Chat" field.
  List<TaskChatStruct>? _chat;
  List<TaskChatStruct> get chat => _chat ?? const [];
  bool hasChat() => _chat != null;

  // "reviwerassigned" field.
  DocumentReference? _reviwerassigned;
  DocumentReference? get reviwerassigned => _reviwerassigned;
  bool hasReviwerassigned() => _reviwerassigned != null;

  // "ParentOBJS" field.
  List<DocumentReference>? _parentOBJS;
  List<DocumentReference> get parentOBJS => _parentOBJS ?? const [];
  bool hasParentOBJS() => _parentOBJS != null;

  // "ParentObjIDS" field.
  List<String>? _parentObjIDS;
  List<String> get parentObjIDS => _parentObjIDS ?? const [];
  bool hasParentObjIDS() => _parentObjIDS != null;

  // "assignedTo" field.
  DocumentReference? _assignedTo;
  DocumentReference? get assignedTo => _assignedTo;
  bool hasAssignedTo() => _assignedTo != null;

  // "Repetative" field.
  bool? _repetative;
  bool get repetative => _repetative ?? false;
  bool hasRepetative() => _repetative != null;

  // "Reviewable" field.
  bool? _reviewable;
  bool get reviewable => _reviewable ?? false;
  bool hasReviewable() => _reviewable != null;

  // "Frequency" field.
  String? _frequency;
  String get frequency => _frequency ?? '';
  bool hasFrequency() => _frequency != null;

  // "RepeatUntill" field.
  DateTime? _repeatUntill;
  DateTime? get repeatUntill => _repeatUntill;
  bool hasRepeatUntill() => _repeatUntill != null;

  // "emp_start_date" field.
  List<DateTime>? _empStartDate;
  List<DateTime> get empStartDate => _empStartDate ?? const [];
  bool hasEmpStartDate() => _empStartDate != null;

  // "emp_end_date" field.
  List<DateTime>? _empEndDate;
  List<DateTime> get empEndDate => _empEndDate ?? const [];
  bool hasEmpEndDate() => _empEndDate != null;

  // "uploadeddoc" field.
  String? _uploadeddoc;
  String get uploadeddoc => _uploadeddoc ?? '';
  bool hasUploadeddoc() => _uploadeddoc != null;

  // "craeteddate" field.
  DateTime? _craeteddate;
  DateTime? get craeteddate => _craeteddate;
  bool hasCraeteddate() => _craeteddate != null;

  // "assignedbypic" field.
  String? _assignedbypic;
  String get assignedbypic => _assignedbypic ?? '';
  bool hasAssignedbypic() => _assignedbypic != null;

  // "assignedbydes" field.
  String? _assignedbydes;
  String get assignedbydes => _assignedbydes ?? '';
  bool hasAssignedbydes() => _assignedbydes != null;

  // "ReviewerName" field.
  String? _reviewerName;
  String get reviewerName => _reviewerName ?? '';
  bool hasReviewerName() => _reviewerName != null;

  // "Attachements" field.
  List<AttachmentsStruct>? _attachements;
  List<AttachmentsStruct> get attachements => _attachements ?? const [];
  bool hasAttachements() => _attachements != null;

  // "ATTACHMULTY" field.
  List<String>? _attachmulty;
  List<String> get attachmulty => _attachmulty ?? const [];
  bool hasAttachmulty() => _attachmulty != null;

  // "attachmultii" field.
  List<AttachmentsStruct>? _attachmultii;
  List<AttachmentsStruct> get attachmultii => _attachmultii ?? const [];
  bool hasAttachmultii() => _attachmultii != null;

  // "JamRef" field.
  DocumentReference? _jamRef;
  DocumentReference? get jamRef => _jamRef;
  bool hasJamRef() => _jamRef != null;

  // "Jam" field.
  bool? _jam;
  bool get jam => _jam ?? false;
  bool hasJam() => _jam != null;

  // "NotValid" field.
  bool? _notValid;
  bool get notValid => _notValid ?? false;
  bool hasNotValid() => _notValid != null;

  void _initializeFields() {
    _taskTitle = snapshotData['task_title'] as String?;
    _taskDesc = snapshotData['task_desc'] as String?;
    _completedFlag = snapshotData['completed_flag'] as bool?;
    _dueDate = snapshotData['due_date'] as DateTime?;
    _projectRef = snapshotData['project_ref'] as DocumentReference?;
    _planRef = snapshotData['plan_ref'] as DocumentReference?;
    _taskAssignee = snapshotData['task_assignee'] as DocumentReference?;
    _completedDate = snapshotData['completedDate'] as DateTime?;
    _assignedEmp = snapshotData['assignedEmp'] as String?;
    _status = snapshotData['Status'] as String?;
    _progress = castToType<int>(snapshotData['Progress']);
    _priority = snapshotData['Priority'] as String?;
    _underOBJ = snapshotData['underOBJ'] as bool?;
    _assignedName = snapshotData['assignedName'] as String?;
    _respond = snapshotData['respond'] as bool?;
    _accept = snapshotData['accept'] as bool?;
    _completred = snapshotData['completred'] as bool?;
    _taskref = getDataList(snapshotData['taskref']);
    _assignedByname = snapshotData['assignedByname'] as String?;
    _document = snapshotData['Document'] as String?;
    _docVis = snapshotData['DocVis'] as bool?;
    _chat = getStructList(
      snapshotData['Chat'],
      TaskChatStruct.fromMap,
    );
    _reviwerassigned = snapshotData['reviwerassigned'] as DocumentReference?;
    _parentOBJS = getDataList(snapshotData['ParentOBJS']);
    _parentObjIDS = getDataList(snapshotData['ParentObjIDS']);
    _assignedTo = snapshotData['assignedTo'] as DocumentReference?;
    _repetative = snapshotData['Repetative'] as bool?;
    _reviewable = snapshotData['Reviewable'] as bool?;
    _frequency = snapshotData['Frequency'] as String?;
    _repeatUntill = snapshotData['RepeatUntill'] as DateTime?;
    _empStartDate = getDataList(snapshotData['emp_start_date']);
    _empEndDate = getDataList(snapshotData['emp_end_date']);
    _uploadeddoc = snapshotData['uploadeddoc'] as String?;
    _craeteddate = snapshotData['craeteddate'] as DateTime?;
    _assignedbypic = snapshotData['assignedbypic'] as String?;
    _assignedbydes = snapshotData['assignedbydes'] as String?;
    _reviewerName = snapshotData['ReviewerName'] as String?;
    _attachements = getStructList(
      snapshotData['Attachements'],
      AttachmentsStruct.fromMap,
    );
    _attachmulty = getDataList(snapshotData['ATTACHMULTY']);
    _attachmultii = getStructList(
      snapshotData['attachmultii'],
      AttachmentsStruct.fromMap,
    );
    _jamRef = snapshotData['JamRef'] as DocumentReference?;
    _jam = snapshotData['Jam'] as bool?;
    _notValid = snapshotData['NotValid'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('task');

  static Stream<TaskRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TaskRecord.fromSnapshot(s));

  static Future<TaskRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TaskRecord.fromSnapshot(s));

  static TaskRecord fromSnapshot(DocumentSnapshot snapshot) => TaskRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TaskRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TaskRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TaskRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TaskRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTaskRecordData({
  String? taskTitle,
  String? taskDesc,
  bool? completedFlag,
  DateTime? dueDate,
  DocumentReference? projectRef,
  DocumentReference? planRef,
  DocumentReference? taskAssignee,
  DateTime? completedDate,
  String? assignedEmp,
  String? status,
  int? progress,
  String? priority,
  bool? underOBJ,
  String? assignedName,
  bool? respond,
  bool? accept,
  bool? completred,
  String? assignedByname,
  String? document,
  bool? docVis,
  DocumentReference? reviwerassigned,
  DocumentReference? assignedTo,
  bool? repetative,
  bool? reviewable,
  String? frequency,
  DateTime? repeatUntill,
  String? uploadeddoc,
  DateTime? craeteddate,
  String? assignedbypic,
  String? assignedbydes,
  String? reviewerName,
  DocumentReference? jamRef,
  bool? jam,
  bool? notValid,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'task_title': taskTitle,
      'task_desc': taskDesc,
      'completed_flag': completedFlag,
      'due_date': dueDate,
      'project_ref': projectRef,
      'plan_ref': planRef,
      'task_assignee': taskAssignee,
      'completedDate': completedDate,
      'assignedEmp': assignedEmp,
      'Status': status,
      'Progress': progress,
      'Priority': priority,
      'underOBJ': underOBJ,
      'assignedName': assignedName,
      'respond': respond,
      'accept': accept,
      'completred': completred,
      'assignedByname': assignedByname,
      'Document': document,
      'DocVis': docVis,
      'reviwerassigned': reviwerassigned,
      'assignedTo': assignedTo,
      'Repetative': repetative,
      'Reviewable': reviewable,
      'Frequency': frequency,
      'RepeatUntill': repeatUntill,
      'uploadeddoc': uploadeddoc,
      'craeteddate': craeteddate,
      'assignedbypic': assignedbypic,
      'assignedbydes': assignedbydes,
      'ReviewerName': reviewerName,
      'JamRef': jamRef,
      'Jam': jam,
      'NotValid': notValid,
    }.withoutNulls,
  );

  return firestoreData;
}

class TaskRecordDocumentEquality implements Equality<TaskRecord> {
  const TaskRecordDocumentEquality();

  @override
  bool equals(TaskRecord? e1, TaskRecord? e2) {
    const listEquality = ListEquality();
    return e1?.taskTitle == e2?.taskTitle &&
        e1?.taskDesc == e2?.taskDesc &&
        e1?.completedFlag == e2?.completedFlag &&
        e1?.dueDate == e2?.dueDate &&
        e1?.projectRef == e2?.projectRef &&
        e1?.planRef == e2?.planRef &&
        e1?.taskAssignee == e2?.taskAssignee &&
        e1?.completedDate == e2?.completedDate &&
        e1?.assignedEmp == e2?.assignedEmp &&
        e1?.status == e2?.status &&
        e1?.progress == e2?.progress &&
        e1?.priority == e2?.priority &&
        e1?.underOBJ == e2?.underOBJ &&
        e1?.assignedName == e2?.assignedName &&
        e1?.respond == e2?.respond &&
        e1?.accept == e2?.accept &&
        e1?.completred == e2?.completred &&
        listEquality.equals(e1?.taskref, e2?.taskref) &&
        e1?.assignedByname == e2?.assignedByname &&
        e1?.document == e2?.document &&
        e1?.docVis == e2?.docVis &&
        listEquality.equals(e1?.chat, e2?.chat) &&
        e1?.reviwerassigned == e2?.reviwerassigned &&
        listEquality.equals(e1?.parentOBJS, e2?.parentOBJS) &&
        listEquality.equals(e1?.parentObjIDS, e2?.parentObjIDS) &&
        e1?.assignedTo == e2?.assignedTo &&
        e1?.repetative == e2?.repetative &&
        e1?.reviewable == e2?.reviewable &&
        e1?.frequency == e2?.frequency &&
        e1?.repeatUntill == e2?.repeatUntill &&
        listEquality.equals(e1?.empStartDate, e2?.empStartDate) &&
        listEquality.equals(e1?.empEndDate, e2?.empEndDate) &&
        e1?.uploadeddoc == e2?.uploadeddoc &&
        e1?.craeteddate == e2?.craeteddate &&
        e1?.assignedbypic == e2?.assignedbypic &&
        e1?.assignedbydes == e2?.assignedbydes &&
        e1?.reviewerName == e2?.reviewerName &&
        listEquality.equals(e1?.attachements, e2?.attachements) &&
        listEquality.equals(e1?.attachmulty, e2?.attachmulty) &&
        listEquality.equals(e1?.attachmultii, e2?.attachmultii) &&
        e1?.jamRef == e2?.jamRef &&
        e1?.jam == e2?.jam &&
        e1?.notValid == e2?.notValid;
  }

  @override
  int hash(TaskRecord? e) => const ListEquality().hash([
        e?.taskTitle,
        e?.taskDesc,
        e?.completedFlag,
        e?.dueDate,
        e?.projectRef,
        e?.planRef,
        e?.taskAssignee,
        e?.completedDate,
        e?.assignedEmp,
        e?.status,
        e?.progress,
        e?.priority,
        e?.underOBJ,
        e?.assignedName,
        e?.respond,
        e?.accept,
        e?.completred,
        e?.taskref,
        e?.assignedByname,
        e?.document,
        e?.docVis,
        e?.chat,
        e?.reviwerassigned,
        e?.parentOBJS,
        e?.parentObjIDS,
        e?.assignedTo,
        e?.repetative,
        e?.reviewable,
        e?.frequency,
        e?.repeatUntill,
        e?.empStartDate,
        e?.empEndDate,
        e?.uploadeddoc,
        e?.craeteddate,
        e?.assignedbypic,
        e?.assignedbydes,
        e?.reviewerName,
        e?.attachements,
        e?.attachmulty,
        e?.attachmultii,
        e?.jamRef,
        e?.jam,
        e?.notValid
      ]);

  @override
  bool isValidKey(Object? o) => o is TaskRecord;
}
