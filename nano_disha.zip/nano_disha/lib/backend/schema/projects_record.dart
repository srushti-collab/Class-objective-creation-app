import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProjectsRecord extends FirestoreRecord {
  ProjectsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "due_date" field.
  DateTime? _dueDate;
  DateTime? get dueDate => _dueDate;
  bool hasDueDate() => _dueDate != null;

  // "project_creator" field.
  DocumentReference? _projectCreator;
  DocumentReference? get projectCreator => _projectCreator;
  bool hasProjectCreator() => _projectCreator != null;

  // "start_date" field.
  DateTime? _startDate;
  DateTime? get startDate => _startDate;
  bool hasStartDate() => _startDate != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "progress" field.
  int? _progress;
  int get progress => _progress ?? 0;
  bool hasProgress() => _progress != null;

  // "CreationDate" field.
  DateTime? _creationDate;
  DateTime? get creationDate => _creationDate;
  bool hasCreationDate() => _creationDate != null;

  // "owner" field.
  DocumentReference? _owner;
  DocumentReference? get owner => _owner;
  bool hasOwner() => _owner != null;

  // "ownerName" field.
  String? _ownerName;
  String get ownerName => _ownerName ?? '';
  bool hasOwnerName() => _ownerName != null;

  // "parentOwner" field.
  DocumentReference? _parentOwner;
  DocumentReference? get parentOwner => _parentOwner;
  bool hasParentOwner() => _parentOwner != null;

  // "creatorID" field.
  String? _creatorID;
  String get creatorID => _creatorID ?? '';
  bool hasCreatorID() => _creatorID != null;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  bool hasMessage() => _message != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "senderuid" field.
  String? _senderuid;
  String get senderuid => _senderuid ?? '';
  bool hasSenderuid() => _senderuid != null;

  // "receiver" field.
  DocumentReference? _receiver;
  DocumentReference? get receiver => _receiver;
  bool hasReceiver() => _receiver != null;

  // "sendername" field.
  String? _sendername;
  String get sendername => _sendername ?? '';
  bool hasSendername() => _sendername != null;

  // "projID" field.
  String? _projID;
  String get projID => _projID ?? '';
  bool hasProjID() => _projID != null;

  // "assignedManager" field.
  DocumentReference? _assignedManager;
  DocumentReference? get assignedManager => _assignedManager;
  bool hasAssignedManager() => _assignedManager != null;

  // "Personal" field.
  bool? _personal;
  bool get personal => _personal ?? false;
  bool hasPersonal() => _personal != null;

  // "ParentProject" field.
  DocumentReference? _parentProject;
  DocumentReference? get parentProject => _parentProject;
  bool hasParentProject() => _parentProject != null;

  // "Organisational" field.
  bool? _organisational;
  bool get organisational => _organisational ?? false;
  bool hasOrganisational() => _organisational != null;

  // "ParentProj" field.
  DocumentReference? _parentProj;
  DocumentReference? get parentProj => _parentProj;
  bool hasParentProj() => _parentProj != null;

  // "ParentOBJS" field.
  List<DocumentReference>? _parentOBJS;
  List<DocumentReference> get parentOBJS => _parentOBJS ?? const [];
  bool hasParentOBJS() => _parentOBJS != null;

  // "UnderOrg" field.
  bool? _underOrg;
  bool get underOrg => _underOrg ?? false;
  bool hasUnderOrg() => _underOrg != null;

  // "childObjectives" field.
  List<DocumentReference>? _childObjectives;
  List<DocumentReference> get childObjectives => _childObjectives ?? const [];
  bool hasChildObjectives() => _childObjectives != null;

  // "ProgressObj" field.
  String? _progressObj;
  String get progressObj => _progressObj ?? '';
  bool hasProgressObj() => _progressObj != null;

  // "totalTask" field.
  int? _totalTask;
  int get totalTask => _totalTask ?? 0;
  bool hasTotalTask() => _totalTask != null;

  // "completedTask" field.
  int? _completedTask;
  int get completedTask => _completedTask ?? 0;
  bool hasCompletedTask() => _completedTask != null;

  // "ProgressPerc" field.
  double? _progressPerc;
  double get progressPerc => _progressPerc ?? 0.0;
  bool hasProgressPerc() => _progressPerc != null;

  // "ParentIDS" field.
  List<String>? _parentIDS;
  List<String> get parentIDS => _parentIDS ?? const [];
  bool hasParentIDS() => _parentIDS != null;

  // "usersinpro" field.
  DocumentReference? _usersinpro;
  DocumentReference? get usersinpro => _usersinpro;
  bool hasUsersinpro() => _usersinpro != null;

  // "plans" field.
  DocumentReference? _plans;
  DocumentReference? get plans => _plans;
  bool hasPlans() => _plans != null;

  // "Type" field.
  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  // "weightage" field.
  int? _weightage;
  int get weightage => _weightage ?? 0;
  bool hasWeightage() => _weightage != null;

  // "Notes" field.
  List<ObjectiveNotesStruct>? _notes;
  List<ObjectiveNotesStruct> get notes => _notes ?? const [];
  bool hasNotes() => _notes != null;

  // "subOBJIDS" field.
  List<String>? _subOBJIDS;
  List<String> get subOBJIDS => _subOBJIDS ?? const [];
  bool hasSubOBJIDS() => _subOBJIDS != null;

  // "projectID" field.
  String? _projectID;
  String get projectID => _projectID ?? '';
  bool hasProjectID() => _projectID != null;

  // "HirarchialList" field.
  List<String>? _hirarchialList;
  List<String> get hirarchialList => _hirarchialList ?? const [];
  bool hasHirarchialList() => _hirarchialList != null;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
    _description = snapshotData['description'] as String?;
    _dueDate = snapshotData['due_date'] as DateTime?;
    _projectCreator = snapshotData['project_creator'] as DocumentReference?;
    _startDate = snapshotData['start_date'] as DateTime?;
    _status = snapshotData['status'] as String?;
    _progress = castToType<int>(snapshotData['progress']);
    _creationDate = snapshotData['CreationDate'] as DateTime?;
    _owner = snapshotData['owner'] as DocumentReference?;
    _ownerName = snapshotData['ownerName'] as String?;
    _parentOwner = snapshotData['parentOwner'] as DocumentReference?;
    _creatorID = snapshotData['creatorID'] as String?;
    _message = snapshotData['message'] as String?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _senderuid = snapshotData['senderuid'] as String?;
    _receiver = snapshotData['receiver'] as DocumentReference?;
    _sendername = snapshotData['sendername'] as String?;
    _projID = snapshotData['projID'] as String?;
    _assignedManager = snapshotData['assignedManager'] as DocumentReference?;
    _personal = snapshotData['Personal'] as bool?;
    _parentProject = snapshotData['ParentProject'] as DocumentReference?;
    _organisational = snapshotData['Organisational'] as bool?;
    _parentProj = snapshotData['ParentProj'] as DocumentReference?;
    _parentOBJS = getDataList(snapshotData['ParentOBJS']);
    _underOrg = snapshotData['UnderOrg'] as bool?;
    _childObjectives = getDataList(snapshotData['childObjectives']);
    _progressObj = snapshotData['ProgressObj'] as String?;
    _totalTask = castToType<int>(snapshotData['totalTask']);
    _completedTask = castToType<int>(snapshotData['completedTask']);
    _progressPerc = castToType<double>(snapshotData['ProgressPerc']);
    _parentIDS = getDataList(snapshotData['ParentIDS']);
    _usersinpro = snapshotData['usersinpro'] as DocumentReference?;
    _plans = snapshotData['plans'] as DocumentReference?;
    _type = snapshotData['Type'] as String?;
    _weightage = castToType<int>(snapshotData['weightage']);
    _notes = getStructList(
      snapshotData['Notes'],
      ObjectiveNotesStruct.fromMap,
    );
    _subOBJIDS = getDataList(snapshotData['subOBJIDS']);
    _projectID = snapshotData['projectID'] as String?;
    _hirarchialList = getDataList(snapshotData['HirarchialList']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('projects');

  static Stream<ProjectsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ProjectsRecord.fromSnapshot(s));

  static Future<ProjectsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ProjectsRecord.fromSnapshot(s));

  static ProjectsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ProjectsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ProjectsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ProjectsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ProjectsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ProjectsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createProjectsRecordData({
  String? title,
  String? description,
  DateTime? dueDate,
  DocumentReference? projectCreator,
  DateTime? startDate,
  String? status,
  int? progress,
  DateTime? creationDate,
  DocumentReference? owner,
  String? ownerName,
  DocumentReference? parentOwner,
  String? creatorID,
  String? message,
  DateTime? timestamp,
  String? senderuid,
  DocumentReference? receiver,
  String? sendername,
  String? projID,
  DocumentReference? assignedManager,
  bool? personal,
  DocumentReference? parentProject,
  bool? organisational,
  DocumentReference? parentProj,
  bool? underOrg,
  String? progressObj,
  int? totalTask,
  int? completedTask,
  double? progressPerc,
  DocumentReference? usersinpro,
  DocumentReference? plans,
  String? type,
  int? weightage,
  String? projectID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
      'description': description,
      'due_date': dueDate,
      'project_creator': projectCreator,
      'start_date': startDate,
      'status': status,
      'progress': progress,
      'CreationDate': creationDate,
      'owner': owner,
      'ownerName': ownerName,
      'parentOwner': parentOwner,
      'creatorID': creatorID,
      'message': message,
      'timestamp': timestamp,
      'senderuid': senderuid,
      'receiver': receiver,
      'sendername': sendername,
      'projID': projID,
      'assignedManager': assignedManager,
      'Personal': personal,
      'ParentProject': parentProject,
      'Organisational': organisational,
      'ParentProj': parentProj,
      'UnderOrg': underOrg,
      'ProgressObj': progressObj,
      'totalTask': totalTask,
      'completedTask': completedTask,
      'ProgressPerc': progressPerc,
      'usersinpro': usersinpro,
      'plans': plans,
      'Type': type,
      'weightage': weightage,
      'projectID': projectID,
    }.withoutNulls,
  );

  return firestoreData;
}

class ProjectsRecordDocumentEquality implements Equality<ProjectsRecord> {
  const ProjectsRecordDocumentEquality();

  @override
  bool equals(ProjectsRecord? e1, ProjectsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.title == e2?.title &&
        e1?.description == e2?.description &&
        e1?.dueDate == e2?.dueDate &&
        e1?.projectCreator == e2?.projectCreator &&
        e1?.startDate == e2?.startDate &&
        e1?.status == e2?.status &&
        e1?.progress == e2?.progress &&
        e1?.creationDate == e2?.creationDate &&
        e1?.owner == e2?.owner &&
        e1?.ownerName == e2?.ownerName &&
        e1?.parentOwner == e2?.parentOwner &&
        e1?.creatorID == e2?.creatorID &&
        e1?.message == e2?.message &&
        e1?.timestamp == e2?.timestamp &&
        e1?.senderuid == e2?.senderuid &&
        e1?.receiver == e2?.receiver &&
        e1?.sendername == e2?.sendername &&
        e1?.projID == e2?.projID &&
        e1?.assignedManager == e2?.assignedManager &&
        e1?.personal == e2?.personal &&
        e1?.parentProject == e2?.parentProject &&
        e1?.organisational == e2?.organisational &&
        e1?.parentProj == e2?.parentProj &&
        listEquality.equals(e1?.parentOBJS, e2?.parentOBJS) &&
        e1?.underOrg == e2?.underOrg &&
        listEquality.equals(e1?.childObjectives, e2?.childObjectives) &&
        e1?.progressObj == e2?.progressObj &&
        e1?.totalTask == e2?.totalTask &&
        e1?.completedTask == e2?.completedTask &&
        e1?.progressPerc == e2?.progressPerc &&
        listEquality.equals(e1?.parentIDS, e2?.parentIDS) &&
        e1?.usersinpro == e2?.usersinpro &&
        e1?.plans == e2?.plans &&
        e1?.type == e2?.type &&
        e1?.weightage == e2?.weightage &&
        listEquality.equals(e1?.notes, e2?.notes) &&
        listEquality.equals(e1?.subOBJIDS, e2?.subOBJIDS) &&
        e1?.projectID == e2?.projectID &&
        listEquality.equals(e1?.hirarchialList, e2?.hirarchialList);
  }

  @override
  int hash(ProjectsRecord? e) => const ListEquality().hash([
        e?.title,
        e?.description,
        e?.dueDate,
        e?.projectCreator,
        e?.startDate,
        e?.status,
        e?.progress,
        e?.creationDate,
        e?.owner,
        e?.ownerName,
        e?.parentOwner,
        e?.creatorID,
        e?.message,
        e?.timestamp,
        e?.senderuid,
        e?.receiver,
        e?.sendername,
        e?.projID,
        e?.assignedManager,
        e?.personal,
        e?.parentProject,
        e?.organisational,
        e?.parentProj,
        e?.parentOBJS,
        e?.underOrg,
        e?.childObjectives,
        e?.progressObj,
        e?.totalTask,
        e?.completedTask,
        e?.progressPerc,
        e?.parentIDS,
        e?.usersinpro,
        e?.plans,
        e?.type,
        e?.weightage,
        e?.notes,
        e?.subOBJIDS,
        e?.projectID,
        e?.hirarchialList
      ]);

  @override
  bool isValidKey(Object? o) => o is ProjectsRecord;
}
