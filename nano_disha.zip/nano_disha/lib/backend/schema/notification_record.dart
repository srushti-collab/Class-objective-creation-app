import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class NotificationRecord extends FirestoreRecord {
  NotificationRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "subtitle" field.
  String? _subtitle;
  String get subtitle => _subtitle ?? '';
  bool hasSubtitle() => _subtitle != null;

  // "time" field.
  DateTime? _time;
  DateTime? get time => _time;
  bool hasTime() => _time != null;

  // "userref" field.
  DocumentReference? _userref;
  DocumentReference? get userref => _userref;
  bool hasUserref() => _userref != null;

  // "All" field.
  bool? _all;
  bool get all => _all ?? false;
  bool hasAll() => _all != null;

  // "obj" field.
  bool? _obj;
  bool get obj => _obj ?? false;
  bool hasObj() => _obj != null;

  // "chat" field.
  bool? _chat;
  bool get chat => _chat ?? false;
  bool hasChat() => _chat != null;

  // "general" field.
  bool? _general;
  bool get general => _general ?? false;
  bool hasGeneral() => _general != null;

  // "task" field.
  bool? _task;
  bool get task => _task ?? false;
  bool hasTask() => _task != null;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
    _subtitle = snapshotData['subtitle'] as String?;
    _time = snapshotData['time'] as DateTime?;
    _userref = snapshotData['userref'] as DocumentReference?;
    _all = snapshotData['All'] as bool?;
    _obj = snapshotData['obj'] as bool?;
    _chat = snapshotData['chat'] as bool?;
    _general = snapshotData['general'] as bool?;
    _task = snapshotData['task'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('notification');

  static Stream<NotificationRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => NotificationRecord.fromSnapshot(s));

  static Future<NotificationRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => NotificationRecord.fromSnapshot(s));

  static NotificationRecord fromSnapshot(DocumentSnapshot snapshot) =>
      NotificationRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static NotificationRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      NotificationRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'NotificationRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is NotificationRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createNotificationRecordData({
  String? title,
  String? subtitle,
  DateTime? time,
  DocumentReference? userref,
  bool? all,
  bool? obj,
  bool? chat,
  bool? general,
  bool? task,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
      'subtitle': subtitle,
      'time': time,
      'userref': userref,
      'All': all,
      'obj': obj,
      'chat': chat,
      'general': general,
      'task': task,
    }.withoutNulls,
  );

  return firestoreData;
}

class NotificationRecordDocumentEquality
    implements Equality<NotificationRecord> {
  const NotificationRecordDocumentEquality();

  @override
  bool equals(NotificationRecord? e1, NotificationRecord? e2) {
    return e1?.title == e2?.title &&
        e1?.subtitle == e2?.subtitle &&
        e1?.time == e2?.time &&
        e1?.userref == e2?.userref &&
        e1?.all == e2?.all &&
        e1?.obj == e2?.obj &&
        e1?.chat == e2?.chat &&
        e1?.general == e2?.general &&
        e1?.task == e2?.task;
  }

  @override
  int hash(NotificationRecord? e) => const ListEquality().hash([
        e?.title,
        e?.subtitle,
        e?.time,
        e?.userref,
        e?.all,
        e?.obj,
        e?.chat,
        e?.general,
        e?.task
      ]);

  @override
  bool isValidKey(Object? o) => o is NotificationRecord;
}
