import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class JamRecord extends FirestoreRecord {
  JamRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  // "text" field.
  String? _text;
  String get text => _text ?? '';
  bool hasText() => _text != null;

  // "scribble" field.
  String? _scribble;
  String get scribble => _scribble ?? '';
  bool hasScribble() => _scribble != null;

  // "photo" field.
  String? _photo;
  String get photo => _photo ?? '';
  bool hasPhoto() => _photo != null;

  // "voice" field.
  String? _voice;
  String get voice => _voice ?? '';
  bool hasVoice() => _voice != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "createdAt" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "note" field.
  String? _note;
  String get note => _note ?? '';
  bool hasNote() => _note != null;

  // "video" field.
  String? _video;
  String get video => _video ?? '';
  bool hasVideo() => _video != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _type = snapshotData['type'] as String?;
    _text = snapshotData['text'] as String?;
    _scribble = snapshotData['scribble'] as String?;
    _photo = snapshotData['photo'] as String?;
    _voice = snapshotData['voice'] as String?;
    _status = snapshotData['status'] as String?;
    _createdAt = snapshotData['createdAt'] as DateTime?;
    _note = snapshotData['note'] as String?;
    _video = snapshotData['video'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Jam')
          : FirebaseFirestore.instance.collectionGroup('Jam');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('Jam').doc(id);

  static Stream<JamRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => JamRecord.fromSnapshot(s));

  static Future<JamRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => JamRecord.fromSnapshot(s));

  static JamRecord fromSnapshot(DocumentSnapshot snapshot) => JamRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static JamRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      JamRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'JamRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is JamRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createJamRecordData({
  String? type,
  String? text,
  String? scribble,
  String? photo,
  String? voice,
  String? status,
  DateTime? createdAt,
  String? note,
  String? video,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'type': type,
      'text': text,
      'scribble': scribble,
      'photo': photo,
      'voice': voice,
      'status': status,
      'createdAt': createdAt,
      'note': note,
      'video': video,
    }.withoutNulls,
  );

  return firestoreData;
}

class JamRecordDocumentEquality implements Equality<JamRecord> {
  const JamRecordDocumentEquality();

  @override
  bool equals(JamRecord? e1, JamRecord? e2) {
    return e1?.type == e2?.type &&
        e1?.text == e2?.text &&
        e1?.scribble == e2?.scribble &&
        e1?.photo == e2?.photo &&
        e1?.voice == e2?.voice &&
        e1?.status == e2?.status &&
        e1?.createdAt == e2?.createdAt &&
        e1?.note == e2?.note &&
        e1?.video == e2?.video;
  }

  @override
  int hash(JamRecord? e) => const ListEquality().hash([
        e?.type,
        e?.text,
        e?.scribble,
        e?.photo,
        e?.voice,
        e?.status,
        e?.createdAt,
        e?.note,
        e?.video
      ]);

  @override
  bool isValidKey(Object? o) => o is JamRecord;
}
