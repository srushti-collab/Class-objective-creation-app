import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "role" field.
  String? _role;
  String get role => _role ?? '';
  bool hasRole() => _role != null;

  // "theme" field.
  String? _theme;
  String get theme => _theme ?? '';
  bool hasTheme() => _theme != null;

  // "designation" field.
  String? _designation;
  String get designation => _designation ?? '';
  bool hasDesignation() => _designation != null;

  // "projects" field.
  List<DocumentReference>? _projects;
  List<DocumentReference> get projects => _projects ?? const [];
  bool hasProjects() => _projects != null;

  // "plans" field.
  List<DocumentReference>? _plans;
  List<DocumentReference> get plans => _plans ?? const [];
  bool hasPlans() => _plans != null;

  // "department" field.
  String? _department;
  String get department => _department ?? '';
  bool hasDepartment() => _department != null;

  // "lastmessage" field.
  String? _lastmessage;
  String get lastmessage => _lastmessage ?? '';
  bool hasLastmessage() => _lastmessage != null;

  // "seenby" field.
  List<DocumentReference>? _seenby;
  List<DocumentReference> get seenby => _seenby ?? const [];
  bool hasSeenby() => _seenby != null;

  // "tasks" field.
  List<DocumentReference>? _tasks;
  List<DocumentReference> get tasks => _tasks ?? const [];
  bool hasTasks() => _tasks != null;

  // "newmessages" field.
  List<String>? _newmessages;
  List<String> get newmessages => _newmessages ?? const [];
  bool hasNewmessages() => _newmessages != null;

  // "active" field.
  bool? _active;
  bool get active => _active ?? false;
  bool hasActive() => _active != null;

  // "ImmediateSub" field.
  bool? _immediateSub;
  bool get immediateSub => _immediateSub ?? false;
  bool hasImmediateSub() => _immediateSub != null;

  // "StaffNumber" field.
  int? _staffNumber;
  int get staffNumber => _staffNumber ?? 0;
  bool hasStaffNumber() => _staffNumber != null;

  // "Reviwability" field.
  bool? _reviwability;
  bool get reviwability => _reviwability ?? false;
  bool hasReviwability() => _reviwability != null;

  // "Status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "StaffNumberstrign" field.
  String? _staffNumberstrign;
  String get staffNumberstrign => _staffNumberstrign ?? '';
  bool hasStaffNumberstrign() => _staffNumberstrign != null;

  // "Notifiation" field.
  bool? _notifiation;
  bool get notifiation => _notifiation ?? false;
  bool hasNotifiation() => _notifiation != null;

  // "NotiRevv" field.
  bool? _notiRevv;
  bool get notiRevv => _notiRevv ?? false;
  bool hasNotiRevv() => _notiRevv != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _role = snapshotData['role'] as String?;
    _theme = snapshotData['theme'] as String?;
    _designation = snapshotData['designation'] as String?;
    _projects = getDataList(snapshotData['projects']);
    _plans = getDataList(snapshotData['plans']);
    _department = snapshotData['department'] as String?;
    _lastmessage = snapshotData['lastmessage'] as String?;
    _seenby = getDataList(snapshotData['seenby']);
    _tasks = getDataList(snapshotData['tasks']);
    _newmessages = getDataList(snapshotData['newmessages']);
    _active = snapshotData['active'] as bool?;
    _immediateSub = snapshotData['ImmediateSub'] as bool?;
    _staffNumber = castToType<int>(snapshotData['StaffNumber']);
    _reviwability = snapshotData['Reviwability'] as bool?;
    _status = snapshotData['Status'] as String?;
    _staffNumberstrign = snapshotData['StaffNumberstrign'] as String?;
    _notifiation = snapshotData['Notifiation'] as bool?;
    _notiRevv = snapshotData['NotiRevv'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  String? role,
  String? theme,
  String? designation,
  String? department,
  String? lastmessage,
  bool? active,
  bool? immediateSub,
  int? staffNumber,
  bool? reviwability,
  String? status,
  String? staffNumberstrign,
  bool? notifiation,
  bool? notiRevv,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'role': role,
      'theme': theme,
      'designation': designation,
      'department': department,
      'lastmessage': lastmessage,
      'active': active,
      'ImmediateSub': immediateSub,
      'StaffNumber': staffNumber,
      'Reviwability': reviwability,
      'Status': status,
      'StaffNumberstrign': staffNumberstrign,
      'Notifiation': notifiation,
      'NotiRevv': notiRevv,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.role == e2?.role &&
        e1?.theme == e2?.theme &&
        e1?.designation == e2?.designation &&
        listEquality.equals(e1?.projects, e2?.projects) &&
        listEquality.equals(e1?.plans, e2?.plans) &&
        e1?.department == e2?.department &&
        e1?.lastmessage == e2?.lastmessage &&
        listEquality.equals(e1?.seenby, e2?.seenby) &&
        listEquality.equals(e1?.tasks, e2?.tasks) &&
        listEquality.equals(e1?.newmessages, e2?.newmessages) &&
        e1?.active == e2?.active &&
        e1?.immediateSub == e2?.immediateSub &&
        e1?.staffNumber == e2?.staffNumber &&
        e1?.reviwability == e2?.reviwability &&
        e1?.status == e2?.status &&
        e1?.staffNumberstrign == e2?.staffNumberstrign &&
        e1?.notifiation == e2?.notifiation &&
        e1?.notiRevv == e2?.notiRevv;
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.role,
        e?.theme,
        e?.designation,
        e?.projects,
        e?.plans,
        e?.department,
        e?.lastmessage,
        e?.seenby,
        e?.tasks,
        e?.newmessages,
        e?.active,
        e?.immediateSub,
        e?.staffNumber,
        e?.reviwability,
        e?.status,
        e?.staffNumberstrign,
        e?.notifiation,
        e?.notiRevv
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
