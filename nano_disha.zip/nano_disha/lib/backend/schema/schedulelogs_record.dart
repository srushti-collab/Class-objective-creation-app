import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SchedulelogsRecord extends FirestoreRecord {
  SchedulelogsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "starttime" field.
  DateTime? _starttime;
  DateTime? get starttime => _starttime;
  bool hasStarttime() => _starttime != null;

  // "endtime" field.
  DateTime? _endtime;
  DateTime? get endtime => _endtime;
  bool hasEndtime() => _endtime != null;

  // "created" field.
  DateTime? _created;
  DateTime? get created => _created;
  bool hasCreated() => _created != null;

  // "schedulername" field.
  String? _schedulername;
  String get schedulername => _schedulername ?? '';
  bool hasSchedulername() => _schedulername != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
    _starttime = snapshotData['starttime'] as DateTime?;
    _endtime = snapshotData['endtime'] as DateTime?;
    _created = snapshotData['created'] as DateTime?;
    _schedulername = snapshotData['schedulername'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('schedulelogs')
          : FirebaseFirestore.instance.collectionGroup('schedulelogs');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('schedulelogs').doc(id);

  static Stream<SchedulelogsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SchedulelogsRecord.fromSnapshot(s));

  static Future<SchedulelogsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SchedulelogsRecord.fromSnapshot(s));

  static SchedulelogsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SchedulelogsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SchedulelogsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SchedulelogsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SchedulelogsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SchedulelogsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSchedulelogsRecordData({
  String? title,
  DateTime? starttime,
  DateTime? endtime,
  DateTime? created,
  String? schedulername,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
      'starttime': starttime,
      'endtime': endtime,
      'created': created,
      'schedulername': schedulername,
    }.withoutNulls,
  );

  return firestoreData;
}

class SchedulelogsRecordDocumentEquality
    implements Equality<SchedulelogsRecord> {
  const SchedulelogsRecordDocumentEquality();

  @override
  bool equals(SchedulelogsRecord? e1, SchedulelogsRecord? e2) {
    return e1?.title == e2?.title &&
        e1?.starttime == e2?.starttime &&
        e1?.endtime == e2?.endtime &&
        e1?.created == e2?.created &&
        e1?.schedulername == e2?.schedulername;
  }

  @override
  int hash(SchedulelogsRecord? e) => const ListEquality()
      .hash([e?.title, e?.starttime, e?.endtime, e?.created, e?.schedulername]);

  @override
  bool isValidKey(Object? o) => o is SchedulelogsRecord;
}
