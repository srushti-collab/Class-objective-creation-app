import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TaskChatRecord extends FirestoreRecord {
  TaskChatRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  bool hasMessage() => _message != null;

  // "taskRef" field.
  DocumentReference? _taskRef;
  DocumentReference? get taskRef => _taskRef;
  bool hasTaskRef() => _taskRef != null;

  // "assignor" field.
  DocumentReference? _assignor;
  DocumentReference? get assignor => _assignor;
  bool hasAssignor() => _assignor != null;

  // "assignee" field.
  DocumentReference? _assignee;
  DocumentReference? get assignee => _assignee;
  bool hasAssignee() => _assignee != null;

  // "time" field.
  DateTime? _time;
  DateTime? get time => _time;
  bool hasTime() => _time != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  void _initializeFields() {
    _message = snapshotData['message'] as String?;
    _taskRef = snapshotData['taskRef'] as DocumentReference?;
    _assignor = snapshotData['assignor'] as DocumentReference?;
    _assignee = snapshotData['assignee'] as DocumentReference?;
    _time = snapshotData['time'] as DateTime?;
    _name = snapshotData['name'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('taskChat');

  static Stream<TaskChatRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TaskChatRecord.fromSnapshot(s));

  static Future<TaskChatRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TaskChatRecord.fromSnapshot(s));

  static TaskChatRecord fromSnapshot(DocumentSnapshot snapshot) =>
      TaskChatRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TaskChatRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TaskChatRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TaskChatRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TaskChatRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTaskChatRecordData({
  String? message,
  DocumentReference? taskRef,
  DocumentReference? assignor,
  DocumentReference? assignee,
  DateTime? time,
  String? name,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'message': message,
      'taskRef': taskRef,
      'assignor': assignor,
      'assignee': assignee,
      'time': time,
      'name': name,
    }.withoutNulls,
  );

  return firestoreData;
}

class TaskChatRecordDocumentEquality implements Equality<TaskChatRecord> {
  const TaskChatRecordDocumentEquality();

  @override
  bool equals(TaskChatRecord? e1, TaskChatRecord? e2) {
    return e1?.message == e2?.message &&
        e1?.taskRef == e2?.taskRef &&
        e1?.assignor == e2?.assignor &&
        e1?.assignee == e2?.assignee &&
        e1?.time == e2?.time &&
        e1?.name == e2?.name;
  }

  @override
  int hash(TaskChatRecord? e) => const ListEquality().hash(
      [e?.message, e?.taskRef, e?.assignor, e?.assignee, e?.time, e?.name]);

  @override
  bool isValidKey(Object? o) => o is TaskChatRecord;
}
