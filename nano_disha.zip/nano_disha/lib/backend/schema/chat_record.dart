import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChatRecord extends FirestoreRecord {
  ChatRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "jai" field.
  String? _jai;
  String get jai => _jai ?? '';
  bool hasJai() => _jai != null;

  // "sender" field.
  String? _sender;
  String get sender => _sender ?? '';
  bool hasSender() => _sender != null;

  // "receiver" field.
  String? _receiver;
  String get receiver => _receiver ?? '';
  bool hasReceiver() => _receiver != null;

  // "lastmessage" field.
  String? _lastmessage;
  String get lastmessage => _lastmessage ?? '';
  bool hasLastmessage() => _lastmessage != null;

  // "username" field.
  List<String>? _username;
  List<String> get username => _username ?? const [];
  bool hasUsername() => _username != null;

  // "timestamp" field.
  String? _timestamp;
  String get timestamp => _timestamp ?? '';
  bool hasTimestamp() => _timestamp != null;

  void _initializeFields() {
    _jai = snapshotData['jai'] as String?;
    _sender = snapshotData['sender'] as String?;
    _receiver = snapshotData['receiver'] as String?;
    _lastmessage = snapshotData['lastmessage'] as String?;
    _username = getDataList(snapshotData['username']);
    _timestamp = snapshotData['timestamp'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('chat');

  static Stream<ChatRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ChatRecord.fromSnapshot(s));

  static Future<ChatRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ChatRecord.fromSnapshot(s));

  static ChatRecord fromSnapshot(DocumentSnapshot snapshot) => ChatRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ChatRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ChatRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ChatRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ChatRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChatRecordData({
  String? jai,
  String? sender,
  String? receiver,
  String? lastmessage,
  String? timestamp,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'jai': jai,
      'sender': sender,
      'receiver': receiver,
      'lastmessage': lastmessage,
      'timestamp': timestamp,
    }.withoutNulls,
  );

  return firestoreData;
}

class ChatRecordDocumentEquality implements Equality<ChatRecord> {
  const ChatRecordDocumentEquality();

  @override
  bool equals(ChatRecord? e1, ChatRecord? e2) {
    const listEquality = ListEquality();
    return e1?.jai == e2?.jai &&
        e1?.sender == e2?.sender &&
        e1?.receiver == e2?.receiver &&
        e1?.lastmessage == e2?.lastmessage &&
        listEquality.equals(e1?.username, e2?.username) &&
        e1?.timestamp == e2?.timestamp;
  }

  @override
  int hash(ChatRecord? e) => const ListEquality().hash([
        e?.jai,
        e?.sender,
        e?.receiver,
        e?.lastmessage,
        e?.username,
        e?.timestamp
      ]);

  @override
  bool isValidKey(Object? o) => o is ChatRecord;
}
