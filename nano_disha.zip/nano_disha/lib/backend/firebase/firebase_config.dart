import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDDVGwyXuLQw2_WUVi7280d3360peolMVQ",
            authDomain: "nanodisha-npx.firebaseapp.com",
            projectId: "nanodisha-npx",
            storageBucket: "nanodisha-npx.firebasestorage.app",
            messagingSenderId: "228552367534",
            appId: "1:228552367534:web:c35bd6e596e24df5e9bc3f"));
  } else {
    await Firebase.initializeApp();
  }
}
