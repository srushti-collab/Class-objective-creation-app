// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Firebase imports
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

Future<String> createClient(
    String emailAddress,
    String password,
    String randomDocGen,
    String fullName,
    String staffNumber,
    String department,
    String designation,
    String phoneNumber,
    String email,
    String photoUrl,
    bool isActive,
    bool canReview) async {
  String returnMsg = 'Success';
  String defaultPassword = "Nano@2025";
  DateTime createdTime = DateTime.now();

  FirebaseApp app = await Firebase.initializeApp(
      name: randomDocGen, options: Firebase.app().options);

  try {
    // ✅ Check if the email exists in Firestore 'users' collection
    final CollectionReference<Map<String, dynamic>> usersRef =
        FirebaseFirestore.instance.collection('users');

    QuerySnapshot querySnapshot =
        await usersRef.where('email', isEqualTo: emailAddress).get();

    if (querySnapshot.docs.isNotEmpty) {
      return "Error: Email already in use"; // ✅ Custom error message
    }

    // ✅ Check if email exists in Firebase Auth
    List<String> signInMethods =
        await FirebaseAuth.instance.fetchSignInMethodsForEmail(emailAddress);

    if (signInMethods.isNotEmpty) {
      return "Error: Email already in use"; // ✅ Ensuring duplicate check
    }

    // ✅ Create the user with Firebase Authentication
    UserCredential userCredential = await FirebaseAuth.instanceFor(app: app)
        .createUserWithEmailAndPassword(
            email: emailAddress, password: password);

    String? uid = userCredential.user?.uid;

    if (uid != null) {
      // ✅ Add user data to Firestore
      await usersRef.doc(uid).set({
        'uid': uid,
        'email': emailAddress,
        'created_time': createdTime,
        'display_name': fullName,
        'photo_url': photoUrl,
        'phone_number': phoneNumber,
        'StaffNumberstrign': staffNumber,
        'department': department,
        'role': designation,
        'active': isActive,
        'Reviewability': canReview,
        'created_at': FieldValue.serverTimestamp(),
        'password': defaultPassword
      });

      return returnMsg;
    } else {
      return "Error: UID creation failed";
    }
  } on FirebaseAuthException catch (e) {
    if (e.code == 'email-already-in-use') {
      return "Error: Email already in use"; // ✅ Firebase error handling
    }
    return "Error: ${e.message}"; // ✅ Generic error message
  }
}
