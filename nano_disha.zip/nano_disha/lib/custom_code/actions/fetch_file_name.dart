// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:firebase_storage/firebase_storage.dart';

import 'package:file_picker/file_picker.dart';

List<String> selectedFileNames = []; // Store file names before upload

// Function to select files and store their names
Future<void> pickFiles() async {
  FilePickerResult? result =
      await FilePicker.platform.pickFiles(allowMultiple: true);

  if (result != null) {
    selectedFileNames =
        result.files.map((file) => file.name).toList(); // Store filenames
    print("Selected Files: $selectedFileNames"); // Debugging
  }
}

Future<List<String>> fetchFileName(List<String> fileUrls) async {
  return fileUrls.map((fileUrl) {
    Uri uri = Uri.parse(fileUrl);
    return uri.pathSegments.last.split('?').first; // Extracts only the filename
  }).toList();
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
