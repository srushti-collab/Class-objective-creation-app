// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';

Future<List<FFUploadedFile>?> documentPicker() async {
  final selectedFiles = await selectFiles(
    allowedExtensions: ['pdf', 'png', 'jpg'],
    multiFile: true,
  );

  if (selectedFiles == null || selectedFiles.isEmpty) {
    return null;
  }

  List<FFUploadedFile> selectedUploadedFiles = [];
  List<String> fileNames = [];

  for (var file in selectedFiles) {
    selectedUploadedFiles.add(
      FFUploadedFile(
        name: file.storagePath,
        bytes: file.bytes,
      ),
    );
    fileNames.add(file.storagePath);
  }

  FFAppState().fileNames =
      fileNames; // Store the list of filenames in app state
  return selectedUploadedFiles;
}

Future<List<SelectedFile>?> selectFiles({
  String? storageFolderPath,
  List<String>? allowedExtensions,
  bool multiFile = false,
}) async {
  final pickedFiles = await FilePicker.platform.pickFiles(
    type: allowedExtensions != null ? FileType.custom : FileType.any,
    allowedExtensions: allowedExtensions,
    withData: true,
    allowMultiple: multiFile,
  );

  if (pickedFiles == null || pickedFiles.files.isEmpty) {
    return null;
  }

  return pickedFiles.files.map((file) {
    return SelectedFile(
      storagePath: file.name,
      filePath: file.path,
      bytes: file.bytes!,
    );
  }).toList();
}

class SelectedFile {
  const SelectedFile({
    required this.storagePath,
    this.filePath,
    required this.bytes,
    this.dimensions,
    this.blurHash,
  });

  final String storagePath;
  final String? filePath;
  final Uint8List bytes;
  final MediaDimensions? dimensions;
  final String? blurHash;
}

class MediaDimensions {
  const MediaDimensions({
    this.height,
    this.width,
  });

  final double? height;
  final double? width;
}
