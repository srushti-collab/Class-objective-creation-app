// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// PDF package imports
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'dart:typed_data';

Future<FFUploadedFile> reportGenerator(String title, String message) async {
  final pdf = pw.Document();

  pdf.addPage(
    pw.Page(
      pageFormat: PdfPageFormat.a4,
      margin: pw.EdgeInsets.all(32),
      build: (pw.Context context) {
        return pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(DateTime.now().toString(),
                style: pw.TextStyle(fontSize: 12, color: PdfColors.black)),
            pw.SizedBox(height: 10),
            pw.Divider(thickness: 3),
            pw.SizedBox(height: 10),
            pw.Text(title,
                style: pw.TextStyle(fontSize: 24, color: PdfColors.blue)),
            pw.SizedBox(height: 10),
            pw.Divider(thickness: 3),
            pw.SizedBox(height: 10),
            pw.Text(message,
                style: pw.TextStyle(fontSize: 16, color: PdfColors.green)),
            pw.SizedBox(height: 10),
            pw.Divider(thickness: 3),
            pw.SizedBox(height: 10),
            pw.TableHelper.fromTextArray(
              context: context,
              data: [
                ['Item', 'Count'],
                ['Apple', '3'],
                ['Celery', '10'],
                ['Potato', '4'],
                ['Chicken', '12'],
              ],
            ),
          ],
        );
      },
    ),
  );

  final Uint8List pdfBytes = await pdf.save();
  final uploadedFile = FFUploadedFile(
    bytes: pdfBytes,
    name: 'report.pdf',
  );

  return uploadedFile;
}
