// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Additional imports
import 'dart:typed_data';
import 'package:excel/excel.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

Future<String?> exportTasksToExcel(List<DocumentReference>? tasksRecord) async {
  if (tasksRecord == null || tasksRecord.isEmpty) {
    debugPrint("No tasks to export.");
    return null;
  }

  try {
    debugPrint("Starting Excel export...");

    // Create a new Excel document
    var excel = Excel.createExcel();
    var sheet = excel[excel.getDefaultSheet()!];

    // Add headers
    sheet.appendRow(["Title", "Description", "Due Date"]);

    // Fetch task details
    for (var taskRef in tasksRecord) {
      debugPrint("Fetching task: ${taskRef.id}");

      var taskSnapshot = await taskRef.get();
      if (taskSnapshot.exists) {
        var taskData = taskSnapshot.data() as Map<String, dynamic>;
        debugPrint("Task Data: $taskData");

        String title = taskData['title'] ?? 'Untitled';
        String description = taskData['description'] ?? 'No Description';
        String dueDate = taskData['dueDate'] is Timestamp
            ? (taskData['dueDate'] as Timestamp).toDate().toString()
            : 'No Date';

        sheet.appendRow([title, description, dueDate]);
      } else {
        debugPrint("Task ${taskRef.id} does not exist!");
      }
    }

    // Save Excel file to bytes
    List<int>? bytes = excel.encode();
    if (bytes == null) {
      debugPrint("Excel encoding failed!");
      return null;
    }
    Uint8List uint8List = Uint8List.fromList(bytes);

    // Upload to Firebase Storage
    String fileName =
        "tasks_export_${DateTime.now().millisecondsSinceEpoch}.xlsx";
    Reference ref = FirebaseStorage.instance.ref().child("exports/$fileName");

    debugPrint("Uploading to Firebase...");
    UploadTask uploadTask = ref.putData(uint8List);
    TaskSnapshot taskSnapshot = await uploadTask;
    debugPrint("Upload Complete!");

    // Get download URL
    String downloadUrl = await taskSnapshot.ref.getDownloadURL();
    debugPrint("Download URL: $downloadUrl");

    return downloadUrl;
  } catch (e) {
    debugPrint("Error exporting to Excel: $e");
    return null;
  }
}
