import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/image_prof_widget.dart';
import '/components/options_widget.dart';
import '/components/text_prof_widget.dart';
import '/components/video_prof_widget.dart';
import '/components/voice_prof_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'jam_board1_widget.dart' show JamBoard1Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class JamBoard1Model extends FlutterFlowModel<JamBoard1Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
