import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/chat_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/manager/add_o_b_j/add_o_b_j_widget.dart';
import '/nano_track/gogleint/gogleint_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'd_a_s_h_h_y_y_y_copy_copy_widget.dart' show DASHHYYYCopyCopyWidget;
import 'package:flutter/material.dart';
import 'package:flutter_app_badger/flutter_app_badger.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DASHHYYYCopyCopyModel extends FlutterFlowModel<DASHHYYYCopyCopyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
