import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'total_widget.dart' show TotalWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TotalModel extends FlutterFlowModel<TotalWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for TextFieldTOTAL widget.
  FocusNode? textFieldTOTALFocusNode;
  TextEditingController? textFieldTOTALTextController;
  String? Function(BuildContext, String?)?
      textFieldTOTALTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldTOTALFocusNode?.dispose();
    textFieldTOTALTextController?.dispose();
  }
}
