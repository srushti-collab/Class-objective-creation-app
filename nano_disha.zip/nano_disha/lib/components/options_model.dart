import '/components/scribble_widget.dart';
import '/components/text_jam_widget.dart';
import '/components/uploadimage_widget.dart';
import '/components/uploadvideo_widget.dart';
import '/components/voice_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'options_widget.dart' show OptionsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class OptionsModel extends FlutterFlowModel<OptionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
