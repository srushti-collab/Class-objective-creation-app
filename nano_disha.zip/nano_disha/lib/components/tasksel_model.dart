import '/backend/backend.dart';
import '/components/repetativetask_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/nano_track/create_task_copy/create_task_copy_widget.dart';
import 'dart:ui';
import 'tasksel_widget.dart' show TaskselWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TaskselModel extends FlutterFlowModel<TaskselWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
