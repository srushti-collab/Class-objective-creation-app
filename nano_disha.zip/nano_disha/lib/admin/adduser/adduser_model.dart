import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import 'adduser_widget.dart' show AdduserWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AdduserModel extends FlutterFlowModel<AdduserWidget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController1;
  String? Function(BuildContext, String?)? textController1Validator;
  // State field(s) for TextFieldSTAFF widget.
  FocusNode? textFieldSTAFFFocusNode;
  TextEditingController? textFieldSTAFFTextController;
  String? Function(BuildContext, String?)?
      textFieldSTAFFTextControllerValidator;
  // State field(s) for DropDownDep widget.
  String? dropDownDepValue;
  FormFieldController<String>? dropDownDepValueController;
  // State field(s) for DropDownPos widget.
  String? dropDownPosValue;
  FormFieldController<String>? dropDownPosValueController;
  // State field(s) for TextFieldPhn widget.
  FocusNode? textFieldPhnFocusNode;
  TextEditingController? textFieldPhnTextController;
  String? Function(BuildContext, String?)? textFieldPhnTextControllerValidator;
  String? _textFieldPhnTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'fd2zarl7' /* Field is required */,
      );
    }

    return null;
  }

  // State field(s) for TextFieldEmail widget.
  FocusNode? textFieldEmailFocusNode;
  TextEditingController? textFieldEmailTextController;
  String? Function(BuildContext, String?)?
      textFieldEmailTextControllerValidator;
  String? _textFieldEmailTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        '5tyta4mc' /* Field is required */,
      );
    }

    if (!RegExp(kTextValidatorEmailRegex).hasMatch(val)) {
      return FFLocalizations.of(context).getText(
        'cb4qufai' /* Email is required */,
      );
    }
    return null;
  }

  // State field(s) for TextFieldPass widget.
  FocusNode? textFieldPassFocusNode;
  TextEditingController? textFieldPassTextController;
  late bool textFieldPassVisibility;
  String? Function(BuildContext, String?)? textFieldPassTextControllerValidator;
  // State field(s) for TextFieldConfPass widget.
  FocusNode? textFieldConfPassFocusNode;
  TextEditingController? textFieldConfPassTextController;
  late bool textFieldConfPassVisibility;
  String? Function(BuildContext, String?)?
      textFieldConfPassTextControllerValidator;
  // State field(s) for Switch widget.
  bool? switchValue;
  // State field(s) for Checkbox widget.
  bool? checkboxValue;

  @override
  void initState(BuildContext context) {
    textFieldPhnTextControllerValidator = _textFieldPhnTextControllerValidator;
    textFieldEmailTextControllerValidator =
        _textFieldEmailTextControllerValidator;
    textFieldPassVisibility = false;
    textFieldConfPassVisibility = false;
  }

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController1?.dispose();

    textFieldSTAFFFocusNode?.dispose();
    textFieldSTAFFTextController?.dispose();

    textFieldPhnFocusNode?.dispose();
    textFieldPhnTextController?.dispose();

    textFieldEmailFocusNode?.dispose();
    textFieldEmailTextController?.dispose();

    textFieldPassFocusNode?.dispose();
    textFieldPassTextController?.dispose();

    textFieldConfPassFocusNode?.dispose();
    textFieldConfPassTextController?.dispose();
  }
}
