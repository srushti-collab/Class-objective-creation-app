// Export pages
export '/admin/login_page/login_page_widget.dart' show LoginPageWidget;
export '/nano_track/reports/reports_widget.dart' show ReportsWidget;
export '/nano_track/sub_o_b_j/sub_o_b_j_widget.dart' show SubOBJWidget;
export '/nano_track/manger_level/dashhyyy/dashhyyy_widget.dart'
    show DashhyyyWidget;
export '/nano_track/objectives/objectives_widget.dart' show ObjectivesWidget;
export '/nano_track/detailyyy/detailyyy_widget.dart' show DetailyyyWidget;
export '/nano_track/detailyyy_copy/detailyyy_copy_widget.dart'
    show DetailyyyCopyWidget;
export '/manager/taskyy/taskyy_widget.dart' show TaskyyWidget;
export '/owner/employeeee/employeeee_widget.dart' show EmployeeeeWidget;
export '/owner/manager_dashyy/manager_dashyy_widget.dart'
    show ManagerDashyyWidget;
export '/nano_track/assigned_obj/assigned_obj_widget.dart'
    show AssignedObjWidget;
export '/owner/detailyy_owner/detailyy_owner_widget.dart'
    show DetailyyOwnerWidget;
export '/detailyy_copy_owner/detailyy_copy_owner_widget.dart'
    show DetailyyCopyOwnerWidget;
export '/owner/o_b_j_y_yowner/o_b_j_y_yowner_widget.dart' show OBJYYownerWidget;
export '/owner/d_a_s_h_y_yowner/d_a_s_h_y_yowner_widget.dart'
    show DASHYYownerWidget;
export '/chatpag/chatpag_widget.dart' show ChatpagWidget;
export '/nano_track/employeedash/employeedash_widget.dart'
    show EmployeedashWidget;
export '/nano_track/taskyyemployee/taskyyemployee_widget.dart'
    show TaskyyemployeeWidget;
export '/nano_track/employee/taskyyemployee_copy/taskyyemployee_copy_widget.dart'
    show TaskyyemployeeCopyWidget;
export '/owner/o_b_j_y_yowner_copy/o_b_j_y_yowner_copy_widget.dart'
    show OBJYYownerCopyWidget;
export '/nano_track/detailyyy_copy_copy/detailyyy_copy_copy_widget.dart'
    show DetailyyyCopyCopyWidget;
export '/nano_track/taskyy_copy/taskyy_copy_widget.dart' show TaskyyCopyWidget;
export '/progress/progress_widget.dart' show ProgressWidget;
export '/nano_track/taskyy_copy2/taskyy_copy2_widget.dart'
    show TaskyyCopy2Widget;
export '/noti/noti_widget.dart' show NotiWidget;
export '/nano_track/reportsemployee/reportsemployee_widget.dart'
    show ReportsemployeeWidget;
export '/progressemployee/progressemployee_widget.dart'
    show ProgressemployeeWidget;
export '/owner/employee_dashyyy/employee_dashyyy_widget.dart'
    show EmployeeDashyyyWidget;
export '/manager/chil_obj/chil_obj_widget.dart' show ChilObjWidget;
export '/manager/manager_objective/manager_objective_widget.dart'
    show ManagerObjectiveWidget;
export '/calendar/calendar_widget.dart' show CalendarWidget;
export '/scheduletask/scheduletask_widget.dart' show ScheduletaskWidget;
export '/manager/task_profile_page/task_profile_page_widget.dart'
    show TaskProfilePageWidget;
export '/nano_track/reviewpage/reviewpage_widget.dart' show ReviewpageWidget;
export '/manager/reviewprofilepage/reviewprofilepage_widget.dart'
    show ReviewprofilepageWidget;
export '/nano_track/employeeprofile/employeeprofile_widget.dart'
    show EmployeeprofileWidget;
export '/admin/admin_dashboard/admin_dashboard_widget.dart'
    show AdminDashboardWidget;
export '/nano_track/d_a_s_h_h_y_y_y_copy_copy/d_a_s_h_h_y_y_y_copy_copy_widget.dart'
    show DASHHYYYCopyCopyWidget;
export '/staff/employee_dashboard/employee_dashboard_widget.dart'
    show EmployeeDashboardWidget;
export '/manager/manager_dashboard/manager_dashboard_widget.dart'
    show ManagerDashboardWidget;
export '/admin/employeee_manage_page/employeee_manage_page_widget.dart'
    show EmployeeeManagePageWidget;
export '/admin/emp_profile/emp_profile_widget.dart' show EmpProfileWidget;
export '/profile_page/profile_page_widget.dart' show ProfilePageWidget;
export '/admin/adminprofile/adminprofile_widget.dart' show AdminprofileWidget;
export '/nano_track/h_r_dashboard/h_r_dashboard_widget.dart'
    show HRDashboardWidget;
export '/manager/task_assignor_page/task_assignor_page_widget.dart'
    show TaskAssignorPageWidget;
export '/reports_and_analytics/reports_and_analytics_widget.dart'
    show ReportsAndAnalyticsWidget;
export '/manager/public_child_obj/public_child_obj_widget.dart'
    show PublicChildObjWidget;
export '/manager/task_review/task_review_widget.dart' show TaskReviewWidget;
export '/task_management/task_management_widget.dart' show TaskManagementWidget;
export '/staff/taskyy_copy3/taskyy_copy3_widget.dart' show TaskyyCopy3Widget;
export '/manager/my_task_page/my_task_page_widget.dart' show MyTaskPageWidget;
export '/manager/mytask1/mytask1_widget.dart' show Mytask1Widget;
export '/manager/task_assignee_page/task_assignee_page_widget.dart'
    show TaskAssigneePageWidget;
export '/manager/task_revier_page/task_revier_page_widget.dart'
    show TaskRevierPageWidget;
export '/jam_board/jam_board_widget.dart' show JamBoardWidget;
export '/jam_board1/jam_board1_widget.dart' show JamBoard1Widget;
export '/scribble_prof/scribble_prof_widget.dart' show ScribbleProfWidget;
export '/manager/managerobjphone/managerobjphone_widget.dart'
    show ManagerobjphoneWidget;
export '/manager/childobjphone/childobjphone_widget.dart'
    show ChildobjphoneWidget;
export '/nano_track/objectivesphone/objectivesphone_widget.dart'
    show ObjectivesphoneWidget;
export '/manager/managerobjphone2/managerobjphone2_widget.dart'
    show Managerobjphone2Widget;
export '/manager/taskyyphn/taskyyphn_widget.dart' show TaskyyphnWidget;
export '/manager/task_assigneephone/task_assigneephone_widget.dart'
    show TaskAssigneephoneWidget;
export '/manager/chil_obj_copy/chil_obj_copy_widget.dart'
    show ChilObjCopyWidget;
export '/admin/manage_u_sers_admin_page/manage_u_sers_admin_page_widget.dart'
    show ManageUSersAdminPageWidget;
export '/admin/noti_copy/noti_copy_widget.dart' show NotiCopyWidget;
export '/notification_page/notification_page_widget.dart'
    show NotificationPageWidget;
export '/manager/staff_dashboard/staff_dashboard_widget.dart'
    show StaffDashboardWidget;
export '/manager/taskyy_copy4/taskyy_copy4_widget.dart' show TaskyyCopy4Widget;
export '/manager/task_assignor_page_copy/task_assignor_page_copy_widget.dart'
    show TaskAssignorPageCopyWidget;
export '/trail/trail_widget.dart' show TrailWidget;
export '/task_phone_view/task_phone_view_widget.dart' show TaskPhoneViewWidget;
