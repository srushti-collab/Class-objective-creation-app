import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';

import '/auth/base_auth_user_provider.dart';

import '/backend/push_notifications/push_notifications_handler.dart'
    show PushNotificationsHandler;
import '/main.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'serialization_util.dart';

import '/index.dart';

export 'package:go_router/go_router.dart';
export 'serialization_util.dart';

const kTransitionInfoKey = '__transition_info__';

GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

class AppStateNotifier extends ChangeNotifier {
  AppStateNotifier._();

  static AppStateNotifier? _instance;
  static AppStateNotifier get instance => _instance ??= AppStateNotifier._();

  BaseAuthUser? initialUser;
  BaseAuthUser? user;
  bool showSplashImage = true;
  String? _redirectLocation;

  /// Determines whether the app will refresh and build again when a sign
  /// in or sign out happens. This is useful when the app is launched or
  /// on an unexpected logout. However, this must be turned off when we
  /// intend to sign in/out and then navigate or perform any actions after.
  /// Otherwise, this will trigger a refresh and interrupt the action(s).
  bool notifyOnAuthChange = true;

  bool get loading => user == null || showSplashImage;
  bool get loggedIn => user?.loggedIn ?? false;
  bool get initiallyLoggedIn => initialUser?.loggedIn ?? false;
  bool get shouldRedirect => loggedIn && _redirectLocation != null;

  String getRedirectLocation() => _redirectLocation!;
  bool hasRedirect() => _redirectLocation != null;
  void setRedirectLocationIfUnset(String loc) => _redirectLocation ??= loc;
  void clearRedirectLocation() => _redirectLocation = null;

  /// Mark as not needing to notify on a sign in / out when we intend
  /// to perform subsequent actions (such as navigation) afterwards.
  void updateNotifyOnAuthChange(bool notify) => notifyOnAuthChange = notify;

  void update(BaseAuthUser newUser) {
    final shouldUpdate =
        user?.uid == null || newUser.uid == null || user?.uid != newUser.uid;
    initialUser ??= newUser;
    user = newUser;
    // Refresh the app on auth change unless explicitly marked otherwise.
    // No need to update unless the user has changed.
    if (notifyOnAuthChange && shouldUpdate) {
      notifyListeners();
    }
    // Once again mark the notifier as needing to update on auth change
    // (in order to catch sign in / out events).
    updateNotifyOnAuthChange(true);
  }

  void stopShowingSplashImage() {
    showSplashImage = false;
    notifyListeners();
  }
}

GoRouter createRouter(AppStateNotifier appStateNotifier) => GoRouter(
      initialLocation: '/',
      debugLogDiagnostics: true,
      refreshListenable: appStateNotifier,
      navigatorKey: appNavigatorKey,
      errorBuilder: (context, state) => appStateNotifier.loggedIn
          ? ManagerDashboardWidget()
          : LoginPageWidget(),
      routes: [
        FFRoute(
          name: '_initialize',
          path: '/',
          builder: (context, _) => appStateNotifier.loggedIn
              ? ManagerDashboardWidget()
              : LoginPageWidget(),
        ),
        FFRoute(
          name: LoginPageWidget.routeName,
          path: LoginPageWidget.routePath,
          builder: (context, params) => LoginPageWidget(),
        ),
        FFRoute(
          name: ReportsWidget.routeName,
          path: ReportsWidget.routePath,
          builder: (context, params) => ReportsWidget(),
        ),
        FFRoute(
          name: SubOBJWidget.routeName,
          path: SubOBJWidget.routePath,
          builder: (context, params) => SubOBJWidget(),
        ),
        FFRoute(
          name: DashhyyyWidget.routeName,
          path: DashhyyyWidget.routePath,
          builder: (context, params) => DashhyyyWidget(),
        ),
        FFRoute(
          name: ObjectivesWidget.routeName,
          path: ObjectivesWidget.routePath,
          builder: (context, params) => ObjectivesWidget(),
        ),
        FFRoute(
          name: DetailyyyWidget.routeName,
          path: DetailyyyWidget.routePath,
          builder: (context, params) => DetailyyyWidget(
            projectRef: params.getParam(
              'projectRef',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            projTitle: params.getParam(
              'projTitle',
              ParamType.String,
            ),
            projDesc: params.getParam(
              'projDesc',
              ParamType.String,
            ),
            startDate: params.getParam(
              'startDate',
              ParamType.DateTime,
            ),
            endDate: params.getParam(
              'endDate',
              ParamType.DateTime,
            ),
            progress: params.getParam(
              'progress',
              ParamType.int,
            ),
            projOwn: params.getParam(
              'projOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            ownername: params.getParam(
              'ownername',
              ParamType.String,
            ),
            parentOwn: params.getParam(
              'parentOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            progressbar: params.getParam(
              'progressbar',
              ParamType.int,
            ),
            taskrefrence: params.getParam(
              'taskrefrence',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['task'],
            ),
            type: params.getParam(
              'type',
              ParamType.String,
            ),
            weightage: params.getParam(
              'weightage',
              ParamType.int,
            ),
          ),
        ),
        FFRoute(
          name: DetailyyyCopyWidget.routeName,
          path: DetailyyyCopyWidget.routePath,
          builder: (context, params) => DetailyyyCopyWidget(
            projectRef: params.getParam(
              'projectRef',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            projTitle: params.getParam(
              'projTitle',
              ParamType.String,
            ),
            planTitle: params.getParam(
              'planTitle',
              ParamType.String,
            ),
            planDesc: params.getParam(
              'planDesc',
              ParamType.String,
            ),
            startDate: params.getParam(
              'startDate',
              ParamType.DateTime,
            ),
            endTime: params.getParam(
              'endTime',
              ParamType.DateTime,
            ),
            planRef: params.getParam(
              'planRef',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['plans'],
            ),
            projMan: params.getParam(
              'projMan',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            owner: params.getParam(
              'owner',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            ownerName: params.getParam(
              'ownerName',
              ParamType.String,
            ),
            parentOwn: params.getParam(
              'parentOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
          ),
        ),
        FFRoute(
          name: TaskyyWidget.routeName,
          path: TaskyyWidget.routePath,
          builder: (context, params) => TaskyyWidget(),
        ),
        FFRoute(
          name: EmployeeeeWidget.routeName,
          path: EmployeeeeWidget.routePath,
          builder: (context, params) => EmployeeeeWidget(),
        ),
        FFRoute(
          name: ManagerDashyyWidget.routeName,
          path: ManagerDashyyWidget.routePath,
          builder: (context, params) => ManagerDashyyWidget(),
        ),
        FFRoute(
          name: AssignedObjWidget.routeName,
          path: AssignedObjWidget.routePath,
          builder: (context, params) => AssignedObjWidget(
            progress: params.getParam(
              'progress',
              ParamType.double,
            ),
          ),
        ),
        FFRoute(
          name: DetailyyOwnerWidget.routeName,
          path: DetailyyOwnerWidget.routePath,
          builder: (context, params) => DetailyyOwnerWidget(
            projectRef: params.getParam(
              'projectRef',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            projTitle: params.getParam(
              'projTitle',
              ParamType.String,
            ),
            projDesc: params.getParam(
              'projDesc',
              ParamType.String,
            ),
            startDate: params.getParam(
              'startDate',
              ParamType.DateTime,
            ),
            endDate: params.getParam(
              'endDate',
              ParamType.DateTime,
            ),
            progress: params.getParam(
              'progress',
              ParamType.int,
            ),
            projOwn: params.getParam(
              'projOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            ownername: params.getParam(
              'ownername',
              ParamType.String,
            ),
            parentOwn: params.getParam(
              'parentOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
          ),
        ),
        FFRoute(
          name: DetailyyCopyOwnerWidget.routeName,
          path: DetailyyCopyOwnerWidget.routePath,
          builder: (context, params) => DetailyyCopyOwnerWidget(
            projectRef: params.getParam(
              'projectRef',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            projTitle: params.getParam(
              'projTitle',
              ParamType.String,
            ),
            planTitle: params.getParam(
              'planTitle',
              ParamType.String,
            ),
            planDesc: params.getParam(
              'planDesc',
              ParamType.String,
            ),
            startDate: params.getParam(
              'startDate',
              ParamType.DateTime,
            ),
            endTime: params.getParam(
              'endTime',
              ParamType.DateTime,
            ),
            planRef: params.getParam(
              'planRef',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['plans'],
            ),
            projMan: params.getParam(
              'projMan',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            owner: params.getParam(
              'owner',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            ownerName: params.getParam(
              'ownerName',
              ParamType.String,
            ),
            parentOwn: params.getParam(
              'parentOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
          ),
        ),
        FFRoute(
          name: OBJYYownerWidget.routeName,
          path: OBJYYownerWidget.routePath,
          builder: (context, params) => OBJYYownerWidget(),
        ),
        FFRoute(
          name: DASHYYownerWidget.routeName,
          path: DASHYYownerWidget.routePath,
          builder: (context, params) => DASHYYownerWidget(),
        ),
        FFRoute(
          name: ChatpagWidget.routeName,
          path: ChatpagWidget.routePath,
          builder: (context, params) => ChatpagWidget(
            chatresc: params.getParam(
              'chatresc',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
          ),
        ),
        FFRoute(
          name: EmployeedashWidget.routeName,
          path: EmployeedashWidget.routePath,
          builder: (context, params) => EmployeedashWidget(),
        ),
        FFRoute(
          name: TaskyyemployeeWidget.routeName,
          path: TaskyyemployeeWidget.routePath,
          builder: (context, params) => TaskyyemployeeWidget(
            tasktitle: params.getParam(
              'tasktitle',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: TaskyyemployeeCopyWidget.routeName,
          path: TaskyyemployeeCopyWidget.routePath,
          builder: (context, params) => TaskyyemployeeCopyWidget(
            tasktitle: params.getParam(
              'tasktitle',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: OBJYYownerCopyWidget.routeName,
          path: OBJYYownerCopyWidget.routePath,
          builder: (context, params) => OBJYYownerCopyWidget(),
        ),
        FFRoute(
          name: DetailyyyCopyCopyWidget.routeName,
          path: DetailyyyCopyCopyWidget.routePath,
          builder: (context, params) => DetailyyyCopyCopyWidget(
            planTitle: params.getParam(
              'planTitle',
              ParamType.String,
            ),
            planDesc: params.getParam(
              'planDesc',
              ParamType.String,
            ),
            startDate: params.getParam(
              'startDate',
              ParamType.DateTime,
            ),
            endTime: params.getParam(
              'endTime',
              ParamType.DateTime,
            ),
            owner: params.getParam(
              'owner',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            ownerName: params.getParam(
              'ownerName',
              ParamType.String,
            ),
            planref: params.getParam(
              'planref',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['plans'],
            ),
            projectref: params.getParam(
              'projectref',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            projecttitl: params.getParam(
              'projecttitl',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: TaskyyCopyWidget.routeName,
          path: TaskyyCopyWidget.routePath,
          builder: (context, params) => TaskyyCopyWidget(
            title: params.getParam(
              'title',
              ParamType.String,
            ),
            uploadeddoc: params.getParam(
              'uploadeddoc',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: ProgressWidget.routeName,
          path: ProgressWidget.routePath,
          builder: (context, params) => ProgressWidget(),
        ),
        FFRoute(
          name: TaskyyCopy2Widget.routeName,
          path: TaskyyCopy2Widget.routePath,
          builder: (context, params) => TaskyyCopy2Widget(),
        ),
        FFRoute(
          name: NotiWidget.routeName,
          path: NotiWidget.routePath,
          builder: (context, params) => NotiWidget(),
        ),
        FFRoute(
          name: ReportsemployeeWidget.routeName,
          path: ReportsemployeeWidget.routePath,
          builder: (context, params) => ReportsemployeeWidget(),
        ),
        FFRoute(
          name: ProgressemployeeWidget.routeName,
          path: ProgressemployeeWidget.routePath,
          builder: (context, params) => ProgressemployeeWidget(),
        ),
        FFRoute(
          name: EmployeeDashyyyWidget.routeName,
          path: EmployeeDashyyyWidget.routePath,
          requireAuth: true,
          builder: (context, params) => EmployeeDashyyyWidget(),
        ),
        FFRoute(
          name: ChilObjWidget.routeName,
          path: ChilObjWidget.routePath,
          builder: (context, params) => ChilObjWidget(
            projectRef: params.getParam(
              'projectRef',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            projTitle: params.getParam(
              'projTitle',
              ParamType.String,
            ),
            projDesc: params.getParam(
              'projDesc',
              ParamType.String,
            ),
            startDate: params.getParam(
              'startDate',
              ParamType.DateTime,
            ),
            endDate: params.getParam(
              'endDate',
              ParamType.DateTime,
            ),
            progress: params.getParam(
              'progress',
              ParamType.int,
            ),
            projOwn: params.getParam(
              'projOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            ownername: params.getParam(
              'ownername',
              ParamType.String,
            ),
            parentOwn: params.getParam(
              'parentOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            parentList: params.getParam<DocumentReference>(
              'parentList',
              ParamType.DocumentReference,
              isList: true,
              collectionNamePath: ['projects'],
            ),
            orgObj: params.getParam(
              'orgObj',
              ParamType.bool,
            ),
            parentIds: params.getParam<String>(
              'parentIds',
              ParamType.String,
              isList: true,
            ),
            type: params.getParam(
              'type',
              ParamType.String,
            ),
            weighatage: params.getParam(
              'weighatage',
              ParamType.int,
            ),
            subObjIDS: params.getParam<String>(
              'subObjIDS',
              ParamType.String,
              isList: true,
            ),
            hirarhielList: params.getParam<String>(
              'hirarhielList',
              ParamType.String,
              isList: true,
            ),
            status: params.getParam(
              'status',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: ManagerObjectiveWidget.routeName,
          path: ManagerObjectiveWidget.routePath,
          builder: (context, params) => ManagerObjectiveWidget(),
        ),
        FFRoute(
          name: CalendarWidget.routeName,
          path: CalendarWidget.routePath,
          builder: (context, params) => CalendarWidget(),
        ),
        FFRoute(
          name: ScheduletaskWidget.routeName,
          path: ScheduletaskWidget.routePath,
          builder: (context, params) => ScheduletaskWidget(
            taSK: params.getParam(
              'taSK',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['task'],
            ),
            starttim: params.getParam(
              'starttim',
              ParamType.DateTime,
            ),
            endtime: params.getParam(
              'endtime',
              ParamType.DateTime,
            ),
          ),
        ),
        FFRoute(
          name: TaskProfilePageWidget.routeName,
          path: TaskProfilePageWidget.routePath,
          builder: (context, params) => TaskProfilePageWidget(
            taskref: params.getParam(
              'taskref',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['task'],
            ),
            title: params.getParam(
              'title',
              ParamType.String,
            ),
            desc: params.getParam(
              'desc',
              ParamType.String,
            ),
            start: params.getParam(
              'start',
              ParamType.DateTime,
            ),
            end: params.getParam(
              'end',
              ParamType.DateTime,
            ),
          ),
        ),
        FFRoute(
          name: ReviewpageWidget.routeName,
          path: ReviewpageWidget.routePath,
          builder: (context, params) => ReviewpageWidget(
            title: params.getParam(
              'title',
              ParamType.String,
            ),
            uploadeddoc: params.getParam(
              'uploadeddoc',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: ReviewprofilepageWidget.routeName,
          path: ReviewprofilepageWidget.routePath,
          builder: (context, params) => ReviewprofilepageWidget(
            taskname: params.getParam(
              'taskname',
              ParamType.String,
            ),
            taskdesc: params.getParam(
              'taskdesc',
              ParamType.String,
            ),
            priority: params.getParam(
              'priority',
              ParamType.String,
            ),
            created: params.getParam(
              'created',
              ParamType.DateTime,
            ),
            duedate: params.getParam(
              'duedate',
              ParamType.DateTime,
            ),
            assignedby: params.getParam(
              'assignedby',
              ParamType.String,
            ),
            status: params.getParam(
              'status',
              ParamType.String,
            ),
            assignedto: params.getParam(
              'assignedto',
              ParamType.String,
            ),
            taskref: params.getParam(
              'taskref',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['task'],
            ),
            attachment: params.getParam(
              'attachment',
              ParamType.String,
            ),
            assignedbypic: params.getParam(
              'assignedbypic',
              ParamType.String,
            ),
            assignedtoimg: params.getParam(
              'assignedtoimg',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: EmployeeprofileWidget.routeName,
          path: EmployeeprofileWidget.routePath,
          builder: (context, params) => EmployeeprofileWidget(),
        ),
        FFRoute(
          name: AdminDashboardWidget.routeName,
          path: AdminDashboardWidget.routePath,
          builder: (context, params) => AdminDashboardWidget(),
        ),
        FFRoute(
          name: DASHHYYYCopyCopyWidget.routeName,
          path: DASHHYYYCopyCopyWidget.routePath,
          builder: (context, params) => DASHHYYYCopyCopyWidget(),
        ),
        FFRoute(
          name: EmployeeDashboardWidget.routeName,
          path: EmployeeDashboardWidget.routePath,
          builder: (context, params) => EmployeeDashboardWidget(),
        ),
        FFRoute(
          name: ManagerDashboardWidget.routeName,
          path: ManagerDashboardWidget.routePath,
          requireAuth: true,
          builder: (context, params) => ManagerDashboardWidget(),
        ),
        FFRoute(
          name: EmployeeeManagePageWidget.routeName,
          path: EmployeeeManagePageWidget.routePath,
          builder: (context, params) => EmployeeeManagePageWidget(),
        ),
        FFRoute(
          name: EmpProfileWidget.routeName,
          path: EmpProfileWidget.routePath,
          builder: (context, params) => EmpProfileWidget(
            empref: params.getParam(
              'empref',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            name: params.getParam(
              'name',
              ParamType.String,
            ),
            email: params.getParam(
              'email',
              ParamType.String,
            ),
            phobe: params.getParam(
              'phobe',
              ParamType.String,
            ),
            role: params.getParam(
              'role',
              ParamType.String,
            ),
            photourl: params.getParam(
              'photourl',
              ParamType.String,
            ),
            staffNumber: params.getParam(
              'staffNumber',
              ParamType.String,
            ),
            department: params.getParam(
              'department',
              ParamType.String,
            ),
            active: params.getParam(
              'active',
              ParamType.bool,
            ),
            reviewability: params.getParam(
              'reviewability',
              ParamType.bool,
            ),
          ),
        ),
        FFRoute(
          name: ProfilePageWidget.routeName,
          path: ProfilePageWidget.routePath,
          builder: (context, params) => ProfilePageWidget(),
        ),
        FFRoute(
          name: AdminprofileWidget.routeName,
          path: AdminprofileWidget.routePath,
          builder: (context, params) => AdminprofileWidget(
            authenref: params.getParam(
              'authenref',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
          ),
        ),
        FFRoute(
          name: HRDashboardWidget.routeName,
          path: HRDashboardWidget.routePath,
          builder: (context, params) => HRDashboardWidget(),
        ),
        FFRoute(
          name: TaskAssignorPageWidget.routeName,
          path: TaskAssignorPageWidget.routePath,
          builder: (context, params) => TaskAssignorPageWidget(
            taskref: params.getParam(
              'taskref',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['task'],
            ),
            taskbame: params.getParam(
              'taskbame',
              ParamType.String,
            ),
            taskdesc: params.getParam(
              'taskdesc',
              ParamType.String,
            ),
            due: params.getParam(
              'due',
              ParamType.DateTime,
            ),
            assigneee: params.getParam(
              'assigneee',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            status: params.getParam(
              'status',
              ParamType.String,
            ),
            priority: params.getParam(
              'priority',
              ParamType.String,
            ),
            projReference: params.getParam(
              'projReference',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            taskAssigneeName: params.getParam(
              'taskAssigneeName',
              ParamType.String,
            ),
            reviewability: params.getParam(
              'reviewability',
              ParamType.bool,
            ),
            reviwername: params.getParam(
              'reviwername',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: ReportsAndAnalyticsWidget.routeName,
          path: ReportsAndAnalyticsWidget.routePath,
          builder: (context, params) => ReportsAndAnalyticsWidget(),
        ),
        FFRoute(
          name: PublicChildObjWidget.routeName,
          path: PublicChildObjWidget.routePath,
          builder: (context, params) => PublicChildObjWidget(
            projectRef: params.getParam(
              'projectRef',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            projTitle: params.getParam(
              'projTitle',
              ParamType.String,
            ),
            projDesc: params.getParam(
              'projDesc',
              ParamType.String,
            ),
            startDate: params.getParam(
              'startDate',
              ParamType.DateTime,
            ),
            endDate: params.getParam(
              'endDate',
              ParamType.DateTime,
            ),
            progress: params.getParam(
              'progress',
              ParamType.int,
            ),
            projOwn: params.getParam(
              'projOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            ownername: params.getParam(
              'ownername',
              ParamType.String,
            ),
            parentOwn: params.getParam(
              'parentOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            parentList: params.getParam<DocumentReference>(
              'parentList',
              ParamType.DocumentReference,
              isList: true,
              collectionNamePath: ['projects'],
            ),
            orgObj: params.getParam(
              'orgObj',
              ParamType.bool,
            ),
            parentIds: params.getParam<String>(
              'parentIds',
              ParamType.String,
              isList: true,
            ),
            type: params.getParam(
              'type',
              ParamType.String,
            ),
            weightage: params.getParam(
              'weightage',
              ParamType.int,
            ),
          ),
        ),
        FFRoute(
          name: TaskReviewWidget.routeName,
          path: TaskReviewWidget.routePath,
          builder: (context, params) => TaskReviewWidget(),
        ),
        FFRoute(
          name: TaskManagementWidget.routeName,
          path: TaskManagementWidget.routePath,
          builder: (context, params) => TaskManagementWidget(),
        ),
        FFRoute(
          name: TaskyyCopy3Widget.routeName,
          path: TaskyyCopy3Widget.routePath,
          builder: (context, params) => TaskyyCopy3Widget(),
        ),
        FFRoute(
          name: MyTaskPageWidget.routeName,
          path: MyTaskPageWidget.routePath,
          builder: (context, params) => MyTaskPageWidget(
            taskref: params.getParam(
              'taskref',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['task'],
            ),
            taskbame: params.getParam(
              'taskbame',
              ParamType.String,
            ),
            taskdesc: params.getParam(
              'taskdesc',
              ParamType.String,
            ),
            due: params.getParam(
              'due',
              ParamType.DateTime,
            ),
            assigneee: params.getParam(
              'assigneee',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            status: params.getParam(
              'status',
              ParamType.String,
            ),
            priority: params.getParam(
              'priority',
              ParamType.String,
            ),
            projReference: params.getParam(
              'projReference',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            taskAssigneeName: params.getParam(
              'taskAssigneeName',
              ParamType.String,
            ),
            reviewability: params.getParam(
              'reviewability',
              ParamType.bool,
            ),
            taskAssignedBy: params.getParam(
              'taskAssignedBy',
              ParamType.String,
            ),
            accept: params.getParam(
              'accept',
              ParamType.bool,
            ),
          ),
        ),
        FFRoute(
          name: Mytask1Widget.routeName,
          path: Mytask1Widget.routePath,
          builder: (context, params) => Mytask1Widget(
            taskref: params.getParam(
              'taskref',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['task'],
            ),
            taskname: params.getParam(
              'taskname',
              ParamType.String,
            ),
            desc: params.getParam(
              'desc',
              ParamType.String,
            ),
            prior: params.getParam(
              'prior',
              ParamType.String,
            ),
            due: params.getParam(
              'due',
              ParamType.DateTime,
            ),
            reviewer: params.getParam(
              'reviewer',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: TaskAssigneePageWidget.routeName,
          path: TaskAssigneePageWidget.routePath,
          builder: (context, params) => TaskAssigneePageWidget(
            taskref: params.getParam(
              'taskref',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['task'],
            ),
            taskbame: params.getParam(
              'taskbame',
              ParamType.String,
            ),
            taskdesc: params.getParam(
              'taskdesc',
              ParamType.String,
            ),
            due: params.getParam(
              'due',
              ParamType.DateTime,
            ),
            assigneee: params.getParam(
              'assigneee',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            status: params.getParam(
              'status',
              ParamType.String,
            ),
            priority: params.getParam(
              'priority',
              ParamType.String,
            ),
            projReference: params.getParam(
              'projReference',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            taskAssigneeName: params.getParam(
              'taskAssigneeName',
              ParamType.String,
            ),
            reviewability: params.getParam(
              'reviewability',
              ParamType.bool,
            ),
            reviwername: params.getParam(
              'reviwername',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: TaskRevierPageWidget.routeName,
          path: TaskRevierPageWidget.routePath,
          builder: (context, params) => TaskRevierPageWidget(
            taskref: params.getParam(
              'taskref',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['task'],
            ),
            taskbame: params.getParam(
              'taskbame',
              ParamType.String,
            ),
            taskdesc: params.getParam(
              'taskdesc',
              ParamType.String,
            ),
            due: params.getParam(
              'due',
              ParamType.DateTime,
            ),
            assigneee: params.getParam(
              'assigneee',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            status: params.getParam(
              'status',
              ParamType.String,
            ),
            priority: params.getParam(
              'priority',
              ParamType.String,
            ),
            projReference: params.getParam(
              'projReference',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            taskAssigneeName: params.getParam(
              'taskAssigneeName',
              ParamType.String,
            ),
            reviewability: params.getParam(
              'reviewability',
              ParamType.bool,
            ),
            reviwername: params.getParam(
              'reviwername',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: JamBoardWidget.routeName,
          path: JamBoardWidget.routePath,
          builder: (context, params) => JamBoardWidget(),
        ),
        FFRoute(
          name: JamBoard1Widget.routeName,
          path: JamBoard1Widget.routePath,
          builder: (context, params) => JamBoard1Widget(),
        ),
        FFRoute(
          name: ScribbleProfWidget.routeName,
          path: ScribbleProfWidget.routePath,
          builder: (context, params) => ScribbleProfWidget(
            scribble: params.getParam(
              'scribble',
              ParamType.String,
            ),
            notes: params.getParam(
              'notes',
              ParamType.String,
            ),
            jamRef: params.getParam(
              'jamRef',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users', 'Jam'],
            ),
            viewonly: params.getParam(
              'viewonly',
              ParamType.bool,
            ),
          ),
        ),
        FFRoute(
          name: ManagerobjphoneWidget.routeName,
          path: ManagerobjphoneWidget.routePath,
          builder: (context, params) => ManagerobjphoneWidget(),
        ),
        FFRoute(
          name: ChildobjphoneWidget.routeName,
          path: ChildobjphoneWidget.routePath,
          builder: (context, params) => ChildobjphoneWidget(
            projectRef: params.getParam(
              'projectRef',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            projTitle: params.getParam(
              'projTitle',
              ParamType.String,
            ),
            projDesc: params.getParam(
              'projDesc',
              ParamType.String,
            ),
            startDate: params.getParam(
              'startDate',
              ParamType.DateTime,
            ),
            endDate: params.getParam(
              'endDate',
              ParamType.DateTime,
            ),
            progress: params.getParam(
              'progress',
              ParamType.int,
            ),
            projOwn: params.getParam(
              'projOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            ownername: params.getParam(
              'ownername',
              ParamType.String,
            ),
            parentOwn: params.getParam(
              'parentOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            parentList: params.getParam<DocumentReference>(
              'parentList',
              ParamType.DocumentReference,
              isList: true,
              collectionNamePath: ['projects'],
            ),
            orgObj: params.getParam(
              'orgObj',
              ParamType.bool,
            ),
            parentIds: params.getParam<String>(
              'parentIds',
              ParamType.String,
              isList: true,
            ),
            type: params.getParam(
              'type',
              ParamType.String,
            ),
            weighatage: params.getParam(
              'weighatage',
              ParamType.int,
            ),
          ),
        ),
        FFRoute(
          name: ObjectivesphoneWidget.routeName,
          path: ObjectivesphoneWidget.routePath,
          builder: (context, params) => ObjectivesphoneWidget(),
        ),
        FFRoute(
          name: Managerobjphone2Widget.routeName,
          path: Managerobjphone2Widget.routePath,
          builder: (context, params) => Managerobjphone2Widget(),
        ),
        FFRoute(
          name: TaskyyphnWidget.routeName,
          path: TaskyyphnWidget.routePath,
          builder: (context, params) => TaskyyphnWidget(),
        ),
        FFRoute(
          name: TaskAssigneephoneWidget.routeName,
          path: TaskAssigneephoneWidget.routePath,
          builder: (context, params) => TaskAssigneephoneWidget(
            taskref: params.getParam(
              'taskref',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['task'],
            ),
            taskbame: params.getParam(
              'taskbame',
              ParamType.String,
            ),
            taskdesc: params.getParam(
              'taskdesc',
              ParamType.String,
            ),
            due: params.getParam(
              'due',
              ParamType.DateTime,
            ),
            assigneee: params.getParam(
              'assigneee',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            status: params.getParam(
              'status',
              ParamType.String,
            ),
            priority: params.getParam(
              'priority',
              ParamType.String,
            ),
            projReference: params.getParam(
              'projReference',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            taskAssigneeName: params.getParam(
              'taskAssigneeName',
              ParamType.String,
            ),
            reviewability: params.getParam(
              'reviewability',
              ParamType.bool,
            ),
            reviwername: params.getParam(
              'reviwername',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: ChilObjCopyWidget.routeName,
          path: ChilObjCopyWidget.routePath,
          builder: (context, params) => ChilObjCopyWidget(
            projectRef: params.getParam(
              'projectRef',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            projTitle: params.getParam(
              'projTitle',
              ParamType.String,
            ),
            projDesc: params.getParam(
              'projDesc',
              ParamType.String,
            ),
            startDate: params.getParam(
              'startDate',
              ParamType.DateTime,
            ),
            endDate: params.getParam(
              'endDate',
              ParamType.DateTime,
            ),
            progress: params.getParam(
              'progress',
              ParamType.int,
            ),
            projOwn: params.getParam(
              'projOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            ownername: params.getParam(
              'ownername',
              ParamType.String,
            ),
            parentOwn: params.getParam(
              'parentOwn',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            parentList: params.getParam<DocumentReference>(
              'parentList',
              ParamType.DocumentReference,
              isList: true,
              collectionNamePath: ['projects'],
            ),
            orgObj: params.getParam(
              'orgObj',
              ParamType.bool,
            ),
            parentIds: params.getParam<String>(
              'parentIds',
              ParamType.String,
              isList: true,
            ),
            type: params.getParam(
              'type',
              ParamType.String,
            ),
            weighatage: params.getParam(
              'weighatage',
              ParamType.int,
            ),
          ),
        ),
        FFRoute(
          name: ManageUSersAdminPageWidget.routeName,
          path: ManageUSersAdminPageWidget.routePath,
          builder: (context, params) => ManageUSersAdminPageWidget(),
        ),
        FFRoute(
          name: NotiCopyWidget.routeName,
          path: NotiCopyWidget.routePath,
          builder: (context, params) => NotiCopyWidget(),
        ),
        FFRoute(
          name: NotificationPageWidget.routeName,
          path: NotificationPageWidget.routePath,
          builder: (context, params) => NotificationPageWidget(),
        ),
        FFRoute(
          name: StaffDashboardWidget.routeName,
          path: StaffDashboardWidget.routePath,
          requireAuth: true,
          builder: (context, params) => StaffDashboardWidget(),
        ),
        FFRoute(
          name: TaskyyCopy4Widget.routeName,
          path: TaskyyCopy4Widget.routePath,
          builder: (context, params) => TaskyyCopy4Widget(),
        ),
        FFRoute(
          name: TaskAssignorPageCopyWidget.routeName,
          path: TaskAssignorPageCopyWidget.routePath,
          builder: (context, params) => TaskAssignorPageCopyWidget(
            taskref: params.getParam(
              'taskref',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['task'],
            ),
            taskbame: params.getParam(
              'taskbame',
              ParamType.String,
            ),
            taskdesc: params.getParam(
              'taskdesc',
              ParamType.String,
            ),
            due: params.getParam(
              'due',
              ParamType.DateTime,
            ),
            assigneee: params.getParam(
              'assigneee',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            status: params.getParam(
              'status',
              ParamType.String,
            ),
            priority: params.getParam(
              'priority',
              ParamType.String,
            ),
            projReference: params.getParam(
              'projReference',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['projects'],
            ),
            taskAssigneeName: params.getParam(
              'taskAssigneeName',
              ParamType.String,
            ),
            reviewability: params.getParam(
              'reviewability',
              ParamType.bool,
            ),
            reviwername: params.getParam(
              'reviwername',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: TrailWidget.routeName,
          path: TrailWidget.routePath,
          builder: (context, params) => TrailWidget(),
        ),
        FFRoute(
          name: TaskPhoneViewWidget.routeName,
          path: TaskPhoneViewWidget.routePath,
          builder: (context, params) => TaskPhoneViewWidget(),
        )
      ].map((r) => r.toRoute(appStateNotifier)).toList(),
      observers: [routeObserver],
    );

extension NavParamExtensions on Map<String, String?> {
  Map<String, String> get withoutNulls => Map.fromEntries(
        entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
}

extension NavigationExtensions on BuildContext {
  void goNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : goNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void pushNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : pushNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void safePop() {
    // If there is only one route on the stack, navigate to the initial
    // page instead of popping.
    if (canPop()) {
      pop();
    } else {
      go('/');
    }
  }
}

extension GoRouterExtensions on GoRouter {
  AppStateNotifier get appState => AppStateNotifier.instance;
  void prepareAuthEvent([bool ignoreRedirect = false]) =>
      appState.hasRedirect() && !ignoreRedirect
          ? null
          : appState.updateNotifyOnAuthChange(false);
  bool shouldRedirect(bool ignoreRedirect) =>
      !ignoreRedirect && appState.hasRedirect();
  void clearRedirectLocation() => appState.clearRedirectLocation();
  void setRedirectLocationIfUnset(String location) =>
      appState.updateNotifyOnAuthChange(false);
}

extension _GoRouterStateExtensions on GoRouterState {
  Map<String, dynamic> get extraMap =>
      extra != null ? extra as Map<String, dynamic> : {};
  Map<String, dynamic> get allParams => <String, dynamic>{}
    ..addAll(pathParameters)
    ..addAll(uri.queryParameters)
    ..addAll(extraMap);
  TransitionInfo get transitionInfo => extraMap.containsKey(kTransitionInfoKey)
      ? extraMap[kTransitionInfoKey] as TransitionInfo
      : TransitionInfo.appDefault();
}

class FFParameters {
  FFParameters(this.state, [this.asyncParams = const {}]);

  final GoRouterState state;
  final Map<String, Future<dynamic> Function(String)> asyncParams;

  Map<String, dynamic> futureParamValues = {};

  // Parameters are empty if the params map is empty or if the only parameter
  // present is the special extra parameter reserved for the transition info.
  bool get isEmpty =>
      state.allParams.isEmpty ||
      (state.allParams.length == 1 &&
          state.extraMap.containsKey(kTransitionInfoKey));
  bool isAsyncParam(MapEntry<String, dynamic> param) =>
      asyncParams.containsKey(param.key) && param.value is String;
  bool get hasFutures => state.allParams.entries.any(isAsyncParam);
  Future<bool> completeFutures() => Future.wait(
        state.allParams.entries.where(isAsyncParam).map(
          (param) async {
            final doc = await asyncParams[param.key]!(param.value)
                .onError((_, __) => null);
            if (doc != null) {
              futureParamValues[param.key] = doc;
              return true;
            }
            return false;
          },
        ),
      ).onError((_, __) => [false]).then((v) => v.every((e) => e));

  dynamic getParam<T>(
    String paramName,
    ParamType type, {
    bool isList = false,
    List<String>? collectionNamePath,
    StructBuilder<T>? structBuilder,
  }) {
    if (futureParamValues.containsKey(paramName)) {
      return futureParamValues[paramName];
    }
    if (!state.allParams.containsKey(paramName)) {
      return null;
    }
    final param = state.allParams[paramName];
    // Got parameter from `extras`, so just directly return it.
    if (param is! String) {
      return param;
    }
    // Return serialized value.
    return deserializeParam<T>(
      param,
      type,
      isList,
      collectionNamePath: collectionNamePath,
      structBuilder: structBuilder,
    );
  }
}

class FFRoute {
  const FFRoute({
    required this.name,
    required this.path,
    required this.builder,
    this.requireAuth = false,
    this.asyncParams = const {},
    this.routes = const [],
  });

  final String name;
  final String path;
  final bool requireAuth;
  final Map<String, Future<dynamic> Function(String)> asyncParams;
  final Widget Function(BuildContext, FFParameters) builder;
  final List<GoRoute> routes;

  GoRoute toRoute(AppStateNotifier appStateNotifier) => GoRoute(
        name: name,
        path: path,
        redirect: (context, state) {
          if (appStateNotifier.shouldRedirect) {
            final redirectLocation = appStateNotifier.getRedirectLocation();
            appStateNotifier.clearRedirectLocation();
            return redirectLocation;
          }

          if (requireAuth && !appStateNotifier.loggedIn) {
            appStateNotifier.setRedirectLocationIfUnset(state.uri.toString());
            return '/loginPage';
          }
          return null;
        },
        pageBuilder: (context, state) {
          fixStatusBarOniOS16AndBelow(context);
          final ffParams = FFParameters(state, asyncParams);
          final page = ffParams.hasFutures
              ? FutureBuilder(
                  future: ffParams.completeFutures(),
                  builder: (context, _) => builder(context, ffParams),
                )
              : builder(context, ffParams);
          final child = appStateNotifier.loading
              ? Container(
                  color: Colors.transparent,
                  child: Image.asset(
                    'assets/images/nanopix.png',
                    fit: BoxFit.contain,
                  ),
                )
              : PushNotificationsHandler(child: page);

          final transitionInfo = state.transitionInfo;
          return transitionInfo.hasTransition
              ? CustomTransitionPage(
                  key: state.pageKey,
                  child: child,
                  transitionDuration: transitionInfo.duration,
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          PageTransition(
                    type: transitionInfo.transitionType,
                    duration: transitionInfo.duration,
                    reverseDuration: transitionInfo.duration,
                    alignment: transitionInfo.alignment,
                    child: child,
                  ).buildTransitions(
                    context,
                    animation,
                    secondaryAnimation,
                    child,
                  ),
                )
              : MaterialPage(key: state.pageKey, child: child);
        },
        routes: routes,
      );
}

class TransitionInfo {
  const TransitionInfo({
    required this.hasTransition,
    this.transitionType = PageTransitionType.fade,
    this.duration = const Duration(milliseconds: 300),
    this.alignment,
  });

  final bool hasTransition;
  final PageTransitionType transitionType;
  final Duration duration;
  final Alignment? alignment;

  static TransitionInfo appDefault() => TransitionInfo(hasTransition: false);
}

class RootPageContext {
  const RootPageContext(this.isRootPage, [this.errorRoute]);
  final bool isRootPage;
  final String? errorRoute;

  static bool isInactiveRootPage(BuildContext context) {
    final rootPageContext = context.read<RootPageContext?>();
    final isRootPage = rootPageContext?.isRootPage ?? false;
    final location = GoRouterState.of(context).uri.toString();
    return isRootPage &&
        location != '/' &&
        location != rootPageContext?.errorRoute;
  }

  static Widget wrap(Widget child, {String? errorRoute}) => Provider.value(
        value: RootPageContext(true, errorRoute),
        child: child,
      );
}

extension GoRouterLocationExtension on GoRouter {
  String getCurrentLocation() {
    final RouteMatch lastMatch = routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }
}
