import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'kn'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? knText = '',
  }) =>
      [enText, knText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

/// Used if the locale is not supported by GlobalMaterialLocalizations.
class FallbackMaterialLocalizationDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const FallbackMaterialLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<MaterialLocalizations> load(Locale locale) async =>
      SynchronousFuture<MaterialLocalizations>(
        const DefaultMaterialLocalizations(),
      );

  @override
  bool shouldReload(FallbackMaterialLocalizationDelegate old) => false;
}

/// Used if the locale is not supported by GlobalCupertinoLocalizations.
class FallbackCupertinoLocalizationDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const FallbackCupertinoLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<CupertinoLocalizations> load(Locale locale) =>
      SynchronousFuture<CupertinoLocalizations>(
        const DefaultCupertinoLocalizations(),
      );

  @override
  bool shouldReload(FallbackCupertinoLocalizationDelegate old) => false;
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

bool _isSupportedLocale(Locale locale) {
  final language = locale.toString();
  return FFLocalizations.languages().contains(
    language.endsWith('_')
        ? language.substring(0, language.length - 1)
        : language,
  );
}

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // LoginPage
  {
    'gs9xcyax': {
      'en': 'nanoDisha',
      'kn': '',
    },
    'uvf4fwvw': {
      'en': 'imageIn Your Future',
      'kn': '',
    },
    'xydjm4w7': {
      'en': 'Welcome back!',
      'kn': 'ಮರಳಿ ಸ್ವಾಗತ!',
    },
    '8bv7s4rr': {
      'en': 'Sign in to continue managing your team efficiently',
      'kn':
          'ನಿಮ್ಮ ತಂಡವನ್ನು ಪರಿಣಾಮಕಾರಿಯಾಗಿ ನಿರ್ವಹಿಸುವುದನ್ನು ಮುಂದುವರಿಸಲು ಸೈನ್ ಇನ್ ಮಾಡಿ.',
    },
    'gytuj9g2': {
      'en': 'Email Address',
      'kn': 'ಇಮೇಲ್ ವಿಳಾಸ',
    },
    '5rnn77gc': {
      'en': 'Password',
      'kn': 'ಪಾಸ್ವರ್ಡ್',
    },
    'd2kf8lz6': {
      'en': 'Sign In OG',
      'kn': 'ಸೈನ್ ಇನ್ ಮಾಡಿ',
    },
    'jdpuua05': {
      'en': 'Sign In',
      'kn': 'ಸೈನ್ ಇನ್ ಮಾಡಿ',
    },
    'd2pf6se1': {
      'en': 'Forgot Password?',
      'kn': 'ಪಾಸ್ವರ್ಡ್ ಮರೆತಿರಾ?',
    },
    'i28jsftt': {
      'en': 'Powered by Megascends',
      'kn': 'ಮೆಗಾಸೆಂಡ್ಸ್ ನಿಂದ ನಡೆಸಲ್ಪಡುತ್ತಿದೆ',
    },
  },
  // Reports
  {
    '93ufovgr': {
      'en': 'Reports & Analytics',
      'kn': '',
    },
    '29iww96i': {
      'en': 'Performance Overview',
      'kn': '',
    },
    'b5fwr0c5': {
      'en': 'Last 30 Days',
      'kn': '',
    },
    'k6e4r8oi': {
      'en': 'Projects',
      'kn': '',
    },
    'bf8hzeqs': {
      'en': '24 Active',
      'kn': '',
    },
    'jpwegwb2': {
      'en': 'Tasks',
      'kn': '',
    },
    'tfd0pvbp': {
      'en': '156 Completed',
      'kn': '',
    },
    'sn17ockt': {
      'en': 'Team',
      'kn': '',
    },
    'blgedysx': {
      'en': '32 Members',
      'kn': '',
    },
    'rjseffot': {
      'en': 'Project Performance',
      'kn': '',
    },
    '9r0cm67v': {
      'en': 'Filter',
      'kn': '',
    },
    'gsqcrzr4': {
      'en': 'Project Completion Status',
      'kn': '',
    },
    '63v5qdy2': {
      'en': '[Chart Placeholder]',
      'kn': '',
    },
    'bwhaog7a': {
      'en': 'Recent Projects',
      'kn': '',
    },
    '2m7gowjg': {
      'en': 'Website Redesign',
      'kn': '',
    },
    'knb5i5rs': {
      'en': 'Due: June 30, 2023',
      'kn': '',
    },
    'conu4jsl': {
      'en': '85%',
      'kn': '',
    },
    'u6d3laym': {
      'en': 'Mobile App Development',
      'kn': '',
    },
    'pcnc2gyf': {
      'en': 'Due: July 15, 2023',
      'kn': '',
    },
    '3xdeupym': {
      'en': '65%',
      'kn': '',
    },
    'ut08cbah': {
      'en': 'Marketing Campaign',
      'kn': '',
    },
    'secwxhik': {
      'en': 'Due: July 30, 2023',
      'kn': '',
    },
    'n9jfa30s': {
      'en': '45%',
      'kn': '',
    },
    'wr21b4ek': {
      'en': 'Team Performance',
      'kn': '',
    },
    'v81f9wl4': {
      'en': 'This Month',
      'kn': '',
    },
    'g9tq4cda': {
      'en': 'Employee Productivity',
      'kn': '',
    },
    'm5v6cqrj': {
      'en': '[Chart Placeholder]',
      'kn': '',
    },
    'hg4yvm2e': {
      'en': 'Top Performers',
      'kn': '',
    },
    'xo95hwc5': {
      'en': 'Sarah Johnson',
      'kn': '',
    },
    'm3gcchnq': {
      'en': '32 Tasks Completed',
      'kn': '',
    },
    'q7kgk2qh': {
      'en': '98%',
      'kn': '',
    },
    '3gkxgody': {
      'en': 'Michael Chen',
      'kn': '',
    },
    '6xwru989': {
      'en': '28 Tasks Completed',
      'kn': '',
    },
    'kv4gqj2d': {
      'en': '95%',
      'kn': '',
    },
    'ytrmjwsq': {
      'en': 'Emily Davis',
      'kn': '',
    },
    '1ga1enmy': {
      'en': '25 Tasks Completed',
      'kn': '',
    },
    'xbibh7bz': {
      'en': '92%',
      'kn': '',
    },
  },
  // subOBJ
  {
    '7x0kkxt6': {
      'en': 'Team Objectives',
      'kn': '',
    },
    'esn7v9n8': {
      'en': 'Track and manage organizational goals',
      'kn': '',
    },
    'nsts47g7': {
      'en': 'Search objectives...',
      'kn': '',
    },
    'h20gnbzn': {
      'en': 'Filter',
      'kn': '',
    },
    'an2evr3n': {
      'en': 'Increase Market Share',
      'kn': '',
    },
    'xqj7g6hl': {
      'en':
          'Expand market presence in key regions through strategic partnerships',
      'kn': '',
    },
    '8swlb4oj': {
      'en': 'Progress',
      'kn': '',
    },
    'zy8nctd9': {
      'en': '75%',
      'kn': '',
    },
    '2fnrhyf5': {
      'en': 'Manager',
      'kn': '',
    },
    '5ynq88ge': {
      'en': 'Due Date',
      'kn': '',
    },
    '3p7g1jyr': {
      'en': 'Dec 31, 2024',
      'kn': '',
    },
    'qx96wlnj': {
      'en': 'Track and manage organizational goals',
      'kn': '',
    },
    'x8mejcy5': {
      'en': 'Team Objectives',
      'kn': '',
    },
  },
  // DASHHYYY
  {
    '7vqoyztk': {
      'en': 'Administrator',
      'kn': '',
    },
    'b48sjlij': {
      'en': 'Dashboard',
      'kn': '',
    },
    'xthuqhj0': {
      'en': 'Objectives',
      'kn': '',
    },
    '05bfhqbr': {
      'en': 'Objectives New',
      'kn': '',
    },
    'x5bm9iip': {
      'en': 'Task Management',
      'kn': '',
    },
    'nzb6ohe0': {
      'en': 'Employee Management',
      'kn': '',
    },
    'cpbvw65p': {
      'en': 'Reports',
      'kn': '',
    },
    'muxir0fb': {
      'en': 'Notifications',
      'kn': '',
    },
    'emej8qw1': {
      'en': 'Logout',
      'kn': '',
    },
    'hogcceq8': {
      'en': 'Admin Dashboard',
      'kn': '',
    },
    'beqzt8ha': {
      'en': 'Here\'s what\'s happening with your projects',
      'kn': '',
    },
    '2qweuj0z': {
      'en': 'Add Objective',
      'kn': '',
    },
    'z36b7eke': {
      'en': 'Here\'s what\'s happening with your projects',
      'kn': '',
    },
    'nj768ypf': {
      'en': 'Total Active Users',
      'kn': '',
    },
    'd38pyibv': {
      'en': 'In Progress',
      'kn': '',
    },
    '6r478zou': {
      'en': 'Completed',
      'kn': '',
    },
    'ce47dnvb': {
      'en': 'Pending Tasks',
      'kn': '',
    },
    'mqnscc8f': {
      'en': 'Generate Report',
      'kn': '',
    },
    'hv5im99g': {
      'en': 'Add Objective',
      'kn': '',
    },
    'mutrzd5b': {
      'en': 'Total Objectives',
      'kn': '',
    },
    'g1spaoyf': {
      'en': 'In Progress',
      'kn': '',
    },
    '6xt6ls1p': {
      'en': 'Completed',
      'kn': '',
    },
    'y4fbug4h': {
      'en': 'Pending Tasks',
      'kn': '',
    },
    'rxhyg0tr': {
      'en': 'Overview',
      'kn': '',
    },
    'xorji7p1': {
      'en': 'Name',
      'kn': '',
    },
    '3s9urgp3': {
      'en': 'Manager',
      'kn': '',
    },
    '6gd36wti': {
      'en': 'Progress',
      'kn': '',
    },
    'wxwu9muo': {
      'en': 'Deadline',
      'kn': '',
    },
    'otcep5qf': {
      'en': '2 days left',
      'kn': '',
    },
    'go8mr3zr': {
      'en': 'Recent Activity',
      'kn': '',
    },
    '1vax7fq7': {
      'en': 'Sub-Objectives Overview',
      'kn': '',
    },
    'du6ayptk': {
      'en': 'Name',
      'kn': '',
    },
    'nqp8tbtm': {
      'en': 'Manager',
      'kn': '',
    },
    'n2vtmjbw': {
      'en': 'Progress',
      'kn': '',
    },
    '8qle47op': {
      'en': 'Deadline',
      'kn': '',
    },
    'b9oc2kko': {
      'en': '2 days left',
      'kn': '',
    },
    'weotiqrm': {
      'en': 'Recent Activity',
      'kn': '',
    },
    'pppyiwzv': {
      'en': 'Market Analysis completed',
      'kn': '',
    },
    'x412ei9r': {
      'en': '2 hours ago',
      'kn': '',
    },
    '64c32p6n': {
      'en': 'New objective created',
      'kn': '',
    },
    'elutm38k': {
      'en': '4 hours ago',
      'kn': '',
    },
    'b2trwg93': {
      'en': 'New team member added',
      'kn': '',
    },
    'mjyzd9y8': {
      'en': 'Yesterday',
      'kn': '',
    },
    '1ofvhsf8': {
      'en': 'NanoTrack',
      'kn': '',
    },
    'q6p8nwr5': {
      'en': 'Administrator',
      'kn': '',
    },
    'kt80rzx5': {
      'en': 'Dashboard',
      'kn': '',
    },
    'v6ztzyr0': {
      'en': 'Objectives',
      'kn': '',
    },
    'mlfts48c': {
      'en': 'Task Management',
      'kn': '',
    },
    'yrv45ky9': {
      'en': 'Employee Management',
      'kn': '',
    },
    'mp2u3m0i': {
      'en': 'Reports',
      'kn': '',
    },
    'oj4qjs06': {
      'en': 'Notifications',
      'kn': '',
    },
    '5ub00efq': {
      'en': 'Logout',
      'kn': '',
    },
    '7xwno00i': {
      'en': 'Home',
      'kn': '',
    },
  },
  // Objectives
  {
    'tuowdibi': {
      'en': 'Search objectives...',
      'kn': '',
    },
    '081qg3wo': {
      'en': 'Progress: 65%',
      'kn': '',
    },
    '9axvuvvs': {
      'en': 'Deactive',
      'kn': '',
    },
    'mxnqipvf': {
      'en': 'Edit',
      'kn': '',
    },
    '554k37v8': {
      'en': 'View Details',
      'kn': '',
    },
    'hwlxa1kg': {
      'en': 'Active',
      'kn': '',
    },
    'lj3rcmx6': {
      'en': 'Progress: 65%',
      'kn': '',
    },
    '5uqck2fx': {
      'en': 'Delete',
      'kn': '',
    },
    '00mwoaeu': {
      'en': 'Edit',
      'kn': '',
    },
    '1kimnquw': {
      'en': 'View Details',
      'kn': '',
    },
    'rgdb7xdu': {
      'en': 'Organizational Objectives',
      'kn': '',
    },
  },
  // Detailyyy
  {
    'tap4465a': {
      'en': 'Progress Bar:',
      'kn': '',
    },
    'n5c2tfbt': {
      'en': '70%',
      'kn': '',
    },
    'xc6xz6iv': {
      'en': 'TextField',
      'kn': '',
    },
    'svgpyqbc': {
      'en': 'TextField',
      'kn': '',
    },
    'glg876ic': {
      'en': 'Sub Objectives',
      'kn': '',
    },
    'kagekzyi': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    'hqd5pf8p': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    'n6igjs8f': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    'sgz53rlc': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    'id2oaq9j': {
      'en': 'On Track',
      'kn': '',
    },
    'vg4yba9r': {
      'en': '80%',
      'kn': '',
    },
    'uo2ia1da': {
      'en': 'On Track',
      'kn': '',
    },
    'ond8kdft': {
      'en': '80%',
      'kn': '',
    },
    'xm49mdv1': {
      'en': 'Tasks',
      'kn': '',
    },
    '46385xl1': {
      'en': 'All',
      'kn': '',
    },
    '0gbujnag': {
      'en': 'Select...',
      'kn': '',
    },
    '19a0or4k': {
      'en': 'Search...',
      'kn': '',
    },
    'igg3tbfz': {
      'en': 'Pending',
      'kn': '',
    },
    'khlwgmam': {
      'en': 'Completed',
      'kn': '',
    },
    'rrzml433': {
      'en': 'All',
      'kn': '',
    },
    'vekrkkjj': {
      'en': 'Add task',
      'kn': '',
    },
    'z4jb13go': {
      'en': 'Due',
      'kn': '',
    },
    '29ckpfpl': {
      'en': 'Due',
      'kn': '',
    },
    'wn1fwnj0': {
      'en': 'Organizational Objectives',
      'kn': '',
    },
  },
  // DetailyyyCopy
  {
    'nepiwikg': {
      'en': 'Progress Bar',
      'kn': '',
    },
    'oqq663go': {
      'en': 'Sub Objectives',
      'kn': '',
    },
    '17sd0j8n': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    'dmmrlss6': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    'kk7yrpnr': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    'wcny8g5u': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    '2puxmfs7': {
      'en': 'On Track',
      'kn': '',
    },
    'w5gcd7br': {
      'en': '80%',
      'kn': '',
    },
    'e3c6bw83': {
      'en': 'On Track',
      'kn': '',
    },
    '51oqjsij': {
      'en': '80%',
      'kn': '',
    },
    'kilevmoo': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    'z5l9pi5z': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    'oqal4hjz': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    's9bws9u1': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    'p8sxn9e6': {
      'en': 'On Track',
      'kn': '',
    },
    '3d2v9o49': {
      'en': '80%',
      'kn': '',
    },
    'jsrx2hfh': {
      'en': 'On Track',
      'kn': '',
    },
    'bqs9eg31': {
      'en': '80%',
      'kn': '',
    },
    'pi555mqh': {
      'en': 'Tasks',
      'kn': '',
    },
    'e48skxk1': {
      'en': 'All',
      'kn': '',
    },
    'fvimcwx8': {
      'en': 'Select...',
      'kn': '',
    },
    'w9i4wzlc': {
      'en': 'Search...',
      'kn': '',
    },
    'hts32ugs': {
      'en': 'Pending',
      'kn': '',
    },
    'vj3ca6ue': {
      'en': 'Completed',
      'kn': '',
    },
    'jecri9n1': {
      'en': 'All',
      'kn': '',
    },
    'vcnlv86n': {
      'en': 'Add task',
      'kn': '',
    },
    't10q4dbm': {
      'en': 'Due',
      'kn': '',
    },
    'oy2upgos': {
      'en': 'Objectives',
      'kn': '',
    },
  },
  // Taskyy
  {
    'rzxyvomc': {
      'en': 'Task Management',
      'kn': '',
    },
    '6b573zy3': {
      'en': 'My Tasks',
      'kn': '',
    },
    'tcstdt9s': {
      'en': 'Task Management',
      'kn': '',
    },
    'lafp40f8': {
      'en': 'Manage and track team tasks',
      'kn': '',
    },
    '40r4f1b5': {
      'en': 'Sort By: ',
      'kn': '',
    },
    'cm5q1wyo': {
      'en': 'Accepted',
      'kn': '',
    },
    'cqzc9m73': {
      'en': 'Inprogress',
      'kn': '',
    },
    'z0krix7y': {
      'en': 'Deffered',
      'kn': '',
    },
    'naqmsku6': {
      'en': 'Completed',
      'kn': '',
    },
    '7slvpt0n': {
      'en': 'All',
      'kn': '',
    },
    '4r6s5t4m': {
      'en': 'All',
      'kn': '',
    },
    '5lg7zdp8': {
      'en': 'Search tasks',
      'kn': '',
    },
    'u5ly7ejr': {
      'en': 'Task Name',
      'kn': '',
    },
    'vmwusli0': {
      'en': 'Assigned By',
      'kn': '',
    },
    'ylm2mlwx': {
      'en': 'Due Date',
      'kn': '',
    },
    'ogwdyir4': {
      'en': 'Priority',
      'kn': '',
    },
    'h4j6kyvs': {
      'en': 'Status',
      'kn': '',
    },
    'ow4srvum': {
      'en': 'Assigned Tasks',
      'kn': '',
    },
    'ur527z5o': {
      'en': 'Task Management',
      'kn': '',
    },
    '0bkzmyds': {
      'en': 'Manage and track team tasks',
      'kn': '',
    },
    'y5yscx3e': {
      'en': 'Search Tasks',
      'kn': '',
    },
    'lu3evevb': {
      'en': 'Task Name',
      'kn': '',
    },
    'ckbzxa2d': {
      'en': 'Assigned To',
      'kn': '',
    },
    'bm5eamrs': {
      'en': 'Due Date',
      'kn': '',
    },
    'gsauzg2t': {
      'en': 'Priority',
      'kn': '',
    },
    'k7on2hzn': {
      'en': 'Status',
      'kn': '',
    },
  },
  // Employeeee
  {
    '6lysfdn9': {
      'en': 'Manage your organization\'s workforce',
      'kn': '',
    },
    'fh5f2oke': {
      'en': 'Search employee by name/email',
      'kn': '',
    },
    's67pjqxl': {
      'en': 'Name',
      'kn': '',
    },
    'va0a4p4h': {
      'en': 'Designation',
      'kn': '',
    },
    'muhvp2bc': {
      'en': 'Department',
      'kn': '',
    },
    'adicx5k9': {
      'en': 'Email',
      'kn': '',
    },
    'ywu1jbwn': {
      'en': 'Status',
      'kn': '',
    },
    'hm442qst': {
      'en': 'Delete',
      'kn': '',
    },
    'zm5w6zdj': {
      'en': 'Employee Management',
      'kn': '',
    },
  },
  // ManagerDashyy
  {
    'pfck2uhr': {
      'en': 'Nanotrack',
      'kn': '',
    },
    'jm4f9ofb': {
      'en': 'Dashboard',
      'kn': '',
    },
    'x3tvkpza': {
      'en': 'Org Objectives',
      'kn': '',
    },
    'dq8e4la1': {
      'en': 'Sub Objectives',
      'kn': '',
    },
    'kyqgyqzb': {
      'en': 'Task Management',
      'kn': '',
    },
    'svedo610': {
      'en': 'My Tasks',
      'kn': '',
    },
    '2yzczqma': {
      'en': 'Notifications',
      'kn': '',
    },
    'mitlg5ij': {
      'en': 'Reports',
      'kn': '',
    },
    '8qd0gskg': {
      'en': 'Logout',
      'kn': '',
    },
    '7clv7e8v': {
      'en': 'Dashboard',
      'kn': '',
    },
    'k01hbifl': {
      'en': 'Org Objectives',
      'kn': '',
    },
    'qj7ips1h': {
      'en': 'Sub Objectives',
      'kn': '',
    },
    'n5du4gj9': {
      'en': 'Task Management',
      'kn': '',
    },
    'mqvpi1o8': {
      'en': 'My Tasks',
      'kn': '',
    },
    'rxsmvb2u': {
      'en': 'Notifications',
      'kn': '',
    },
    't8l43kkc': {
      'en': 'Reports',
      'kn': '',
    },
    'o1ig8ssk': {
      'en': 'Logout',
      'kn': '',
    },
    'hfvu5el0': {
      'en': 'Manager Dashboard',
      'kn': '',
    },
    'rrg4bs74': {
      'en': 'Total Tasks',
      'kn': '',
    },
    'pdohow2r': {
      'en': '24',
      'kn': '',
    },
    'khtz96wk': {
      'en': '+12% from last month',
      'kn': '',
    },
    'gv9enbzg': {
      'en': 'Completed',
      'kn': '',
    },
    'pk06i6di': {
      'en': '18',
      'kn': '',
    },
    '5i4u8clq': {
      'en': '75% completion rate',
      'kn': '',
    },
    '1ajiytsr': {
      'en': 'Assigned Tasks',
      'kn': '',
    },
    '62l5iufa': {
      'en': 'Filter',
      'kn': '',
    },
    'g3kh7sq9': {
      'en': 'Q4 Revenue Target',
      'kn': '',
    },
    'picb6vp6': {
      'en': '75%',
      'kn': '',
    },
    'ctebrrux': {
      'en': 'Team Expansion',
      'kn': '',
    },
    's60tvsar': {
      'en': '40%',
      'kn': '',
    },
    'pmfdirzw': {
      'en': 'Product Launch',
      'kn': '',
    },
    'mf3hquo1': {
      'en': '90%',
      'kn': '',
    },
    'sojmq6of': {
      'en': 'My Tasks',
      'kn': '',
    },
    '7doqefjc': {
      'en': 'Urgent',
      'kn': '',
    },
    '5hjspo59': {
      'en': 'Team Performance Review',
      'kn': '',
    },
    'wd2rxmed': {
      'en': 'Due: Next Week',
      'kn': '',
    },
    'q0virof9': {
      'en': 'In Progress',
      'kn': '',
    },
    'zq6qtk7j': {
      'en': 'Budget Planning 2024',
      'kn': '',
    },
    'b19it5fd': {
      'en': 'Due: Next Month',
      'kn': '',
    },
    'y55yd4t5': {
      'en': 'Pending',
      'kn': '',
    },
    're2gl4ln': {
      'en': 'Recent Activities',
      'kn': '',
    },
    '3v7bj777': {
      'en': 'View All',
      'kn': '',
    },
    'ka075zxd': {
      'en': 'Team meeting completed',
      'kn': '',
    },
    '91asvrug': {
      'en': '2 hours ago',
      'kn': '',
    },
    'x4fmfdt8': {
      'en': 'Dashboard',
      'kn': '',
    },
    'tnreqnwf': {
      'en': 'Org Objectives',
      'kn': '',
    },
    'ufc9awi4': {
      'en': 'Sub Objectives',
      'kn': '',
    },
    'ahbm6i5m': {
      'en': 'Task Management',
      'kn': '',
    },
    'twfgilxa': {
      'en': 'My Tasks',
      'kn': '',
    },
    'tilqmn6i': {
      'en': 'Notifications',
      'kn': '',
    },
    '7wna0h8m': {
      'en': 'Reports',
      'kn': '',
    },
    '9qko3c4z': {
      'en': 'Logout',
      'kn': '',
    },
  },
  // AssignedObj
  {
    'tnih20tl': {
      'en': 'Create Objective',
      'kn': '',
    },
    'd166j2p7': {
      'en': 'Search objectives...',
      'kn': '',
    },
    'g9717nsl': {
      'en': 'Active',
      'kn': '',
    },
    'e4c9h1ky': {
      'en': 'Manager: Sarah Johnson',
      'kn': '',
    },
    'nxax782t': {
      'en': 'Progress: 65%',
      'kn': '',
    },
    'h869d7wk': {
      'en': '50%',
      'kn': '',
    },
    'h7aq4639': {
      'en': 'Edit',
      'kn': '',
    },
    'sn988hqj': {
      'en': 'View Details',
      'kn': '',
    },
    '2fih2l9i': {
      'en': 'Assigned Objectives',
      'kn': '',
    },
  },
  // DetailyyOwner
  {
    'ko6hbeax': {
      'en': 'Overall Progress',
      'kn': '',
    },
    'lno3lfa6': {
      'en': '65%',
      'kn': '',
    },
    'fiave35l': {
      'en': 'Sub Objectives',
      'kn': '',
    },
    '7zqv0170': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    '1h2avkn6': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    '0dwcjdf8': {
      'en': 'On Track',
      'kn': '',
    },
    'gqfiqpez': {
      'en': '80%',
      'kn': '',
    },
    'a0w3v2ug': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    'iniocnoe': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    'y58jl2b4': {
      'en': 'On Track',
      'kn': '',
    },
    '3spfi2l2': {
      'en': '80%',
      'kn': '',
    },
    'd8gfveci': {
      'en': 'Tasks',
      'kn': '',
    },
    'pm73eyw6': {
      'en': 'All',
      'kn': '',
    },
    'qg3ot1z5': {
      'en': 'Select...',
      'kn': '',
    },
    '9py4pcq0': {
      'en': 'Search...',
      'kn': '',
    },
    '98fu4nrm': {
      'en': 'Pending',
      'kn': '',
    },
    '94lrtj0x': {
      'en': 'Completed',
      'kn': '',
    },
    'ukrsy3gj': {
      'en': 'All',
      'kn': '',
    },
    'f64grxop': {
      'en': 'Add task',
      'kn': '',
    },
    'pzodyqp8': {
      'en': 'Due',
      'kn': '',
    },
    'gkng27uw': {
      'en': 'All',
      'kn': '',
    },
    'y5edlp5w': {
      'en': 'Select...',
      'kn': '',
    },
    '7be1ff39': {
      'en': 'Search...',
      'kn': '',
    },
    'e9i7dnz6': {
      'en': 'Pending',
      'kn': '',
    },
    '6tp6d8i4': {
      'en': 'Completed',
      'kn': '',
    },
    'vntqcd3w': {
      'en': 'All',
      'kn': '',
    },
    'n9a1t62y': {
      'en': 'Add task',
      'kn': '',
    },
    '82h582tr': {
      'en': 'Due',
      'kn': '',
    },
    'xipr3iz5': {
      'en': 'Objective',
      'kn': '',
    },
  },
  // DetailyyCopyOwner
  {
    'fqiwzs7t': {
      'en': 'Overall Progress',
      'kn': '',
    },
    'hmzok6ph': {
      'en': '65%',
      'kn': '',
    },
    '6ho8rh6k': {
      'en': 'Sub Objectives',
      'kn': '',
    },
    '03txouub': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    '1uyv4h9g': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    'ewbpshol': {
      'en': 'On Track',
      'kn': '',
    },
    'gzw95ha3': {
      'en': '80%',
      'kn': '',
    },
    '3h5gs8n0': {
      'en': 'Tasks',
      'kn': '',
    },
    'gm2ohs4s': {
      'en': 'All',
      'kn': '',
    },
    '3vry2e86': {
      'en': 'Select...',
      'kn': '',
    },
    '7x40t0d0': {
      'en': 'Search...',
      'kn': '',
    },
    'y2pdwg9z': {
      'en': 'Pending',
      'kn': '',
    },
    '8dq3o7pv': {
      'en': 'Completed',
      'kn': '',
    },
    '3sm3wthu': {
      'en': 'All',
      'kn': '',
    },
    'rn71b0h7': {
      'en': 'Add task',
      'kn': '',
    },
    '8rmrsc7f': {
      'en': 'Due',
      'kn': '',
    },
  },
  // OBJYYowner
  {
    'zlvd7i39': {
      'en': 'Search objectives...',
      'kn': '',
    },
    'rxiinp51': {
      'en': 'Active',
      'kn': '',
    },
    'dms7p45d': {
      'en': 'Progress: 65%',
      'kn': '',
    },
    'qc4spmp1': {
      'en': 'Delete',
      'kn': '',
    },
    'b7009b4r': {
      'en': 'Edit',
      'kn': '',
    },
    '942gq474': {
      'en': 'View Details',
      'kn': '',
    },
    'g39y7u5r': {
      'en': 'Objectives',
      'kn': '',
    },
  },
  // DASHYYowner
  {
    'e3t6e715': {
      'en': 'Effitrack',
      'kn': '',
    },
    'm1g83uhy': {
      'en': 'Dashboard',
      'kn': '',
    },
    'luqpijct': {
      'en': 'Objectives',
      'kn': '',
    },
    'e5hxkq3a': {
      'en': 'Task Management',
      'kn': '',
    },
    'jfk9cdit': {
      'en': 'Employee Management',
      'kn': '',
    },
    'ev2fwhz2': {
      'en': 'Reports',
      'kn': '',
    },
    'uf22j5f8': {
      'en': 'Notifications',
      'kn': '',
    },
    'hakkualg': {
      'en': 'Settings',
      'kn': '',
    },
    '5zbhxdfl': {
      'en': 'Logout',
      'kn': '',
    },
    'woo3uwb9': {
      'en': 'Welcome back, Admin!',
      'kn': '',
    },
    'jqou6ggm': {
      'en': 'Here\'s what\'s happening with your projects',
      'kn': '',
    },
    '22vz6a8f': {
      'en': 'Add Objective',
      'kn': '',
    },
    'zt6k42cy': {
      'en': 'Generate Report',
      'kn': '',
    },
    'am25pzpj': {
      'en': 'Total Objectives',
      'kn': '',
    },
    '5nl8xg2u': {
      'en': 'In Progress',
      'kn': '',
    },
    'ndv7awae': {
      'en': 'Completed',
      'kn': '',
    },
    '1w054at2': {
      'en': 'Pending Tasks',
      'kn': '',
    },
    '4ie7s7jn': {
      'en': 'Sub-Objectives Overview',
      'kn': '',
    },
    'wvteydrm': {
      'en': 'Name',
      'kn': '',
    },
    'i5n6t8wa': {
      'en': 'Manager',
      'kn': '',
    },
    'uctecxuw': {
      'en': 'Progress',
      'kn': '',
    },
    've6fszng': {
      'en': 'Deadline',
      'kn': '',
    },
    '9orn9lpt': {
      'en': 'Market Research',
      'kn': '',
    },
    '7a9tpait': {
      'en': 'John Smith',
      'kn': '',
    },
    '1w1zz8x0': {
      'en': '75%',
      'kn': '',
    },
    'pbrzmxvm': {
      'en': '2 days left',
      'kn': '',
    },
    'pclte6e6': {
      'en': 'Product Launch',
      'kn': '',
    },
    'z1ljkdnn': {
      'en': 'Sarah Johnson',
      'kn': '',
    },
    '6hy4e21c': {
      'en': '45%',
      'kn': '',
    },
    '4tdtpy6r': {
      'en': '1 week left',
      'kn': '',
    },
    '7ksiwxkp': {
      'en': 'Team Training',
      'kn': '',
    },
    'x0e84fw8': {
      'en': 'Mike Wilson',
      'kn': '',
    },
    'py3fle4i': {
      'en': '90%',
      'kn': '',
    },
    'bt7p8xl1': {
      'en': '3 days left',
      'kn': '',
    },
    'ch4j1mbm': {
      'en': 'Recent Activity',
      'kn': '',
    },
    'othtmvpj': {
      'en': 'Market Analysis completed',
      'kn': '',
    },
    'gz4mycuo': {
      'en': '2 hours ago',
      'kn': '',
    },
    'lpqqqvfi': {
      'en': 'New objective created',
      'kn': '',
    },
    'pxor1nl6': {
      'en': '4 hours ago',
      'kn': '',
    },
    'grn2owyd': {
      'en': 'New team member added',
      'kn': '',
    },
    'xiyc8o41': {
      'en': 'Yesterday',
      'kn': '',
    },
  },
  // chatpag
  {
    'g500l7jh': {
      'en': 'Team Chat',
      'kn': '',
    },
    'i1wxzg1j': {
      'en': 'Type a message...',
      'kn': '',
    },
  },
  // employeedash
  {
    '9d9f5i8g': {
      'en': 'Nanotrack',
      'kn': '',
    },
    'uirxvehq': {
      'en': 'Dashboard',
      'kn': '',
    },
    'menmqtil': {
      'en': 'Assigned Tasks',
      'kn': '',
    },
    'ey77amrr': {
      'en': 'My Tasks',
      'kn': '',
    },
    '05hivsfw': {
      'en': 'Progress Tracking',
      'kn': '',
    },
    'joutm4d1': {
      'en': 'Reports',
      'kn': '',
    },
    'bjq0ck3b': {
      'en': 'Notifications',
      'kn': '',
    },
    '8nk3mmon': {
      'en': 'Settings',
      'kn': '',
    },
    'bek9mahd': {
      'en': 'Effitrack',
      'kn': '',
    },
    'symridhb': {
      'en': 'My Tasks',
      'kn': '',
    },
    'kfeaby7i': {
      'en': 'Progress Tracking',
      'kn': '',
    },
    '0ffbevkp': {
      'en': 'Reports',
      'kn': '',
    },
    'a3ecvarc': {
      'en': 'Notifications',
      'kn': '',
    },
    't21p7n5c': {
      'en': 'log out',
      'kn': '',
    },
    'g3wa4bhw': {
      'en': 'Employee   Dashboard',
      'kn': '',
    },
    'hwg9vu0n': {
      'en': 'Employee  Dashboard',
      'kn': '',
    },
    'y8mr6gyt': {
      'en': 'Assigned Tasks',
      'kn': '',
    },
    'nnyrp1as': {
      'en': '75%',
      'kn': '',
    },
    'kkhktuij': {
      'en': 'Team Expansion',
      'kn': '',
    },
    'hqoto66q': {
      'en': '40%',
      'kn': '',
    },
    'e9d66317': {
      'en': 'Product Launch',
      'kn': '',
    },
    'xsay1eij': {
      'en': '90%',
      'kn': '',
    },
    'r553cklc': {
      'en': 'Pending Tasks',
      'kn': '',
    },
    'osr5yc9g': {
      'en': 'Urgent',
      'kn': '',
    },
    'kyv6vla6': {
      'en': 'Team Performance Review',
      'kn': '',
    },
    'c5b0egb1': {
      'en': 'Due: Next Week',
      'kn': '',
    },
    'nehvak0t': {
      'en': 'In Progress',
      'kn': '',
    },
    'bf5puf8x': {
      'en': 'Budget Planning 2024',
      'kn': '',
    },
    '8t1lag9l': {
      'en': 'Due: Next Month',
      'kn': '',
    },
    '0a49apjl': {
      'en': 'Pending',
      'kn': '',
    },
    'qpql5i6e': {
      'en': 'Upcoming Task\'s',
      'kn': '',
    },
    '16lps3pu': {
      'en': 'Task Title',
      'kn': '',
    },
    'r0yv2vk9': {
      'en': '(deadline date)',
      'kn': '',
    },
    '5v1tuswr': {
      'en': 'Accept',
      'kn': '',
    },
    'c6443w7o': {
      'en': 'Reject',
      'kn': '',
    },
    'r19cbhqy': {
      'en': 'Team Expansion',
      'kn': '',
    },
    'xunpm9q6': {
      'en': '40%',
      'kn': '',
    },
    'x3zn548l': {
      'en': 'Product Launch',
      'kn': '',
    },
    '478wo2i6': {
      'en': '90%',
      'kn': '',
    },
    '4cbhyoqc': {
      'en': 'Upcoming Task\'s',
      'kn': '',
    },
    'dy4fg4p2': {
      'en': 'Task Title',
      'kn': '',
    },
    'avntlhbx': {
      'en': '(deadline date)',
      'kn': '',
    },
    'yh96a1sr': {
      'en': 'Accept',
      'kn': '',
    },
    'dyml4gg0': {
      'en': 'Reject',
      'kn': '',
    },
    '9gb6ufbz': {
      'en': 'Team Expansion',
      'kn': '',
    },
    'kvtx054a': {
      'en': '40%',
      'kn': '',
    },
    'qd4c0idy': {
      'en': 'Product Launch',
      'kn': '',
    },
    '7eaam4xp': {
      'en': '90%',
      'kn': '',
    },
  },
  // Taskyyemployee
  {
    'lef7b01d': {
      'en': 'MY TASK',
      'kn': '',
    },
    'baj0ko26': {
      'en': 'TextField',
      'kn': '',
    },
    'z14mi929': {
      'en': 'Task Name',
      'kn': '',
    },
    'efte49m5': {
      'en': 'Assigned by',
      'kn': '',
    },
    'r8xgrvjj': {
      'en': 'Due Date',
      'kn': '',
    },
    'hb83dit1': {
      'en': 'Priority',
      'kn': '',
    },
    'u4u1m0sy': {
      'en': 'Status',
      'kn': '',
    },
    '29wpbtoy': {
      'en': 'Update',
      'kn': '',
    },
    'ghu9qjj1': {
      'en': 'Update',
      'kn': '',
    },
    'f7yk8ksh': {
      'en': 'Page Title',
      'kn': '',
    },
  },
  // TaskyyemployeeCopy
  {
    'sy48nlg2': {
      'en': 'MY TASK',
      'kn': '',
    },
    'e862npkr': {
      'en': 'TextField',
      'kn': '',
    },
    'u0rz8hvu': {
      'en': 'Task Name',
      'kn': '',
    },
    'av3wke7f': {
      'en': 'Assigned by',
      'kn': '',
    },
    'brzz5zgh': {
      'en': 'Due Date',
      'kn': '',
    },
    'sla0w2qy': {
      'en': 'Priority',
      'kn': '',
    },
    'rx3e7ri6': {
      'en': 'Status',
      'kn': '',
    },
    'tr0zeq18': {
      'en': 'Button',
      'kn': '',
    },
    'u9zs8tv9': {
      'en': 'Accept',
      'kn': '',
    },
    'ojat6uyt': {
      'en': 'Decline',
      'kn': '',
    },
    'g7n0e6il': {
      'en': 'Page Title',
      'kn': '',
    },
  },
  // OBJYYownerCopy
  {
    'hkc04evv': {
      'en': 'Search objectives...',
      'kn': '',
    },
    'mnew4ux0': {
      'en': 'Active',
      'kn': '',
    },
    'g7c61z6c': {
      'en': 'Progress: 65%',
      'kn': '',
    },
    '8ifq9fu5': {
      'en': 'Delete',
      'kn': '',
    },
    'm04k0h41': {
      'en': 'Edit',
      'kn': '',
    },
    'vln0ais6': {
      'en': 'View Details',
      'kn': '',
    },
    'zs81vxr4': {
      'en': 'Sub Objectives',
      'kn': '',
    },
  },
  // DetailyyyCopyCopy
  {
    '3acfkid1': {
      'en': 'Progress Bar',
      'kn': '',
    },
    'x0adyfp7': {
      'en': 'Sub Objectives',
      'kn': '',
    },
    '4ddyhf53': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    'rg2li19a': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    'mlqarlmq': {
      'en': 'On Track',
      'kn': '',
    },
    'pkfc2269': {
      'en': '80%',
      'kn': '',
    },
    '1czy20qf': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    'd4wqm2jr': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    'kc49mmk6': {
      'en': 'On Track',
      'kn': '',
    },
    '4sno58wb': {
      'en': '80%',
      'kn': '',
    },
    '0e6ahadz': {
      'en': 'Tasks',
      'kn': '',
    },
    '4mx7hvzz': {
      'en': 'All',
      'kn': '',
    },
    '93262jkg': {
      'en': 'Select...',
      'kn': '',
    },
    'nej6rono': {
      'en': 'Search...',
      'kn': '',
    },
    'lxxeriwg': {
      'en': 'Pending',
      'kn': '',
    },
    'yqupvhva': {
      'en': 'Completed',
      'kn': '',
    },
    'zk9u33cn': {
      'en': 'All',
      'kn': '',
    },
    'bv3yvq29': {
      'en': 'Add task',
      'kn': '',
    },
    'rbrqhl92': {
      'en': 'Due',
      'kn': '',
    },
    'exdblrli': {
      'en': 'All',
      'kn': '',
    },
    'udb246cy': {
      'en': 'Select...',
      'kn': '',
    },
    '34yb2dcg': {
      'en': 'Search...',
      'kn': '',
    },
    'dqedbysu': {
      'en': 'Pending',
      'kn': '',
    },
    'lkqnyyjy': {
      'en': 'Completed',
      'kn': '',
    },
    '0t0deccf': {
      'en': 'All',
      'kn': '',
    },
    'wp5u9mfm': {
      'en': 'Add task',
      'kn': '',
    },
    'sfcd35hm': {
      'en': 'Due',
      'kn': '',
    },
    'vngma7eo': {
      'en': 'Objectives',
      'kn': '',
    },
  },
  // TaskyyCopy
  {
    'l4umdapr': {
      'en': 'TextField',
      'kn': '',
    },
    '9ql1r6q6': {
      'en': 'Task Name',
      'kn': '',
    },
    'o1i3sj1g': {
      'en': 'Due Date',
      'kn': '',
    },
    'k1145c6b': {
      'en': 'Priority',
      'kn': '',
    },
    '2r5e4iy3': {
      'en': 'Status',
      'kn': '',
    },
    'vivh463k': {
      'en': 'Button',
      'kn': '',
    },
    'w327t44i': {
      'en': 'Task Name',
      'kn': '',
    },
    '2ho9usjo': {
      'en': 'Status',
      'kn': '',
    },
    '6gmywuwq': {
      'en': 'My Tasks',
      'kn': '',
    },
  },
  // progress
  {
    'rcu4n6x9': {
      'en': 'Team Progress',
      'kn': '',
    },
    'bpz5pzmu': {
      'en': 'Real-time employee performance tracking',
      'kn': '',
    },
    'rqldamf1': {
      'en': 'This Week',
      'kn': '',
    },
    '6gbfkgof': {
      'en': 'Overall Team Performance',
      'kn': '',
    },
    'ov88480u': {
      'en': '85% Completion Rate',
      'kn': '',
    },
    '3k81wqn4': {
      'en': '47',
      'kn': '',
    },
    'iycfhn8s': {
      'en': 'Tasks Completed',
      'kn': '',
    },
    '0iv6q997': {
      'en': '12',
      'kn': '',
    },
    'ga0j0vkd': {
      'en': 'In Progress',
      'kn': '',
    },
    '5zgmrvrj': {
      'en': '5',
      'kn': '',
    },
    '9aynu0q3': {
      'en': 'Overdue',
      'kn': '',
    },
    '6jyrv23m': {
      'en': 'Weekly Progress',
      'kn': '',
    },
    'krub69ce': {
      'en': '+12% from last week',
      'kn': '',
    },
    'n8u5n3vc': {
      'en': 'Sarah Johnson',
      'kn': '',
    },
    'vrmch03p': {
      'en': 'UI/UX Designer',
      'kn': '',
    },
    'i21n6raf': {
      'en': '92% Complete',
      'kn': '',
    },
    'uzm522pf': {
      'en': 'Current Project: Website Redesign',
      'kn': '',
    },
    '4t4pz1ig': {
      'en': 'Due: June 30',
      'kn': '',
    },
    'ngp6y4mz': {
      'en': 'Tasks Completed',
      'kn': '',
    },
    'l9k4un57': {
      'en': '15/18',
      'kn': '',
    },
    'nwcsmh6c': {
      'en': 'Hours Logged',
      'kn': '',
    },
    'diz0472g': {
      'en': '42h',
      'kn': '',
    },
    'wqviki77': {
      'en': 'Michael Chen',
      'kn': '',
    },
    '8lkp08z1': {
      'en': 'Frontend Developer',
      'kn': '',
    },
    'xtdjoekb': {
      'en': '78% Complete',
      'kn': '',
    },
    'o8gvbe64': {
      'en': 'Current Project: Mobile App Development',
      'kn': '',
    },
    'i9y1vux3': {
      'en': 'Due: July 15',
      'kn': '',
    },
    'tu7nj5mw': {
      'en': 'Tasks Completed',
      'kn': '',
    },
    'f6d38dyi': {
      'en': '12/15',
      'kn': '',
    },
    'hbzypvf7': {
      'en': 'Hours Logged',
      'kn': '',
    },
    'bokbope8': {
      'en': '38h',
      'kn': '',
    },
    'thublrbn': {
      'en': 'Emily Rodriguez',
      'kn': '',
    },
    'n4lute62': {
      'en': 'Backend Developer',
      'kn': '',
    },
    'gh0ywqmf': {
      'en': '45% Complete',
      'kn': '',
    },
    'o90tk5wr': {
      'en': 'Current Project: API Integration',
      'kn': '',
    },
    '1trz7g8z': {
      'en': 'Due: July 5',
      'kn': '',
    },
    '6cbc5nz8': {
      'en': 'Tasks Completed',
      'kn': '',
    },
    's0midkzn': {
      'en': '5/12',
      'kn': '',
    },
    'isz53v4k': {
      'en': 'Hours Logged',
      'kn': '',
    },
    'pc7si86e': {
      'en': '24h',
      'kn': '',
    },
    'ruqkpmvt': {
      'en': 'David Kim',
      'kn': '',
    },
    '6fqm9qs0': {
      'en': 'QA Engineer',
      'kn': '',
    },
    '1y2jf9zw': {
      'en': '88% Complete',
      'kn': '',
    },
    '3uhom227': {
      'en': 'Current Project: Testing Automation',
      'kn': '',
    },
    'vgg947in': {
      'en': 'Due: June 28',
      'kn': '',
    },
    'ckv8yd9i': {
      'en': 'Tasks Completed',
      'kn': '',
    },
    '45ri3xml': {
      'en': '14/16',
      'kn': '',
    },
    'i0ugznpp': {
      'en': 'Hours Logged',
      'kn': '',
    },
    'rhmuxi47': {
      'en': '36h',
      'kn': '',
    },
  },
  // TaskyyCopy2
  {
    'uql8wriy': {
      'en': 'Manage and track team tasks',
      'kn': '',
    },
    'yw2gkf33': {
      'en': 'Seaech Task',
      'kn': '',
    },
    'hyvpf6q9': {
      'en': 'Task Name',
      'kn': '',
    },
    'z6tsklbz': {
      'en': 'Assigned By',
      'kn': '',
    },
    'ttqvqlx4': {
      'en': 'Assigned To',
      'kn': '',
    },
    '1qmczjzq': {
      'en': 'Due Date',
      'kn': '',
    },
    '1a9zyt21': {
      'en': 'Priority',
      'kn': '',
    },
    '6g6okyss': {
      'en': 'Status',
      'kn': '',
    },
    'o9b54ns1': {
      'en': 'Actions',
      'kn': '',
    },
    '5gxpk76b': {
      'en': 'Task Management',
      'kn': '',
    },
  },
  // noti
  {
    '5xw3btru': {
      'en': 'My Notifications',
      'kn': '',
    },
    'o4xvbtoq': {
      'en': 'All Notifications',
      'kn': '',
    },
    '5qzi04f6': {
      'en': 'Notifications',
      'kn': '',
    },
  },
  // Reportsemployee
  {
    '3hyi5wpg': {
      'en': 'Reports & Analytics',
      'kn': '',
    },
    '5p7g6rwi': {
      'en': 'Performance Overview',
      'kn': '',
    },
    'wn86gx80': {
      'en': 'Last 30 Days',
      'kn': '',
    },
    'dln67n5f': {
      'en': 'Tasks Completed',
      'kn': '',
    },
    'sobxdrof': {
      'en': '156 Completed',
      'kn': '',
    },
    'syvvwhdy': {
      'en': 'Tasks Pending',
      'kn': '',
    },
    'g2lmyyr0': {
      'en': '156 Pending',
      'kn': '',
    },
    'fk140pom': {
      'en': 'Task  Performance',
      'kn': '',
    },
    'edkgsa9x': {
      'en': 'Filter',
      'kn': '',
    },
    'w5pqv8q0': {
      'en': 'TAsk Completion Status',
      'kn': '',
    },
    'nshahfs3': {
      'en': '[Chart Placeholder]',
      'kn': '',
    },
    '6a4x9ter': {
      'en': 'Recent Projects',
      'kn': '',
    },
    '3l3yonmy': {
      'en': 'Website Redesign',
      'kn': '',
    },
    'jkwummcr': {
      'en': 'Due: June 30, 2023',
      'kn': '',
    },
    '58uy5xwb': {
      'en': '85%',
      'kn': '',
    },
    'lwp3bebz': {
      'en': 'Mobile App Development',
      'kn': '',
    },
    'fafhhgii': {
      'en': 'Due: July 15, 2023',
      'kn': '',
    },
    '9tgiuyx2': {
      'en': '65%',
      'kn': '',
    },
    'o7ya82j5': {
      'en': 'Marketing Campaign',
      'kn': '',
    },
    'zccfn9o3': {
      'en': 'Due: July 30, 2023',
      'kn': '',
    },
    'na88bmem': {
      'en': '45%',
      'kn': '',
    },
    '56692c0t': {
      'en': 'Team Performance',
      'kn': '',
    },
    'nreut2ng': {
      'en': 'This Month',
      'kn': '',
    },
    'o0amujy2': {
      'en': 'Employee Productivity',
      'kn': '',
    },
    'pc5xzxny': {
      'en': '[Chart Placeholder]',
      'kn': '',
    },
    'bp4rrvq6': {
      'en': 'Top Performers',
      'kn': '',
    },
    'zgxlrw0h': {
      'en': 'Sarah Johnson',
      'kn': '',
    },
    'b5krt9p1': {
      'en': '32 Tasks Completed',
      'kn': '',
    },
    'pdokpbbe': {
      'en': '98%',
      'kn': '',
    },
    'asbhy2gh': {
      'en': 'Michael Chen',
      'kn': '',
    },
    'hnx5c5jt': {
      'en': '28 Tasks Completed',
      'kn': '',
    },
    'wiuhclnx': {
      'en': '95%',
      'kn': '',
    },
    's435enra': {
      'en': 'Emily Davis',
      'kn': '',
    },
    '36iiu2xf': {
      'en': '25 Tasks Completed',
      'kn': '',
    },
    'wid2v2qj': {
      'en': '92%',
      'kn': '',
    },
  },
  // progressemployee
  {
    'b8czx6xf': {
      'en': 'Progress',
      'kn': '',
    },
    '8d21mlec': {
      'en': 'Real-time employee performance tracking',
      'kn': '',
    },
    '8u1z5akz': {
      'en': 'This Week',
      'kn': '',
    },
    'z9tzt6dv': {
      'en': 'Overall Team Performance',
      'kn': '',
    },
    'tubhprq3': {
      'en': '85% Completion Rate',
      'kn': '',
    },
    '2ym1y0ae': {
      'en': '47',
      'kn': '',
    },
    'vzic7s8f': {
      'en': 'Tasks Completed',
      'kn': '',
    },
    'ktj4t6r3': {
      'en': '12',
      'kn': '',
    },
    'dzefod24': {
      'en': 'In Progress',
      'kn': '',
    },
    '64dhnf40': {
      'en': '5',
      'kn': '',
    },
    'jvy76k88': {
      'en': 'Overdue',
      'kn': '',
    },
    'khy1hb2n': {
      'en': 'Weekly Progress',
      'kn': '',
    },
    'tcnwcgje': {
      'en': '+12% from last week',
      'kn': '',
    },
    'savr4gpd': {
      'en': 'Sarah Johnson',
      'kn': '',
    },
    'rvhzcqxb': {
      'en': 'UI/UX Designer',
      'kn': '',
    },
    'yfysv8zg': {
      'en': '92% Complete',
      'kn': '',
    },
    'lm5x7whh': {
      'en': 'Current Project: Website Redesign',
      'kn': '',
    },
    'sv43py1g': {
      'en': 'Due: June 30',
      'kn': '',
    },
    'idbnrcib': {
      'en': 'Tasks Completed',
      'kn': '',
    },
    't1b03s5k': {
      'en': '15/18',
      'kn': '',
    },
    'ysrn22iz': {
      'en': 'Hours Logged',
      'kn': '',
    },
    'xl2r1a1h': {
      'en': '42h',
      'kn': '',
    },
    'gudq6wbh': {
      'en': 'Michael Chen',
      'kn': '',
    },
    'glddsq4j': {
      'en': 'Frontend Developer',
      'kn': '',
    },
    'hut1md35': {
      'en': '78% Complete',
      'kn': '',
    },
    'fw6475e2': {
      'en': 'Current Project: Mobile App Development',
      'kn': '',
    },
    'c2m1bxo1': {
      'en': 'Due: July 15',
      'kn': '',
    },
    '20d25m1r': {
      'en': 'Tasks Completed',
      'kn': '',
    },
    'icfhude6': {
      'en': '12/15',
      'kn': '',
    },
    'yr425d55': {
      'en': 'Hours Logged',
      'kn': '',
    },
    '49c87lc2': {
      'en': '38h',
      'kn': '',
    },
    'd9jkqwqp': {
      'en': 'Emily Rodriguez',
      'kn': '',
    },
    'bjn7ry81': {
      'en': 'Backend Developer',
      'kn': '',
    },
    'xsw9n5pc': {
      'en': '45% Complete',
      'kn': '',
    },
    '5uq1iwdw': {
      'en': 'Current Project: API Integration',
      'kn': '',
    },
    'lgch69w9': {
      'en': 'Due: July 5',
      'kn': '',
    },
    'wps7322q': {
      'en': 'Tasks Completed',
      'kn': '',
    },
    'aadbf28s': {
      'en': '5/12',
      'kn': '',
    },
    'cj7cv2wb': {
      'en': 'Hours Logged',
      'kn': '',
    },
    '68ea5jn2': {
      'en': '24h',
      'kn': '',
    },
    'oqu3y9lq': {
      'en': 'David Kim',
      'kn': '',
    },
    '12f8aums': {
      'en': 'QA Engineer',
      'kn': '',
    },
    '5xl3z424': {
      'en': '88% Complete',
      'kn': '',
    },
    'az6hr5i6': {
      'en': 'Current Project: Testing Automation',
      'kn': '',
    },
    '552picpe': {
      'en': 'Due: June 28',
      'kn': '',
    },
    'y4a1q1kn': {
      'en': 'Tasks Completed',
      'kn': '',
    },
    '2lfc1y8o': {
      'en': '14/16',
      'kn': '',
    },
    'osci72pk': {
      'en': 'Hours Logged',
      'kn': '',
    },
    'lyhiq5ty': {
      'en': '36h',
      'kn': '',
    },
  },
  // employeeDashyyy
  {
    'owq4dute': {
      'en': 'Nanotrack',
      'kn': '',
    },
    '1ohailv0': {
      'en': 'Dashboard',
      'kn': '',
    },
    'iequgow1': {
      'en': 'Org Objectives',
      'kn': '',
    },
    '71z7x2qn': {
      'en': 'Sub Objectives',
      'kn': '',
    },
    'zlu3qqcn': {
      'en': 'Task Management',
      'kn': '',
    },
    '5tgq9bs3': {
      'en': 'My Tasks',
      'kn': '',
    },
    'iw303aye': {
      'en': 'Notifications',
      'kn': '',
    },
    '8m0b3tuw': {
      'en': 'Reports',
      'kn': '',
    },
    'd3ddn429': {
      'en': 'Logout',
      'kn': '',
    },
    'pemhs26z': {
      'en': 'Dashboard',
      'kn': '',
    },
    '39r8yngt': {
      'en': 'Assign Tasks',
      'kn': '',
    },
    '9ybuy05e': {
      'en': 'My Tasks',
      'kn': '',
    },
    'uq1kug76': {
      'en': 'Notifications',
      'kn': '',
    },
    'icf4clmo': {
      'en': 'Reports',
      'kn': '',
    },
    '01am1ayh': {
      'en': 'Logout',
      'kn': '',
    },
    '74zau5ka': {
      'en': 'Employee Dashboard',
      'kn': '',
    },
    'vypig8za': {
      'en': 'Total Tasks',
      'kn': '',
    },
    'w9ynsaar': {
      'en': '24',
      'kn': '',
    },
    'iyycldc9': {
      'en': '+12% from last month',
      'kn': '',
    },
    'cianmq9q': {
      'en': 'Completed',
      'kn': '',
    },
    'ov3dmfdw': {
      'en': '18',
      'kn': '',
    },
    'uzummzpu': {
      'en': '75% completion rate',
      'kn': '',
    },
    'f1dxdi6x': {
      'en': 'My Tasks',
      'kn': '',
    },
    'h2hh0cjx': {
      'en': 'Urgent',
      'kn': '',
    },
    'oery6dlc': {
      'en': 'Team Performance Review',
      'kn': '',
    },
    'j73n7nnq': {
      'en': 'Due: Next Week',
      'kn': '',
    },
    '985avt6l': {
      'en': 'In Progress',
      'kn': '',
    },
    'kkka704f': {
      'en': 'Budget Planning 2024',
      'kn': '',
    },
    'mhlrqaw2': {
      'en': 'Due: Next Month',
      'kn': '',
    },
    'gy540mrn': {
      'en': 'Pending',
      'kn': '',
    },
    'k00gcqwc': {
      'en': 'Recent Activities',
      'kn': '',
    },
    'ajg8jztp': {
      'en': 'View All',
      'kn': '',
    },
    '1ep5wcje': {
      'en': 'Dashboard',
      'kn': '',
    },
    'o6w3mpjl': {
      'en': 'Org Objectives',
      'kn': '',
    },
    'zvg8tjbu': {
      'en': 'Sub Objectives',
      'kn': '',
    },
    'l34sqpk8': {
      'en': 'Task Management',
      'kn': '',
    },
    '6ejc2xq7': {
      'en': 'My Tasks',
      'kn': '',
    },
    'axsf39vo': {
      'en': 'Notifications',
      'kn': '',
    },
    'ptdocqmu': {
      'en': 'Reports',
      'kn': '',
    },
    'enrszu62': {
      'en': 'Logout',
      'kn': '',
    },
  },
  // ChilObj
  {
    'y0gw0nw7': {
      'en': 'Progress Bar:',
      'kn': '',
    },
    'efkd22x7': {
      'en': 'Child Objectives',
      'kn': '',
    },
    'dplaf6mc': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    '3mky4oou': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    '43cclnm9': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    'waxokwoy': {
      'en': 'View Details',
      'kn': '',
    },
    'tafghjt5': {
      'en': 'View Details',
      'kn': '',
    },
    'lkwros7i': {
      'en': 'Tasks',
      'kn': '',
    },
    '9a5h8sj7': {
      'en': 'Add task',
      'kn': '',
    },
    'wxx8b5y9': {
      'en': 'Due',
      'kn': '',
    },
    'dz7fdldx': {
      'en': 'Due',
      'kn': '',
    },
    'krhoozoy': {
      'en': 'Add task',
      'kn': '',
    },
    'ugmharwm': {
      'en': 'Due',
      'kn': '',
    },
    '9epxzmpw': {
      'en': 'Due',
      'kn': '',
    },
    'xlcww7bi': {
      'en': 'Objectives',
      'kn': '',
    },
  },
  // ManagerObjective
  {
    'spnwc006': {
      'en': 'Objectives',
      'kn': '',
    },
    'm52d2wyy': {
      'en': 'Objectives',
      'kn': '',
    },
    'k17rz5fd': {
      'en': 'Private Objectives',
      'kn': '',
    },
    'u3q1lo22': {
      'en': 'Active',
      'kn': '',
    },
    'tgt4oo7b': {
      'en': 'Deactivated',
      'kn': '',
    },
    'pg3uq4om': {
      'en': 'Active',
      'kn': '',
    },
    'fqs4a6yz': {
      'en': 'Search objectives...',
      'kn': '',
    },
    'crz3tns5': {
      'en': 'View Details',
      'kn': '',
    },
    'xfebp9if': {
      'en': 'View Details',
      'kn': '',
    },
    '7k8my7oe': {
      'en': 'View Details',
      'kn': '',
    },
    'cnp1xzws': {
      'en': 'Public Objectives',
      'kn': '',
    },
    'gvz694ou': {
      'en': 'Search objectives...',
      'kn': '',
    },
    '77r79dcz': {
      'en': 'View Details',
      'kn': '',
    },
    'tgqfueme': {
      'en': 'View Details',
      'kn': '',
    },
    'wv7d2yf9': {
      'en': 'View Details',
      'kn': '',
    },
  },
  // calendar
  {
    'cp2gkkng': {
      'en': 'Calendar',
      'kn': '',
    },
    's14kd9fk': {
      'en': 'June 2023',
      'kn': '',
    },
    '4b4trvfk': {
      'en': 'Sun',
      'kn': '',
    },
    'vsao9bmw': {
      'en': 'Mon',
      'kn': '',
    },
    'bre34r3l': {
      'en': 'Tue',
      'kn': '',
    },
    'sp3fz9re': {
      'en': 'Wed',
      'kn': '',
    },
    'hcqs4bz7': {
      'en': 'Thu',
      'kn': '',
    },
    'qljmba8c': {
      'en': 'Fri',
      'kn': '',
    },
    'w7rfsivb': {
      'en': 'Sat',
      'kn': '',
    },
    'ogy2owbp': {
      'en': '1',
      'kn': '',
    },
    '4s3tiyog': {
      'en': '2',
      'kn': '',
    },
    'dwejkyed': {
      'en': '3',
      'kn': '',
    },
    'q8hgqgtn': {
      'en': '4',
      'kn': '',
    },
    '2jdkavyj': {
      'en': '5',
      'kn': '',
    },
    'fxbmazaf': {
      'en': 'Today\'s Tasks',
      'kn': '',
    },
    'k9ys8j33': {
      'en': 'Add Task',
      'kn': '',
    },
    'lt7ifv7m': {
      'en': 'Team Meeting',
      'kn': '',
    },
    'k4yyhp3x': {
      'en': '10:00 AM - 11:00 AM',
      'kn': '',
    },
    'xur3l0we': {
      'en': 'Discuss project milestones',
      'kn': '',
    },
    'z1kihbdp': {
      'en': 'Client Presentation',
      'kn': '',
    },
    'nzi5reab': {
      'en': '2:00 PM - 3:30 PM',
      'kn': '',
    },
    'nu8go04u': {
      'en': 'Present quarterly results',
      'kn': '',
    },
    'lltzll9y': {
      'en': 'Project Review',
      'kn': '',
    },
    'biofjf7m': {
      'en': '4:00 PM - 5:00 PM',
      'kn': '',
    },
    '6h6swrz5': {
      'en': 'Review development progress',
      'kn': '',
    },
  },
  // scheduletask
  {
    'ad2dalrq': {
      'en': 'Schedule Task',
      'kn': '',
    },
    'kdkb0c56': {
      'en': 'Calendar',
      'kn': '',
    },
    'p6vg0c3p': {
      'en': 'Task Details',
      'kn': '',
    },
    'ba8eyjcq': {
      'en': 'Task Name',
      'kn': '',
    },
    '4l25bbfb': {
      'en': 'Start Time',
      'kn': '',
    },
    'cigjt8an': {
      'en': 'End Time',
      'kn': '',
    },
    'wkr3m09q': {
      'en': 'Schedule Task',
      'kn': '',
    },
  },
  // taskProfilePage
  {
    'c7ve26nh': {
      'en': 'Comments',
      'kn': '',
    },
    'bh5ebwk2': {
      'en': '2 hours ago',
      'kn': '',
    },
    '9difqejk': {
      'en': 'Add a comment...',
      'kn': '',
    },
    'pzpt2zvd': {
      'en': 'Post',
      'kn': '',
    },
    'venatnrq': {
      'en': 'Attachments',
      'kn': '',
    },
    'g4jo3u4m': {
      'en': 'Project_Brief.pdf',
      'kn': '',
    },
    '1zrk1rlk': {
      'en': 'Requirements.docx',
      'kn': '',
    },
    'ff17ovp1': {
      'en': 'Accept',
      'kn': '',
    },
    '1sov0rtc': {
      'en': 'Reject',
      'kn': '',
    },
    '1vq7yhu6': {
      'en': 'Reassign',
      'kn': '',
    },
    'nn4ybct2': {
      'en': 'Update Status',
      'kn': '',
    },
    'qe92ee1d': {
      'en': 'Schedule Task',
      'kn': '',
    },
    'y1jrovmi': {
      'en': 'My Task',
      'kn': '',
    },
  },
  // REVIEWPAGE
  {
    '80d92z0d': {
      'en': 'Review all the tasks',
      'kn': '',
    },
    '5lv6jwxf': {
      'en': 'TextField',
      'kn': '',
    },
    '3kvgcd7f': {
      'en': 'Task Name',
      'kn': '',
    },
    'z10taaaj': {
      'en': 'Due Date',
      'kn': '',
    },
    '9f3jfx05': {
      'en': 'Priority',
      'kn': '',
    },
    'l1ixdy0v': {
      'en': 'Status',
      'kn': '',
    },
    't5o2fzls': {
      'en': 'Button',
      'kn': '',
    },
    '4ruqjntb': {
      'en': 'Task Name',
      'kn': '',
    },
    'e3es9rek': {
      'en': 'Status',
      'kn': '',
    },
    'uo4tbu53': {
      'en': 'Review Tasks',
      'kn': '',
    },
  },
  // Reviewprofilepage
  {
    'm674avty': {
      'en': 'Assigned by: ',
      'kn': '',
    },
    'w74cqa7w': {
      'en': 'Assigned To: ',
      'kn': '',
    },
    'x4ex62m4': {
      'en': 'Comments',
      'kn': '',
    },
    'jjf2nuow': {
      'en': 'Add a comment...',
      'kn': '',
    },
    'imrjyp2v': {
      'en': 'Post',
      'kn': '',
    },
    'aj1d5hro': {
      'en': 'Attachments',
      'kn': '',
    },
    'b9nyo0fe': {
      'en': 'Approve',
      'kn': '',
    },
    'gxj1eg3j': {
      'en': 'Redo',
      'kn': '',
    },
    '0uy9mcze': {
      'en': 'Review ',
      'kn': '',
    },
  },
  // Employeeprofile
  {
    '018w9urx': {
      'en': 'Employee Profile',
      'kn': '',
    },
    '6q75uafl': {
      'en': 'Engineering Department',
      'kn': '',
    },
    'kwqn0vlw': {
      'en': 'Edit Profile',
      'kn': '',
    },
    '1mkqq1qr': {
      'en': 'Email',
      'kn': '',
    },
    'pvsfdw5p': {
      'en': 'Phone',
      'kn': '',
    },
    'd3eqs4j4': {
      'en': 'Task Summary',
      'kn': '',
    },
    'f489ixm5': {
      'en': '12',
      'kn': '',
    },
    'srv3uq73': {
      'en': 'Active',
      'kn': '',
    },
    'bxhcl0mq': {
      'en': '45',
      'kn': '',
    },
    'spwxxqre': {
      'en': 'Completed',
      'kn': '',
    },
    'jhqi27zr': {
      'en': '45',
      'kn': '',
    },
    't71qzqyx': {
      'en': 'Pending Approval',
      'kn': '',
    },
    'w6zrg1tb': {
      'en': '8',
      'kn': '',
    },
    'nzbjxnqq': {
      'en': 'Pending',
      'kn': '',
    },
    'k4mvwr9r': {
      'en': 'Current Tasks',
      'kn': '',
    },
    'vklpzd70': {
      'en': 'Mobile App Development',
      'kn': '',
    },
    'p9l3xeun': {
      'en': 'Due: June 30, 2024',
      'kn': '',
    },
    'wqslp856': {
      'en': 'In Progress',
      'kn': '',
    },
    'gdpm9p5g': {
      'en': 'API Integration',
      'kn': '',
    },
    'f9hckce1': {
      'en': 'Due: July 15, 2024',
      'kn': '',
    },
    'yzsgf4t2': {
      'en': 'Pending',
      'kn': '',
    },
    'pe1gjhp3': {
      'en': 'Code Review',
      'kn': '',
    },
    'w8lq2xy3': {
      'en': 'Due: June 25, 2024',
      'kn': '',
    },
    'ba5jxb3q': {
      'en': 'Overdue',
      'kn': '',
    },
    'xwpe608n': {
      'en': 'Pending Approvals',
      'kn': '',
    },
    'e68voo9t': {
      'en': 'Feature Documentation',
      'kn': '',
    },
    'q4ubl9tz': {
      'en': 'Submitted: June 20, 2024',
      'kn': '',
    },
    '6jl2xv4h': {
      'en': 'Under Review',
      'kn': '',
    },
    'xzr446xy': {
      'en': 'Sprint Planning',
      'kn': '',
    },
    'pzlhj1rz': {
      'en': 'Submitted: June 22, 2024',
      'kn': '',
    },
    'q2w9sq48': {
      'en': 'Under Review',
      'kn': '',
    },
  },
  // AdminDashboard
  {
    'waqlg0c5': {
      'en': 'Dashboard',
      'kn': '',
    },
    'chvot6zr': {
      'en': 'Manage Users',
      'kn': '',
    },
    '1e6m3z7w': {
      'en': 'Notifications',
      'kn': '',
    },
    'z8zkw22x': {
      'en': 'Logout',
      'kn': '',
    },
    'sv8s5dsr': {
      'en': 'Admin Dashboard',
      'kn': '',
    },
    'z1s1frwt': {
      'en': 'Total Users',
      'kn': '',
    },
    'r516t7mn': {
      'en': 'Total Managers',
      'kn': '',
    },
    'agj8bn4j': {
      'en': 'Total Staff\'s',
      'kn': '',
    },
    '3fveuxi7': {
      'en': 'Total HR\'s',
      'kn': '',
    },
    'yxmjlsl1': {
      'en': 'Total Users',
      'kn': '',
    },
    '81nytmwf': {
      'en': 'Total Managers',
      'kn': '',
    },
    '9734q4uu': {
      'en': 'Total Employees',
      'kn': '',
    },
    'xz1ese4x': {
      'en': 'Total HR\'s',
      'kn': '',
    },
    'z4p559ja': {
      'en': 'Sub-Objectives Overview',
      'kn': '',
    },
    '63x4iuxr': {
      'en': 'Name',
      'kn': '',
    },
    'u5o4eeac': {
      'en': 'Manager',
      'kn': '',
    },
    'ss2q1vg4': {
      'en': 'Progress',
      'kn': '',
    },
    'quyokigw': {
      'en': 'Deadline',
      'kn': '',
    },
    'ztxshln2': {
      'en': '2 days left',
      'kn': '2 ದಿನಗಳು ಉಳಿದಿವೆ',
    },
    '62oevxni': {
      'en': 'NanoTrack',
      'kn': '',
    },
    'bh0gh2n9': {
      'en': 'Administrator',
      'kn': '',
    },
    'en1rn5gk': {
      'en': 'Dashboard',
      'kn': '',
    },
    'chf3vov5': {
      'en': 'Manage Users',
      'kn': '',
    },
    'kofm4fh1': {
      'en': 'Notifications',
      'kn': '',
    },
    'rv3xsivb': {
      'en': 'Logout',
      'kn': '',
    },
    'ungkcx3t': {
      'en': 'NanoDisha',
      'kn': '',
    },
    'qbyoycfa': {
      'en': 'Home',
      'kn': '',
    },
  },
  // DASHHYYYCopyCopy
  {
    'nal2mot1': {
      'en': 'Administrator',
      'kn': '',
    },
    '4fuvphe0': {
      'en': 'Dashboard',
      'kn': '',
    },
    '50dhths3': {
      'en': 'Objectives',
      'kn': '',
    },
    'o4xwy486': {
      'en': 'Objectives New',
      'kn': '',
    },
    'gda2bcld': {
      'en': 'Task Management',
      'kn': '',
    },
    '50vimhhp': {
      'en': 'Employee Management',
      'kn': '',
    },
    'yjywbfi7': {
      'en': 'Reports',
      'kn': '',
    },
    'preiogje': {
      'en': 'Notifications',
      'kn': '',
    },
    '82ntxsk9': {
      'en': 'Logout',
      'kn': '',
    },
    'vhlcrau4': {
      'en': 'Admin Dashboard',
      'kn': '',
    },
    'ui4emgzl': {
      'en': 'Add Objective',
      'kn': '',
    },
    'k7j489g7': {
      'en': 'Here\'s what\'s happening with your projects',
      'kn': '',
    },
    'xn02rjue': {
      'en': 'Total Objectives',
      'kn': '',
    },
    '4dbqzv0u': {
      'en': 'In Progress',
      'kn': '',
    },
    'tk07bt3o': {
      'en': 'Completed',
      'kn': '',
    },
    '3xbpc0nb': {
      'en': 'Pending Tasks',
      'kn': '',
    },
    'uqsk7dzq': {
      'en': 'Generate Report',
      'kn': '',
    },
    'ym0d8eb8': {
      'en': 'Add Objective',
      'kn': '',
    },
    'ojo0uhbg': {
      'en': 'Total Objectives',
      'kn': '',
    },
    'xrlklh9n': {
      'en': 'In Progress',
      'kn': '',
    },
    'mzwz9ci5': {
      'en': 'Completed',
      'kn': '',
    },
    '2miz4xw7': {
      'en': 'Pending Tasks',
      'kn': '',
    },
    '6hoyo623': {
      'en': 'Overview',
      'kn': '',
    },
    '1g8yip4i': {
      'en': 'Name',
      'kn': '',
    },
    'kxhz526g': {
      'en': 'Manager',
      'kn': '',
    },
    'xkrsvv32': {
      'en': 'Progress',
      'kn': '',
    },
    'lqtjn7uj': {
      'en': 'Deadline',
      'kn': '',
    },
    '6qoxpolq': {
      'en': '2 days left',
      'kn': '',
    },
    'qg10jr9p': {
      'en': 'Recent Activity',
      'kn': '',
    },
    '3b13522m': {
      'en': 'Recent Activity',
      'kn': '',
    },
    'cl6xlury': {
      'en': 'Market Analysis completed',
      'kn': '',
    },
    '5wib38aj': {
      'en': '2 hours ago',
      'kn': '',
    },
    'thm7cien': {
      'en': 'New objective created',
      'kn': '',
    },
    'simukkjn': {
      'en': '4 hours ago',
      'kn': '',
    },
    'op5e9whx': {
      'en': 'New team member added',
      'kn': '',
    },
    'f78g4qiy': {
      'en': 'Yesterday',
      'kn': '',
    },
    'ckk1l8h2': {
      'en': 'NanoTrack',
      'kn': '',
    },
    'tt55yuqk': {
      'en': 'Administrator',
      'kn': '',
    },
    'f5q7xhzo': {
      'en': 'Dashboard',
      'kn': '',
    },
    'qzjlr4i2': {
      'en': 'Objectives',
      'kn': 'ಉದ್ದೇಶಗಳು',
    },
    'qs262ceu': {
      'en': 'Task Management',
      'kn': '',
    },
    'cq0huht8': {
      'en': 'Employee Management',
      'kn': '',
    },
    '6y11pzfi': {
      'en': 'Reports',
      'kn': '',
    },
    'k8jbjr3p': {
      'en': 'Notifications',
      'kn': '',
    },
    'o2iixzdg': {
      'en': 'Logout',
      'kn': '',
    },
    'di37cm90': {
      'en': 'Home',
      'kn': '',
    },
    'kl56d7r9': {
      'en': 'NanoTrack',
      'kn': '',
    },
  },
  // EmployeeDashboard
  {
    '73iej81f': {
      'en': 'Administrator',
      'kn': '',
    },
    'gz48k7x5': {
      'en': 'Dashboard',
      'kn': '',
    },
    '9twgnsg7': {
      'en': 'Public Objectives',
      'kn': '',
    },
    '6mdbjzno': {
      'en': 'Task Management',
      'kn': '',
    },
    'b2csktvr': {
      'en': 'Employee Management',
      'kn': '',
    },
    '0ddyi6vf': {
      'en': 'Reports',
      'kn': '',
    },
    'n7m8gyxe': {
      'en': 'Notifications',
      'kn': '',
    },
    'u28kze20': {
      'en': 'Logout',
      'kn': '',
    },
    'ufg9l4eb': {
      'en': 'Employee Dashboard',
      'kn': '',
    },
    'crtd9am2': {
      'en': 'Here\'s what\'s happening with your projects',
      'kn': '',
    },
    'cgis7ag0': {
      'en': 'Add Objective',
      'kn': '',
    },
    '1v8frrha': {
      'en': 'Here\'s what\'s happening with your projects',
      'kn': '',
    },
    '7bwbn6sn': {
      'en': 'Total Objectives',
      'kn': '',
    },
    'tojboe1p': {
      'en': 'In Progress',
      'kn': '',
    },
    'xbcflyms': {
      'en': 'Completed',
      'kn': '',
    },
    'm8hnkyzy': {
      'en': 'Pending Tasks',
      'kn': '',
    },
    'wqt3d4w6': {
      'en': 'Generate Report',
      'kn': '',
    },
    'rm77d3ik': {
      'en': 'Add Objective',
      'kn': '',
    },
    'jy8qv471': {
      'en': 'Total Objectives',
      'kn': '',
    },
    'wzm5ian8': {
      'en': 'In Progress',
      'kn': '',
    },
    'cztwkhqb': {
      'en': 'Completed',
      'kn': '',
    },
    '1r7r9ec0': {
      'en': 'Pending Tasks',
      'kn': '',
    },
    '8828g56n': {
      'en': 'Overview',
      'kn': '',
    },
    '9jgu79we': {
      'en': 'Name',
      'kn': '',
    },
    '5ogde7i7': {
      'en': 'Manager',
      'kn': '',
    },
    'xu6uqc86': {
      'en': 'Progress',
      'kn': '',
    },
    'zbjrzo7n': {
      'en': 'Deadline',
      'kn': '',
    },
    '8sl0ysr7': {
      'en': '2 days left',
      'kn': '',
    },
    '4f8g08ni': {
      'en': 'Recent Activity',
      'kn': '',
    },
    'pevhnfm8': {
      'en': 'Recent Activity',
      'kn': '',
    },
    '4elxjcqu': {
      'en': 'Market Analysis completed',
      'kn': '',
    },
    '9choi6c8': {
      'en': '2 hours ago',
      'kn': '',
    },
    'stkndnyx': {
      'en': 'New objective created',
      'kn': '',
    },
    'j6oil1jr': {
      'en': '4 hours ago',
      'kn': '',
    },
    'ly5k0s1j': {
      'en': 'New team member added',
      'kn': '',
    },
    'stlbmbus': {
      'en': 'Yesterday',
      'kn': '',
    },
    'sujdp1yf': {
      'en': 'NanoTrack',
      'kn': '',
    },
    '8oucndtf': {
      'en': 'Administrator',
      'kn': '',
    },
    '623l2k9c': {
      'en': 'Dashboard',
      'kn': '',
    },
    'kz9zzf8w': {
      'en': 'Objectives',
      'kn': '',
    },
    'pqbacgi5': {
      'en': 'Task Management',
      'kn': '',
    },
    '1kqe29ez': {
      'en': 'Employee Management',
      'kn': '',
    },
    'e0l59cau': {
      'en': 'Reports',
      'kn': '',
    },
    'xiymq3ur': {
      'en': 'Notifications',
      'kn': '',
    },
    '0esbj1nz': {
      'en': 'Logout',
      'kn': '',
    },
    'jmrktrrg': {
      'en': 'Home',
      'kn': '',
    },
    'f3bsjsc1': {
      'en': 'NanoTrack',
      'kn': '',
    },
  },
  // ManagerDashboard
  {
    'rfdgi5fo': {
      'en': 'Dashboard',
      'kn': 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
    },
    'emy6opnv': {
      'en': 'Objectives',
      'kn': 'ಉದ್ದೇಶಗಳು',
    },
    'f0sn9229': {
      'en': 'Task Management',
      'kn': 'ಕಾರ್ಯ ನಿರ್ವಹಣೆ',
    },
    'q6j65bp8': {
      'en': 'Review Request',
      'kn': 'ವಿಮರ್ಶೆ ವಿನಂತಿ',
    },
    'z0ptq9gn': {
      'en': 'Notifications',
      'kn': 'ಅಧಿಸೂಚನೆಗಳು',
    },
    'r9xr0iva': {
      'en': 'Logout',
      'kn': 'ಲಾಗ್ಔಟ್',
    },
    '777llr9b': {
      'en': 'Manager Dashboard',
      'kn': 'ಮ್ಯಾನೇಜರ್ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
    },
    'k2niv9bo': {
      'en': 'Manager Dashboard',
      'kn': 'ಮ್ಯಾನೇಜರ್ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
    },
    'lr33zpps': {
      'en': 'Total Objectives',
      'kn': 'ಒಟ್ಟು ಉದ್ದೇಶಗಳು',
    },
    'xvv95e2p': {
      'en': 'Total Tasks ',
      'kn': 'ಒಟ್ಟು ಕಾರ್ಯಗಳು',
    },
    'qjz5v89j': {
      'en': 'Pending Tasks',
      'kn': 'ಬಾಕಿ ಉಳಿದಿರುವ ಕಾರ್ಯಗಳು',
    },
    '6d08knjr': {
      'en': 'Completed Tasks',
      'kn': 'ಪೂರ್ಣಗೊಂಡ ಕಾರ್ಯಗಳು',
    },
    '7wsp3yca': {
      'en': 'Sub-Objectives Overview',
      'kn': 'ಉಪ-ಉದ್ದೇಶಗಳ ಅವಲೋಕನ',
    },
    '3d07hkzw': {
      'en': 'Name',
      'kn': 'ಹೆಸರು',
    },
    'jn52n0y8': {
      'en': 'Manager',
      'kn': 'ವ್ಯವಸ್ಥಾಪಕ',
    },
    'a26j8wue': {
      'en': 'Progress',
      'kn': 'ಪ್ರಗತಿ',
    },
    'mmj28moj': {
      'en': 'Deadline',
      'kn': 'ಕೊನೆಯ ದಿನಾಂಕ',
    },
    'h1y2gwzs': {
      'en': '2 days left',
      'kn': '2 ದಿನಗಳು ಉಳಿದಿವೆ',
    },
    'qkdhtw9e': {
      'en': 'Total Objectives',
      'kn': 'ಒಟ್ಟು ಉದ್ದೇಶಗಳು',
    },
    'wzvzpxl6': {
      'en': 'Total Tasks ',
      'kn': 'ಒಟ್ಟು ಕಾರ್ಯಗಳು',
    },
    'vxbm1zn9': {
      'en': 'Pending Tasks',
      'kn': 'ಬಾಕಿ ಉಳಿದಿರುವ ಕಾರ್ಯಗಳು',
    },
    'mferax7s': {
      'en': 'Completed Tasks',
      'kn': 'ಪೂರ್ಣಗೊಂಡ ಕಾರ್ಯಗಳು',
    },
    '9ooobpe1': {
      'en': 'NanoTrack',
      'kn': 'ನ್ಯಾನೋಟ್ರ್ಯಾಕ್',
    },
    'yyd4hv6r': {
      'en': 'Dashboard',
      'kn': 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
    },
    'ghnc4wmz': {
      'en': 'Jam Board',
      'kn': 'ಜಾಮ್ ಬೋರ್ಡ್',
    },
    'li962vrf': {
      'en': 'Objectives',
      'kn': 'ಉದ್ದೇಶಗಳು',
    },
    '3qpzqlyt': {
      'en': 'Task Management',
      'kn': 'ಕಾರ್ಯ ನಿರ್ವಹಣೆ',
    },
    'q1nd9pdu': {
      'en': 'Logout',
      'kn': 'ಲಾಗ್ಔಟ್',
    },
    '05v3neim': {
      'en': 'NanoDisha',
      'kn': 'ನಂದಿಶಾ',
    },
  },
  // EmployeeeManagePage
  {
    '7tekoyft': {
      'en': 'Manage Team Members',
      'kn': '',
    },
    'kl9osw8b': {
      'en': 'Search by name, department or designation',
      'kn': '',
    },
    'tdbgouso': {
      'en': 'DEACTIVE',
      'kn': '',
    },
    '17vu1euq': {
      'en': 'View',
      'kn': '',
    },
    '2hd0pw7m': {
      'en': 'Michael Chen',
      'kn': '',
    },
    '6tpt0eze': {
      'en': 'Product Manager • Product',
      'kn': '',
    },
    'oqoid2g8': {
      'en': 'Active',
      'kn': '',
    },
    'h7wayygs': {
      'en': 'View',
      'kn': '',
    },
    'shy6aslp': {
      'en': 'Emily Rodriguez',
      'kn': '',
    },
    'y4505qdq': {
      'en': 'UX Designer • Design',
      'kn': '',
    },
    '1unb60qd': {
      'en': 'On Leave',
      'kn': '',
    },
    'ho3mmhje': {
      'en': 'View',
      'kn': '',
    },
    'rlpre3fn': {
      'en': 'David Kim',
      'kn': '',
    },
    '4kvkezoq': {
      'en': 'Marketing Lead • Marketing',
      'kn': '',
    },
    'js48ysis': {
      'en': 'Active',
      'kn': '',
    },
    'yg3ot876': {
      'en': 'View',
      'kn': '',
    },
    'oljqey5q': {
      'en': 'Rachel Thompson',
      'kn': '',
    },
    'b26kwbfw': {
      'en': 'HR Manager • Human Resources',
      'kn': '',
    },
    'uo0b80gz': {
      'en': 'Active',
      'kn': '',
    },
    'a3q1fxzl': {
      'en': 'View',
      'kn': '',
    },
    'z6kgas4i': {
      'en': 'View',
      'kn': '',
    },
    'qcsuyzpj': {
      'en': 'Michael Chen',
      'kn': '',
    },
    'imgm27h4': {
      'en': 'Product Manager • Product',
      'kn': '',
    },
    'yieb5uap': {
      'en': 'Active',
      'kn': '',
    },
    '8xho4oms': {
      'en': 'View',
      'kn': '',
    },
    '331wao6a': {
      'en': 'Emily Rodriguez',
      'kn': '',
    },
    '7z83okd6': {
      'en': 'UX Designer • Design',
      'kn': '',
    },
    'yhddorf2': {
      'en': 'On Leave',
      'kn': '',
    },
    '9v8uq9j3': {
      'en': 'View',
      'kn': '',
    },
    'wgc6dckp': {
      'en': 'David Kim',
      'kn': '',
    },
    'bzko9nbx': {
      'en': 'Marketing Lead • Marketing',
      'kn': '',
    },
    'c4atr5vf': {
      'en': 'Active',
      'kn': '',
    },
    '94jidhwt': {
      'en': 'View',
      'kn': '',
    },
    't9qjo6cv': {
      'en': 'Rachel Thompson',
      'kn': '',
    },
    'ctmm4gb0': {
      'en': 'HR Manager • Human Resources',
      'kn': '',
    },
    '7b7ja1pp': {
      'en': 'Active',
      'kn': '',
    },
    '990dj4de': {
      'en': 'View',
      'kn': '',
    },
  },
  // EmpProfile
  {
    'i8nq678j': {
      'en': 'Employee Profile',
      'kn': '',
    },
    '7dahunjo': {
      'en': 'Edit',
      'kn': '',
    },
    '016igkel': {
      'en': 'Email',
      'kn': '',
    },
    'b126igvr': {
      'en': 'Phone',
      'kn': '',
    },
  },
  // ProfilePage
  {
    'ncykirf4': {
      'en': 'Full Name',
      'kn': '',
    },
    'inbdn9e8': {
      'en': 'Department',
      'kn': '',
    },
    'lso29wxj': {
      'en': 'Staff Number',
      'kn': '',
    },
    '25tdtvsm': {
      'en': 'Phone Number',
      'kn': '',
    },
    'hpfiaw58': {
      'en': 'Email ID',
      'kn': '',
    },
    'l5itybw6': {
      'en': 'Position',
      'kn': '',
    },
    'ik7s13lv': {
      'en': 'Save Changes',
      'kn': '',
    },
    'h4x0xk8d': {
      'en': 'Edit Profile',
      'kn': '',
    },
  },
  // Adminprofile
  {
    'mxbv2e7e': {
      'en': 'Your Details',
      'kn': '',
    },
    'pzsmzr2e': {
      'en': 'Department',
      'kn': '',
    },
    'k2chlke6': {
      'en': 'Staff Number',
      'kn': '',
    },
    'sg0md316': {
      'en': 'Phone Number',
      'kn': '',
    },
    'tkkwzx55': {
      'en': 'Email ID',
      'kn': '',
    },
    '4mhizdc9': {
      'en': 'Your Details',
      'kn': '',
    },
    '2zmba9j0': {
      'en': 'Department',
      'kn': '',
    },
    'wvgoiaex': {
      'en': 'Staff Number',
      'kn': '',
    },
    'edlb5beh': {
      'en': 'Phone Number',
      'kn': '',
    },
    'lo7ityvb': {
      'en': 'Email ID',
      'kn': '',
    },
    'bx29ejdb': {
      'en': 'My Profile',
      'kn': '',
    },
  },
  // HRDashboard
  {
    '6jlkklvj': {
      'en': 'Administrator',
      'kn': '',
    },
    'ou2hj66q': {
      'en': 'Dashboard',
      'kn': '',
    },
    'pe9b1abb': {
      'en': 'Objectives',
      'kn': '',
    },
    '8kcmczyu': {
      'en': 'Objectives New',
      'kn': '',
    },
    'hs7anyxd': {
      'en': 'Task Management',
      'kn': '',
    },
    'lgq7ifrh': {
      'en': 'Employee Management',
      'kn': '',
    },
    '6hntz6u2': {
      'en': 'Reports',
      'kn': '',
    },
    'fl9l4h4m': {
      'en': 'Notifications',
      'kn': '',
    },
    'xx5uwiol': {
      'en': 'HR Dashboard',
      'kn': '',
    },
    '8uikw9py': {
      'en': 'Here\'s what\'s happening with your projects',
      'kn': '',
    },
    'oozhs38j': {
      'en': 'Add Objective',
      'kn': '',
    },
    '9nmujzsg': {
      'en': 'Here\'s what\'s happening with your projects',
      'kn': '',
    },
    'vvsrc9i4': {
      'en': 'Total Objectives',
      'kn': '',
    },
    'x8bph9iz': {
      'en': 'In Progress',
      'kn': '',
    },
    'mxcl6d0z': {
      'en': 'Completed',
      'kn': '',
    },
    'z4d89p7w': {
      'en': 'Pending Tasks',
      'kn': '',
    },
    'd65f84zx': {
      'en': 'Generate Report',
      'kn': '',
    },
    'v3mbv9bp': {
      'en': 'Add Objective',
      'kn': '',
    },
    'p4nrdarj': {
      'en': 'Total Objectives',
      'kn': '',
    },
    'zbf7l8vg': {
      'en': 'In Progress',
      'kn': '',
    },
    'b5v2lfcr': {
      'en': 'Completed',
      'kn': '',
    },
    'ys3nm9ax': {
      'en': 'Pending Tasks',
      'kn': '',
    },
    '5pe4k2h4': {
      'en': 'Overview',
      'kn': '',
    },
    'qyovsabt': {
      'en': 'Name',
      'kn': '',
    },
    'v9gvvj5k': {
      'en': 'Manager',
      'kn': '',
    },
    'ad9x4dvg': {
      'en': 'Progress',
      'kn': '',
    },
    'gzkqhaol': {
      'en': 'Deadline',
      'kn': '',
    },
    'arjqfgic': {
      'en': '2 days left',
      'kn': '',
    },
    'yxdwbylm': {
      'en': 'Recent Activity',
      'kn': '',
    },
    'iomjmook': {
      'en': 'Sub-Objectives Overview',
      'kn': '',
    },
    'gly73k2g': {
      'en': 'Name',
      'kn': '',
    },
    '84s5h49e': {
      'en': 'Manager',
      'kn': '',
    },
    'x2v4udxv': {
      'en': 'Progress',
      'kn': '',
    },
    '7c0vy6yd': {
      'en': 'Deadline',
      'kn': '',
    },
    'uwyvjzyi': {
      'en': '2 days left',
      'kn': '',
    },
    'gb8z4r1c': {
      'en': 'Recent Activity',
      'kn': '',
    },
    'wp62xtna': {
      'en': 'Market Analysis completed',
      'kn': '',
    },
    'a4vu6lbn': {
      'en': '2 hours ago',
      'kn': '',
    },
    'mmmtuysy': {
      'en': 'New objective created',
      'kn': '',
    },
    'hjjimv6m': {
      'en': '4 hours ago',
      'kn': '',
    },
    '84ct6f2e': {
      'en': 'New team member added',
      'kn': '',
    },
    'nc5a8ehm': {
      'en': 'Yesterday',
      'kn': '',
    },
    'ig8ipl9k': {
      'en': 'NanoTrack',
      'kn': '',
    },
    'wnhcrxi2': {
      'en': 'Administrator',
      'kn': '',
    },
    '7wiotcmz': {
      'en': 'Dashboard',
      'kn': '',
    },
    'an0a0y7n': {
      'en': 'Objectives',
      'kn': '',
    },
    '73dbg0r6': {
      'en': 'Task Management',
      'kn': '',
    },
    'kmmokui9': {
      'en': 'Employee Management',
      'kn': '',
    },
    'ww0oy3bp': {
      'en': 'Reports',
      'kn': '',
    },
    'v72w1ycw': {
      'en': 'Notifications',
      'kn': '',
    },
    'ot2timcq': {
      'en': 'Logout',
      'kn': '',
    },
    'v8j9vdoo': {
      'en': 'Home',
      'kn': '',
    },
    'uf90y6xu': {
      'en': 'NanoTrack',
      'kn': '',
    },
  },
  // taskAssignorPage
  {
    '9zuq1rk2': {
      'en': 'Reviewable Task',
      'kn': '',
    },
    'tcs9qv88': {
      'en': 'Attached Jam',
      'kn': '',
    },
    'kmuf8ivt': {
      'en': 'Comments',
      'kn': '',
    },
    'peg7viv8': {
      'en': 'Attachment',
      'kn': '',
    },
    'vmbwrr74': {
      'en': 'Type a comment or attach a document....',
      'kn': '',
    },
    'tbfvbj6x': {
      'en': 'Schedule Logs',
      'kn': '',
    },
    'cts1zx1j': {
      'en': 'Attachments',
      'kn': '',
    },
    'aibg5txu': {
      'en': 'ATTACHMENT',
      'kn': '',
    },
    '061au0bl': {
      'en': 'Task Profile',
      'kn': '',
    },
  },
  // ReportsAndAnalytics
  {
    'v3pwekp9': {
      'en': 'Analytics & Reports',
      'kn': '',
    },
    'siy8iiix': {
      'en': 'Organization Performance',
      'kn': '',
    },
    'zqf1dz4j': {
      'en': 'AI-Driven Analytics Dashboard',
      'kn': '',
    },
    'hh7hvx68': {
      'en': 'Objective Level Analysis',
      'kn': '',
    },
    'bf3l1g0a': {
      'en': 'Total Objectives',
      'kn': '',
    },
    'cbxpw5bt': {
      'en': 'Completion Rate',
      'kn': '',
    },
    'p6aevy9a': {
      'en': '78%',
      'kn': '',
    },
    'ejf6eqpi': {
      'en': 'On Track',
      'kn': '',
    },
    '6kzy1jwk': {
      'en': '85%',
      'kn': '',
    },
    'od89ihwx': {
      'en': 'Person Level Overview',
      'kn': '',
    },
    't26qwzbw': {
      'en': 'Active Contributors',
      'kn': '',
    },
    '9qmwezfd': {
      'en': '45',
      'kn': '',
    },
    'mz9ah36a': {
      'en': 'Avg Tasks/Person',
      'kn': '',
    },
    'ogqvgkof': {
      'en': '12',
      'kn': '',
    },
    'z79syu87': {
      'en': 'Top Performers',
      'kn': '',
    },
    '69f8itrc': {
      'en': 'Sarah Johnson',
      'kn': '',
    },
    'hrs14b4t': {
      'en': '32 completed tasks',
      'kn': '',
    },
    'qp4ys92f': {
      'en': 'Manager Level Insights',
      'kn': '',
    },
    'wgnp8o8t': {
      'en': 'Total Managers',
      'kn': '',
    },
    'eeudhogm': {
      'en': '12',
      'kn': '',
    },
    'l8l814mp': {
      'en': 'Avg Team Size',
      'kn': '',
    },
    'ph0vjd8i': {
      'en': '8',
      'kn': '',
    },
    'lyu6buqh': {
      'en': 'Department Performance',
      'kn': '',
    },
    'itmkt91z': {
      'en': 'Engineering',
      'kn': '',
    },
    '8fr5givg': {
      'en': '92% completion',
      'kn': '',
    },
    'n3mdtlop': {
      'en': 'Marketing',
      'kn': '',
    },
    'h85vie4j': {
      'en': '87% completion',
      'kn': '',
    },
    '2pgzlwur': {
      'en': 'Sales',
      'kn': '',
    },
    'g93l7usc': {
      'en': '83% completion',
      'kn': '',
    },
    'wxwdpru2': {
      'en': 'Organization Level Metrics',
      'kn': '',
    },
    '5wo628ry': {
      'en': 'Total Tasks',
      'kn': '',
    },
    'w0ma382h': {
      'en': '1,234',
      'kn': '',
    },
    'a16yfnth': {
      'en': 'Completion Rate',
      'kn': '',
    },
    'p795jvde': {
      'en': '87%',
      'kn': '',
    },
    'oq05nf2u': {
      'en': 'Status Distribution',
      'kn': '',
    },
    '31tuiuvb': {
      'en': 'Completed',
      'kn': '',
    },
    'y0mh9soc': {
      'en': '876 tasks',
      'kn': '',
    },
    'q2yailbi': {
      'en': 'In Progress',
      'kn': '',
    },
    'a34dzr0q': {
      'en': '245 tasks',
      'kn': '',
    },
    'r7qze3bh': {
      'en': 'Not Started',
      'kn': '',
    },
    'm9urg1lo': {
      'en': '113 tasks',
      'kn': '',
    },
    '4nrpq8vr': {
      'en': 'Generate Detailed Report',
      'kn': '',
    },
  },
  // PublicChildObj
  {
    'h8p1fc0c': {
      'en': 'Progress Bar:',
      'kn': '',
    },
    'aiuarcuu': {
      'en': 'Sub Objectives',
      'kn': '',
    },
    'eay09jxr': {
      'en': 'Add Child Objective',
      'kn': '',
    },
    'tnuvhual': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    'li6lvf7b': {
      'en': 'Tasks',
      'kn': '',
    },
    'lgq0ry8e': {
      'en': 'All',
      'kn': '',
    },
    '7pj2nib4': {
      'en': 'Select...',
      'kn': '',
    },
    'jpw7f0ss': {
      'en': 'Search...',
      'kn': '',
    },
    'ly5ifvlx': {
      'en': 'Pending',
      'kn': '',
    },
    'ogcikkuy': {
      'en': 'Completed',
      'kn': '',
    },
    'pfti1v6y': {
      'en': 'All',
      'kn': '',
    },
    'z2vi04zu': {
      'en': 'Add task',
      'kn': '',
    },
    'sxabljtn': {
      'en': 'Due',
      'kn': '',
    },
    'kxjbqtn0': {
      'en': 'Due',
      'kn': '',
    },
    'cket1lmg': {
      'en': 'Public Objective',
      'kn': '',
    },
  },
  // TaskReview
  {
    'vrktxgog': {
      'en': 'Task Management',
      'kn': '',
    },
    'qjqz82zb': {
      'en': 'Manage and track team tasks',
      'kn': '',
    },
    'rgjqbmo7': {
      'en': 'TextField',
      'kn': '',
    },
    '5m79042o': {
      'en': 'Sort by: ',
      'kn': '',
    },
    't02f57kn': {
      'en': 'Completed',
      'kn': '',
    },
    '802alldw': {
      'en': 'Pending',
      'kn': '',
    },
    '54zulsvx': {
      'en': 'Not Started',
      'kn': '',
    },
    'c2cbl747': {
      'en': 'Task Name',
      'kn': '',
    },
    'viiu908m': {
      'en': 'Assigned By',
      'kn': '',
    },
    '35t4ov97': {
      'en': 'Assigned To',
      'kn': '',
    },
    'uv96qjes': {
      'en': 'Due Date',
      'kn': '',
    },
    '6dof88rk': {
      'en': 'Priority',
      'kn': '',
    },
    'oni2uu51': {
      'en': 'Actions',
      'kn': '',
    },
    'i4xyfc7y': {
      'en': 'Review Request',
      'kn': '',
    },
  },
  // TaskManagement
  {
    'ebp1rpha': {
      'en': 'Task Management',
      'kn': '',
    },
    'dd9tisp8': {
      'en': 'Task Overview',
      'kn': '',
    },
    'bzklt2nw': {
      'en': 'Manage and track your team\'s progress',
      'kn': '',
    },
    'ss9t2p17': {
      'en': 'Add Task',
      'kn': '',
    },
    'oile51g0': {
      'en': 'Pending',
      'kn': '',
    },
    'bi4it3xy': {
      'en': '12',
      'kn': '',
    },
    '4apbl9os': {
      'en': 'Completed',
      'kn': '',
    },
    'dnhlx3yw': {
      'en': '45',
      'kn': '',
    },
    'aphdvxf5': {
      'en': 'Delayed',
      'kn': '',
    },
    'zhswn40o': {
      'en': '3',
      'kn': '',
    },
    'm26rst48': {
      'en': 'All Tasks',
      'kn': '',
    },
    'opgsqc2q': {
      'en': 'Sort by',
      'kn': '',
    },
    '3ono4azd': {
      'en': 'Filter',
      'kn': '',
    },
    'dud46ngq': {
      'en': 'Task Name',
      'kn': '',
    },
    'qlquasil': {
      'en': 'Objective',
      'kn': '',
    },
    'dskunc90': {
      'en': 'Owner',
      'kn': '',
    },
    '35y2bs88': {
      'en': 'Priority',
      'kn': '',
    },
    'q0iy8fzy': {
      'en': 'Due Date',
      'kn': '',
    },
    '97gbkqv1': {
      'en': 'Status',
      'kn': '',
    },
    'sxrgzq0d': {
      'en': 'Market Analysis Report',
      'kn': '',
    },
    'ii91fnf1': {
      'en': 'Q2 Planning',
      'kn': '',
    },
    'l5mse2n1': {
      'en': 'John Smith',
      'kn': '',
    },
    'vuh8zb75': {
      'en': 'Urgent',
      'kn': '',
    },
    'k042ms4j': {
      'en': 'Jun 30, 2023',
      'kn': '',
    },
    'sfafom0s': {
      'en': 'In Progress',
      'kn': '',
    },
    '59k93u73': {
      'en': 'Client Presentation',
      'kn': '',
    },
    '4dm7z7zj': {
      'en': 'Sales Pipeline',
      'kn': '',
    },
    'hnno9ibb': {
      'en': 'Sarah Lee',
      'kn': '',
    },
    'mpoxhoko': {
      'en': 'Important',
      'kn': '',
    },
    '3g68aivk': {
      'en': 'Jul 5, 2023',
      'kn': '',
    },
    'i5pbq61u': {
      'en': 'Delayed',
      'kn': '',
    },
    'mw0nyllu': {
      'en': 'Budget Review',
      'kn': '',
    },
    '2hswtmav': {
      'en': 'Financial Planning',
      'kn': '',
    },
    'tbynvzce': {
      'en': 'Mike Johnson',
      'kn': '',
    },
    'paw0iolr': {
      'en': 'Urgent',
      'kn': '',
    },
    '787mx0ue': {
      'en': 'Jul 10, 2023',
      'kn': '',
    },
    'ilanoxh5': {
      'en': 'Yet to Accept',
      'kn': '',
    },
    'ip42zoqb': {
      'en': 'Team Training',
      'kn': '',
    },
    '01cdkjys': {
      'en': 'HR Initiative',
      'kn': '',
    },
    'r4gfpn1w': {
      'en': 'Emily Brown',
      'kn': '',
    },
    'wgm4kqks': {
      'en': 'Important',
      'kn': '',
    },
    'ivubksaf': {
      'en': 'Jul 15, 2023',
      'kn': '',
    },
    '0vp3hylo': {
      'en': 'In Progress',
      'kn': '',
    },
    '8664spel': {
      'en': 'Recent Activity',
      'kn': '',
    },
    't23r2vrw': {
      'en': 'Market Analysis Report status updated to In Progress',
      'kn': '',
    },
    'baysths6': {
      'en': '2 hours ago by John Smith',
      'kn': '',
    },
    '70lxruof': {
      'en': 'New comment added on Client Presentation',
      'kn': '',
    },
    '1ptmyjqs': {
      'en': '4 hours ago by Sarah Lee',
      'kn': '',
    },
    'hf7qgpmc': {
      'en': 'Client Presentation marked as Delayed',
      'kn': '',
    },
    'a8znxc49': {
      'en': 'Yesterday by System',
      'kn': '',
    },
  },
  // TaskyyCopy3
  {
    '5va36wtq': {
      'en': 'Task Management',
      'kn': '',
    },
    '3fdp0j5b': {
      'en': 'My Tasks',
      'kn': '',
    },
    'luxdad0h': {
      'en': 'Task Management',
      'kn': '',
    },
    'ihkgkak7': {
      'en': 'Manage and track team tasks',
      'kn': '',
    },
    '4913gj8l': {
      'en': 'TextField',
      'kn': '',
    },
    '2x88qb6z': {
      'en': 'Sort by: ',
      'kn': '',
    },
    'am266wcx': {
      'en': 'Completed',
      'kn': '',
    },
    's7bu82gk': {
      'en': 'Pending',
      'kn': '',
    },
    'ueiind1d': {
      'en': 'Not Started',
      'kn': '',
    },
    'wpxczbmx': {
      'en': 'Task Name',
      'kn': '',
    },
    'okdkm6m8': {
      'en': 'Assigned By',
      'kn': '',
    },
    '73l80j5m': {
      'en': 'Assigned To',
      'kn': '',
    },
    'k5w1rrr3': {
      'en': 'Due Date',
      'kn': '',
    },
    '7lf0b3c5': {
      'en': 'Priority',
      'kn': '',
    },
    'dcqsb4ir': {
      'en': 'Status',
      'kn': '',
    },
    'ivchxtbk': {
      'en': 'Assigned Tasks',
      'kn': '',
    },
    'fs979t35': {
      'en': 'Task Management',
      'kn': '',
    },
    'lxh12vqv': {
      'en': 'Manage and track team tasks',
      'kn': '',
    },
    'pxu6uv4d': {
      'en': 'TextField',
      'kn': '',
    },
    '2c0o6ked': {
      'en': 'Sort by: ',
      'kn': '',
    },
    'lgr6vhax': {
      'en': 'Completed',
      'kn': '',
    },
    '9ixmwkzs': {
      'en': 'Pending',
      'kn': '',
    },
    'ly45499d': {
      'en': 'Not Started',
      'kn': '',
    },
    '34xojaih': {
      'en': 'Task Name',
      'kn': '',
    },
    'euz1xl45': {
      'en': 'Assigned To',
      'kn': '',
    },
    '9y3vy4dk': {
      'en': 'Due Date',
      'kn': '',
    },
    'nnex3q1s': {
      'en': 'Priority',
      'kn': '',
    },
    'jrthp0oz': {
      'en': 'Status',
      'kn': '',
    },
  },
  // MyTaskPage
  {
    'ppzqsj0t': {
      'en': 'Reviewable Task',
      'kn': '',
    },
    'lab6djcd': {
      'en': 'Comments',
      'kn': '',
    },
    '0agtnkgi': {
      'en': 'Add a comment...',
      'kn': '',
    },
    'kiwkoldy': {
      'en': 'Schedule Logs',
      'kn': '',
    },
    'v7b84e8n': {
      'en': 'Attachments',
      'kn': '',
    },
    '0radmx7o': {
      'en': 'Project_Brief.pdf',
      'kn': '',
    },
    'gjn282ur': {
      'en': 'Requirements.docx',
      'kn': '',
    },
    '87qatr3w': {
      'en': 'Accept',
      'kn': '',
    },
    'u4lbhn3r': {
      'en': 'Reject',
      'kn': '',
    },
    'wm946dzl': {
      'en': 'Reassign',
      'kn': '',
    },
    '4dhb11pt': {
      'en': 'Update Status',
      'kn': '',
    },
    'w3kw31f5': {
      'en': 'Schedule Task',
      'kn': '',
    },
    '0ttamwwq': {
      'en': 'Task Profile',
      'kn': '',
    },
  },
  // Mytask1
  {
    'smok0dym': {
      'en': 'Reviewable Task',
      'kn': '',
    },
    'j01rj2kf': {
      'en': 'Comments',
      'kn': '',
    },
    'w1xzstie': {
      'en': 'Attachment',
      'kn': '',
    },
    'bef41f1r': {
      'en': 'Type a comment or attach a document....',
      'kn': '',
    },
    'kip4sf0j': {
      'en': 'Schedule Logs',
      'kn': '',
    },
    'euo4u7tq': {
      'en': 'Schedule Task',
      'kn': '',
    },
    'z5yjy7im': {
      'en': 'Attachments',
      'kn': '',
    },
    'o5b33m9b': {
      'en': 'ATTACHMENT',
      'kn': '',
    },
    '3ienhirr': {
      'en': 'Accept',
      'kn': '',
    },
    'nu9eytaj': {
      'en': 'Reject',
      'kn': '',
    },
    'axdph7ia': {
      'en': 'Mark Complete',
      'kn': '',
    },
    'e3xyvb06': {
      'en': 'Submit for Review',
      'kn': '',
    },
    'q9un9fz4': {
      'en': 'Task Profile',
      'kn': '',
    },
  },
  // taskAssigneePage
  {
    'sucfrx55': {
      'en': 'Task Profile',
      'kn': '',
    },
    'lyaeecmy': {
      'en': 'Reviewable Task',
      'kn': '',
    },
    's24lf36b': {
      'en': 'Add Commnent',
      'kn': '',
    },
    'jw6470rp': {
      'en': 'Schedule Task',
      'kn': '',
    },
    'qk5sxgrg': {
      'en': 'Schedule Logs',
      'kn': '',
    },
    '6upxu5q7': {
      'en': 'Comments',
      'kn': '',
    },
    '7dh25lxs': {
      'en': 'Attachment',
      'kn': '',
    },
    'abqructj': {
      'en': 'Type a comment or attach a document....',
      'kn': '',
    },
    'gbgavexp': {
      'en': 'Schedule Logs',
      'kn': '',
    },
    'ytffv1jh': {
      'en': 'Schedule Task',
      'kn': '',
    },
    'srsf3kbq': {
      'en': 'Attachments',
      'kn': '',
    },
    'acun4qyw': {
      'en': 'ATTACHMENT',
      'kn': '',
    },
    '4pjxxgm0': {
      'en': 'Attachments',
      'kn': '',
    },
    '43s9ksas': {
      'en': 'ATTACHMENT',
      'kn': '',
    },
    'pl1dfo0h': {
      'en': 'Accept',
      'kn': '',
    },
    'vvellccq': {
      'en': 'Deffer',
      'kn': '',
    },
    'a6ulvfwz': {
      'en': 'Mark Complete',
      'kn': '',
    },
    '909n19of': {
      'en': 'Submit for Review',
      'kn': '',
    },
  },
  // taskRevierPage
  {
    'gi0be9l8': {
      'en': 'Task Profile',
      'kn': '',
    },
    'zxegox1u': {
      'en': 'Reviewable Task',
      'kn': '',
    },
    'ady0mysf': {
      'en': 'Add Commnent',
      'kn': '',
    },
    '3cz4l18g': {
      'en': 'Schedule Logs',
      'kn': '',
    },
    'wuedoh8x': {
      'en': 'Comments',
      'kn': '',
    },
    'n3e7fmnx': {
      'en': 'Attachment',
      'kn': '',
    },
    'nbabzydk': {
      'en': 'Type a comment or attach a document....',
      'kn': '',
    },
    '1qxn2mpe': {
      'en': 'Schedule Logs',
      'kn': '',
    },
    '26krnvm5': {
      'en': 'Attachments',
      'kn': '',
    },
    'kfcfb5fg': {
      'en': 'ATTACHMENT',
      'kn': '',
    },
    'nbg3p9vd': {
      'en': 'Attachments',
      'kn': '',
    },
    'zikgvulp': {
      'en': 'ATTACHMENT',
      'kn': '',
    },
    'ycu797w7': {
      'en': 'Approve',
      'kn': '',
    },
    'beq6ia0s': {
      'en': 'Redo',
      'kn': '',
    },
  },
  // JamBoard
  {
    '4cxtoz94': {
      'en': 'Jam Board',
      'kn': '',
    },
    'vov7t01d': {
      'en': 'Search Jams...',
      'kn': '',
    },
    'cpbaw4j7': {
      'en': 'Active Jams',
      'kn': '',
    },
    '22hmbex8': {
      'en': 'Meeting Notes',
      'kn': '',
    },
    'm571dpek': {
      'en': 'Discuss project timeline and deliverables...',
      'kn': '',
    },
    '2re9o0by': {
      'en': 'Voice Memo',
      'kn': '',
    },
    '3pbz5pv9': {
      'en': '2:34',
      'kn': '',
    },
    '5o9g1lun': {
      'en': 'Converted Jams',
      'kn': '',
    },
    '64o4gsdi': {
      'en': 'Whiteboard Sketch',
      'kn': '',
    },
    'pncweinz': {
      'en': 'Converted to Task #1234',
      'kn': '',
    },
    'k7rcx0ze': {
      'en': 'Completed Jams',
      'kn': '',
    },
    'r9ywjrms': {
      'en': 'UI Mockup',
      'kn': '',
    },
    'cgdgohmj': {
      'en': 'Completed on May 15',
      'kn': '',
    },
  },
  // JamBoard1
  {
    'fqwklt35': {
      'en': 'Create New Jam',
      'kn': '',
    },
    'taw25itc': {
      'en': 'Not Marked',
      'kn': '',
    },
    '5wehfuw2': {
      'en': 'Jam Board',
      'kn': '',
    },
  },
  // ScribbleProf
  {
    'v9wv56fv': {
      'en': 'Note',
      'kn': '',
    },
    'ustubfgu': {
      'en': 'Tag jam to Task: ',
      'kn': '',
    },
    '8i9afidp': {
      'en': 'Use Jam content: ',
      'kn': '',
    },
    'zco4re0n': {
      'en': 'Add Task',
      'kn': '',
    },
    'lvoix2kj': {
      'en': 'Jam',
      'kn': '',
    },
    'b2pjbqzn': {
      'en': 'Home',
      'kn': '',
    },
  },
  // Managerobjphone
  {
    'j087d184': {
      'en': 'Objectives',
      'kn': '',
    },
    'xh8vbquv': {
      'en': 'Objectives',
      'kn': '',
    },
    'hd122cqi': {
      'en': 'Private Objectives',
      'kn': '',
    },
    '64s8kfbm': {
      'en': 'Search objectives...',
      'kn': '',
    },
    '56gk0ky2': {
      'en': 'View Details',
      'kn': '',
    },
    'kzb92r5n': {
      'en': 'View Details',
      'kn': '',
    },
    '2hv2z1dd': {
      'en': 'Public Objectives',
      'kn': '',
    },
    'bhpp5dm5': {
      'en': 'Search objectives...',
      'kn': '',
    },
    'n85tx0bw': {
      'en': 'View Details',
      'kn': '',
    },
    'vtzt4vl8': {
      'en': 'View Details',
      'kn': '',
    },
  },
  // childobjphone
  {
    'p3b6rnev': {
      'en': 'Child Objectives',
      'kn': '',
    },
    'chum09nx': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    '6o3c07ik': {
      'en': 'Add Child Objective',
      'kn': '',
    },
    'iabs68kx': {
      'en': 'View Details',
      'kn': '',
    },
    '1bqzmd0j': {
      'en': 'Tasks',
      'kn': '',
    },
    '3jk0bucx': {
      'en': 'Due',
      'kn': '',
    },
    'wpv0rqsp': {
      'en': 'Due',
      'kn': '',
    },
    '6im7n45b': {
      'en': 'Organizational Objectives',
      'kn': '',
    },
  },
  // Objectivesphone
  {
    'lj8uzjrw': {
      'en': 'Search objectives...',
      'kn': '',
    },
    'ts92xbba': {
      'en': 'Progress: 65%',
      'kn': '',
    },
    'v3e158vn': {
      'en': 'View Details',
      'kn': '',
    },
    'm0iqlyi3': {
      'en': 'Progress: 65%',
      'kn': '',
    },
    'mtw2xt7t': {
      'en': 'View Details',
      'kn': '',
    },
    '4v9okolf': {
      'en': 'Organizational Objectives',
      'kn': '',
    },
  },
  // Managerobjphone2
  {
    'pikmyj34': {
      'en': 'Private Objectives',
      'kn': '',
    },
    '349wfk5p': {
      'en': 'Search objectives...',
      'kn': '',
    },
    'npr57f2e': {
      'en': 'View Details',
      'kn': '',
    },
    'acem05ql': {
      'en': 'View Details',
      'kn': '',
    },
    'y4t972cc': {
      'en': 'Public Objectives',
      'kn': '',
    },
    'fmhivb1p': {
      'en': 'Search objectives...',
      'kn': '',
    },
    '1svfo4ps': {
      'en': 'View Details',
      'kn': '',
    },
    'xq6scj2i': {
      'en': 'View Details',
      'kn': '',
    },
    '43u9b4e5': {
      'en': 'Objectives',
      'kn': '',
    },
  },
  // Taskyyphn
  {
    'oev61a0f': {
      'en': 'Task Management',
      'kn': '',
    },
    'wr5ttmmj': {
      'en': 'My Tasks',
      'kn': '',
    },
    '8k1fk0h1': {
      'en': 'Task Management',
      'kn': '',
    },
    'or1vbaiv': {
      'en': 'Manage and track team tasks',
      'kn': '',
    },
    '78i2nnns': {
      'en': 'Task Name',
      'kn': '',
    },
    's8tjwx03': {
      'en': 'Status',
      'kn': '',
    },
    'n9e9cmko': {
      'en': 'Assigned Tasks',
      'kn': '',
    },
    'qxgjg77u': {
      'en': 'Task Management',
      'kn': '',
    },
    '5wjifap7': {
      'en': 'Manage and track team tasks',
      'kn': '',
    },
    'exsaksb3': {
      'en': 'Task Name',
      'kn': '',
    },
    'dhff0dfw': {
      'en': 'Status',
      'kn': '',
    },
  },
  // taskAssigneephone
  {
    'iqt9orwc': {
      'en': 'Task Profile',
      'kn': '',
    },
    '13o3acdb': {
      'en': 'Reviewable Task',
      'kn': '',
    },
    '7tnig063': {
      'en': 'Add comment',
      'kn': '',
    },
    '9a4kc6me': {
      'en': 'Schedule Task',
      'kn': '',
    },
    'kn27kexi': {
      'en': 'Comments',
      'kn': '',
    },
    '06w2fjsp': {
      'en': 'Attachment',
      'kn': '',
    },
    '22lba9lc': {
      'en': 'Type a comment or attach a document....',
      'kn': '',
    },
    'd2f0x9aj': {
      'en': 'Schedule Logs',
      'kn': '',
    },
    'iykd09uh': {
      'en': 'Schedule Task',
      'kn': '',
    },
    'h84cs5bg': {
      'en': 'Attachments',
      'kn': '',
    },
    's8dkqpzf': {
      'en': 'ATTACHMENT',
      'kn': '',
    },
    'ibkzbpxh': {
      'en': 'Attachments',
      'kn': '',
    },
    'adim7aow': {
      'en': 'ATTACHMENT',
      'kn': '',
    },
  },
  // ChilObjCopy
  {
    '48xiu8fp': {
      'en': 'Progress Bar:',
      'kn': '',
    },
    'xyg3qru0': {
      'en': 'Child Objectives',
      'kn': '',
    },
    '4toxn90f': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    '6a6wlg8q': {
      'en': 'Add Child Objective',
      'kn': '',
    },
    'z8vpp9oz': {
      'en': 'Sub-Objectives',
      'kn': '',
    },
    'glysjjpt': {
      'en': 'Add Sub-Objective',
      'kn': '',
    },
    'suwzqv1k': {
      'en': 'View Details',
      'kn': '',
    },
    '570fn4cx': {
      'en': 'View Details',
      'kn': '',
    },
    'n0a8h6ur': {
      'en': 'Tasks',
      'kn': '',
    },
    'a2bj4q0i': {
      'en': 'Add task',
      'kn': '',
    },
    'a5dyh7me': {
      'en': 'Due',
      'kn': '',
    },
    'yj9m9dqt': {
      'en': 'Due',
      'kn': '',
    },
    '5pmb0eba': {
      'en': 'Add task',
      'kn': '',
    },
    'fea0s562': {
      'en': 'Due',
      'kn': '',
    },
    '2b3ix3bd': {
      'en': 'Due',
      'kn': '',
    },
    'zkxitjur': {
      'en': 'Objectives',
      'kn': '',
    },
  },
  // ManageUSersAdminPage
  {
    'nyn6gd02': {
      'en': 'Manage Members',
      'kn': '',
    },
    'ltfmjol1': {
      'en': 'Organization Members',
      'kn': '',
    },
    'et409mi0': {
      'en': 'View and manage team members across departments',
      'kn': '',
    },
    '3e5ehcmf': {
      'en': 'Active',
      'kn': '',
    },
    '4txmm4f4': {
      'en': 'Inactive',
      'kn': '',
    },
    'xwsirkds': {
      'en': 'Active',
      'kn': '',
    },
    '61q28jvb': {
      'en': 'Search by name, department or designation',
      'kn': '',
    },
    'o8x36ftb': {
      'en': 'Members List',
      'kn': '',
    },
    '07zqm4xy': {
      'en': 'View',
      'kn': '',
    },
    'auna7pwv': {
      'en': 'SJ',
      'kn': '',
    },
    '8u8e9rzb': {
      'en': 'Sarah Johnson',
      'kn': '',
    },
    'z0fso71u': {
      'en': 'Marketing • Team Lead',
      'kn': '',
    },
    'zr7oownc': {
      'en': 'Active',
      'kn': '',
    },
    'v4320wz6': {
      'en': 'View',
      'kn': '',
    },
    '858m7v7c': {
      'en': 'MB',
      'kn': '',
    },
    'u9o2et77': {
      'en': 'Mike Brown',
      'kn': '',
    },
    'a3c57xyw': {
      'en': 'Finance • Financial Analyst',
      'kn': '',
    },
    '3gmz9y8r': {
      'en': 'Inactive',
      'kn': '',
    },
    'rxfhtvx8': {
      'en': 'View',
      'kn': '',
    },
    'jszzyehw': {
      'en': 'EW',
      'kn': '',
    },
    '23tr2wra': {
      'en': 'Emma Wilson',
      'kn': '',
    },
    'et99u3sb': {
      'en': 'HR • HR Manager',
      'kn': '',
    },
    '7znghtb4': {
      'en': 'Active',
      'kn': '',
    },
    'y3zhgr6d': {
      'en': 'View',
      'kn': '',
    },
    'ry8w4kfe': {
      'en': 'RL',
      'kn': '',
    },
    '5z6u9nnf': {
      'en': 'Robert Lee',
      'kn': '',
    },
    'kole5mfa': {
      'en': 'Sales • Sales Representative',
      'kn': '',
    },
    'y1hwrlv0': {
      'en': 'Inactive',
      'kn': '',
    },
    '0669wtbw': {
      'en': 'View',
      'kn': '',
    },
    '90qboadj': {
      'en': 'View',
      'kn': '',
    },
    'yn81hmp3': {
      'en': 'SJ',
      'kn': '',
    },
    '1pdimcbb': {
      'en': 'Sarah Johnson',
      'kn': '',
    },
    'dwjzaudg': {
      'en': 'Marketing • Team Lead',
      'kn': '',
    },
    'yt92mfgr': {
      'en': 'Active',
      'kn': '',
    },
    'rfrlg30m': {
      'en': 'View',
      'kn': '',
    },
    'dv2af244': {
      'en': 'MB',
      'kn': '',
    },
    'rmd13q73': {
      'en': 'Mike Brown',
      'kn': '',
    },
    'orsliexv': {
      'en': 'Finance • Financial Analyst',
      'kn': '',
    },
    'b90kf7lu': {
      'en': 'Inactive',
      'kn': '',
    },
    '2st9rl0i': {
      'en': 'View',
      'kn': '',
    },
    'f9wxcaxa': {
      'en': 'EW',
      'kn': '',
    },
    '87d4lg02': {
      'en': 'Emma Wilson',
      'kn': '',
    },
    'x2a6hio3': {
      'en': 'HR • HR Manager',
      'kn': '',
    },
    'f3it6wrh': {
      'en': 'Active',
      'kn': '',
    },
    '40t1hc7s': {
      'en': 'View',
      'kn': '',
    },
    'zsopcg02': {
      'en': 'RL',
      'kn': '',
    },
    '3gz985va': {
      'en': 'Robert Lee',
      'kn': '',
    },
    'uyywvfjn': {
      'en': 'Sales • Sales Representative',
      'kn': '',
    },
    '2tjjwbm4': {
      'en': 'Inactive',
      'kn': '',
    },
    'f7uw30xr': {
      'en': 'View',
      'kn': '',
    },
  },
  // notiCopy
  {
    'mtibkw10': {
      'en': 'Notifications',
      'kn': '',
    },
  },
  // notificationPage
  {
    'vmxdyk2h': {
      'en': 'Notifications',
      'kn': '',
    },
    'ne9vb3tc': {
      'en': 'Today',
      'kn': '',
    },
    'oi81azoi': {
      'en': 'Mark all as read',
      'kn': '',
    },
    'dtti910s': {
      'en': 'Task Completed',
      'kn': '',
    },
    '7zsxgz85': {
      'en': 'Project X milestone achieved',
      'kn': '',
    },
    'fr1ks5gq': {
      'en': '10:30 AM',
      'kn': '',
    },
    't47z75bt': {
      'en': 'New Message',
      'kn': '',
    },
    'bur8urf4': {
      'en': 'John commented on your task',
      'kn': '',
    },
    '524vok25': {
      'en': '9:15 AM',
      'kn': '',
    },
    '223z6skz': {
      'en': 'Deadline Approaching',
      'kn': '',
    },
    '525h79l2': {
      'en': 'Task \'Quarterly Report\' due tomorrow',
      'kn': '',
    },
    'rwy2g1u0': {
      'en': '8:45 AM',
      'kn': '',
    },
    '0f54ibs3': {
      'en': 'Yesterday',
      'kn': '',
    },
    'raaee84x': {
      'en': 'New Team Member',
      'kn': '',
    },
    'epmm83h2': {
      'en': 'Sarah joined Marketing department',
      'kn': '',
    },
    'rrninjxn': {
      'en': '4:20 PM',
      'kn': '',
    },
    'ihfk3xha': {
      'en': 'Meeting Scheduled',
      'kn': '',
    },
    'oennxdrh': {
      'en': 'Weekly team sync at 10:00 AM',
      'kn': '',
    },
    '1s6u2cm0': {
      'en': '2:15 PM',
      'kn': '',
    },
    '31o31a06': {
      'en': 'Last Week',
      'kn': '',
    },
    '2eff5al7': {
      'en': 'Task Overdue',
      'kn': '',
    },
    'pgm1dwqp': {
      'en': 'Project Y documentation pending',
      'kn': '',
    },
    'k21aisap': {
      'en': 'Mon',
      'kn': '',
    },
    'dhzqltte': {
      'en': 'Performance Review',
      'kn': '',
    },
    'xx1mve5w': {
      'en': 'Your quarterly review is complete',
      'kn': '',
    },
    '93jqd0hj': {
      'en': 'Mon',
      'kn': '',
    },
  },
  // StaffDashboard
  {
    '8c0vwu8c': {
      'en': 'Dashboard',
      'kn': '',
    },
    '47nsnm9e': {
      'en': 'Objectives',
      'kn': '',
    },
    '4l6ue0l9': {
      'en': 'Task Management',
      'kn': '',
    },
    'e255veox': {
      'en': 'Notifications',
      'kn': '',
    },
    '24riaoxk': {
      'en': 'Logout',
      'kn': '',
    },
    'y3yj8zp9': {
      'en': 'Staff Dashboard',
      'kn': '',
    },
    'i1n8k3a3': {
      'en': 'Manager Dashboard',
      'kn': '',
    },
    'vbixd35i': {
      'en': 'Total Objectives',
      'kn': '',
    },
    'do0nm1td': {
      'en': 'Total Tasks ',
      'kn': '',
    },
    'rgmu1phf': {
      'en': 'Pending Tasks',
      'kn': '',
    },
    'uii0l5y2': {
      'en': 'Completed Tasks',
      'kn': '',
    },
    'fs71awcf': {
      'en': 'Sub-Objectives Overview',
      'kn': '',
    },
    '0edidxop': {
      'en': 'Name',
      'kn': '',
    },
    '0fxbqdd7': {
      'en': 'Manager',
      'kn': '',
    },
    'qasmvoyz': {
      'en': 'Progress',
      'kn': '',
    },
    'qhnx91uf': {
      'en': 'Deadline',
      'kn': '',
    },
    'n2lpef03': {
      'en': '2 days left',
      'kn': '',
    },
    'f5g6d5f2': {
      'en': 'Total Objectives',
      'kn': 'ಒಟ್ಟು ಉದ್ದೇಶಗಳು',
    },
    'qk6oc9oc': {
      'en': 'Total Tasks ',
      'kn': '',
    },
    '8drz8izu': {
      'en': 'Pending Tasks',
      'kn': '',
    },
    '8s5rihkr': {
      'en': 'Completed Tasks',
      'kn': '',
    },
    '5q4runds': {
      'en': 'NanoTrack',
      'kn': '',
    },
    '71cmg6im': {
      'en': 'Administrator',
      'kn': '',
    },
    '8g8ajg4t': {
      'en': 'Dashboard',
      'kn': '',
    },
    'nkwpvp58': {
      'en': 'Jam Board',
      'kn': '',
    },
    '2yltozsc': {
      'en': 'Objectives',
      'kn': '',
    },
    'la6c3g8z': {
      'en': 'Task Management',
      'kn': '',
    },
    'kw0kf3kp': {
      'en': 'Logout',
      'kn': '',
    },
    'usc22kxm': {
      'en': 'NanoDisha',
      'kn': '',
    },
  },
  // TaskyyCopy4
  {
    'tzzkd2w7': {
      'en': 'Task Management',
      'kn': '',
    },
    'hngy7d3z': {
      'en': 'My Tasks',
      'kn': '',
    },
    'jjf196v0': {
      'en': 'Yet to Accept',
      'kn': '',
    },
    '230rjqux': {
      'en': 'Filter by',
      'kn': '',
    },
    'pi6p4de6': {
      'en': 'Search...',
      'kn': '',
    },
    'cl1k01p0': {
      'en': 'Yet to Accept',
      'kn': '',
    },
    '6couwvkd': {
      'en': 'Deffered',
      'kn': '',
    },
    'a7pazyfr': {
      'en': 'Completed',
      'kn': '',
    },
    'u2cjqcdw': {
      'en': 'In progress',
      'kn': '',
    },
    '5r2o4tow': {
      'en': 'Recently Created',
      'kn': '',
    },
    'jp407iag': {
      'en': 'Sort by',
      'kn': '',
    },
    '2l0cm59h': {
      'en': 'Search...',
      'kn': '',
    },
    'd2pt5iiv': {
      'en': 'Due Date',
      'kn': '',
    },
    'euzxv5yt': {
      'en': 'Start Date',
      'kn': '',
    },
    'ys3snbg9': {
      'en': 'Recently Created',
      'kn': '',
    },
    'mf87nbos': {
      'en': 'Search task ',
      'kn': '',
    },
    'w4o2c0c3': {
      'en': 'Task Name',
      'kn': '',
    },
    'tedtrwi1': {
      'en': 'Assigned By',
      'kn': '',
    },
    'rj05jbfr': {
      'en': 'Due Date',
      'kn': '',
    },
    'kc9fhk1y': {
      'en': 'Priority',
      'kn': '',
    },
    'zjrg0dh6': {
      'en': 'Status',
      'kn': '',
    },
    'ygvr0ewu': {
      'en': 'Assigned Tasks',
      'kn': '',
    },
    'fsez5nz5': {
      'en': 'Task Management',
      'kn': '',
    },
    '1zkita4t': {
      'en': 'Manage and track team tasks',
      'kn': '',
    },
    '1rau3tkk': {
      'en': 'Search Tasks',
      'kn': '',
    },
    'ra4mwnb8': {
      'en': 'Task Name',
      'kn': '',
    },
    'tkr23nsz': {
      'en': 'Assigned To',
      'kn': '',
    },
    't8254pty': {
      'en': 'Due Date',
      'kn': '',
    },
    'qbdmhbxk': {
      'en': 'Priority',
      'kn': '',
    },
    't8aqp1gz': {
      'en': 'Status',
      'kn': '',
    },
  },
  // taskAssignorPageCopy
  {
    'mwpuyvhs': {
      'en': 'Reviewable Task',
      'kn': '',
    },
    'sw4bo814': {
      'en': 'Reviewable Task',
      'kn': '',
    },
    '4lrkxgzw': {
      'en': 'Attached Jam',
      'kn': '',
    },
    'nf2gt851': {
      'en': 'Comments',
      'kn': '',
    },
    '144tuo8w': {
      'en': 'Attachment',
      'kn': '',
    },
    'j2uvri5a': {
      'en': 'Type a comment or attach a document....',
      'kn': '',
    },
    'i39bsbik': {
      'en': 'Schedule Logs',
      'kn': '',
    },
    'cmi71ns2': {
      'en': 'Schedule Task',
      'kn': '',
    },
    'nldbvmc9': {
      'en': 'Comments',
      'kn': '',
    },
    'hjk2n3xg': {
      'en': 'Attachment',
      'kn': '',
    },
    'nybo9oc5': {
      'en': 'Type a comment or attach a document....',
      'kn': '',
    },
    'moeiiyyt': {
      'en': 'Schedule Logs',
      'kn': '',
    },
    '17i409bd': {
      'en': 'Schedule Task',
      'kn': '',
    },
    '3n870wu5': {
      'en': 'Attachments',
      'kn': '',
    },
    '5fjxfjxl': {
      'en': 'ATTACHMENT',
      'kn': '',
    },
    'on2kohlr': {
      'en': 'Accept',
      'kn': '',
    },
    'vdi6cfob': {
      'en': 'Deffer',
      'kn': '',
    },
    'su0ii6py': {
      'en': 'Mark Complete',
      'kn': '',
    },
    'rz5ozrrf': {
      'en': 'Submit for Review',
      'kn': '',
    },
    'w9krfw8h': {
      'en': 'Task Re-Assign',
      'kn': '',
    },
    'u3mn8pv3': {
      'en': 'Task Profile',
      'kn': '',
    },
  },
  // trail
  {
    '0j4ec4gl': {
      'en': 'Page Title',
      'kn': '',
    },
    'htzg19zl': {
      'en': 'Title',
      'kn': '',
    },
    '19ajzmaq': {
      'en': 'Subtitle',
      'kn': '',
    },
    '7a9lom2c': {
      'en': 'Select...',
      'kn': '',
    },
    'u47wb0cn': {
      'en': 'Search...',
      'kn': '',
    },
    'dxa6jsgd': {
      'en': 'Option 1',
      'kn': '',
    },
    'l1lba7x4': {
      'en': 'Option 2',
      'kn': '',
    },
    'bxqbj0zc': {
      'en': 'Option 3',
      'kn': '',
    },
    '5hl54aa2': {
      'en': 'Home',
      'kn': '',
    },
  },
  // taskPhoneView
  {
    '549eeldm': {
      'en': 'Task Manager',
      'kn': '',
    },
    'ic3od05o': {
      'en': 'My Tasks',
      'kn': '',
    },
    'pv4djdu0': {
      'en': 'Filter',
      'kn': '',
    },
    'fap8rv6b': {
      'en': 'Sort',
      'kn': '',
    },
    'hafu4n43': {
      'en': 'Task Name',
      'kn': '',
    },
    'pjtq37s8': {
      'en': 'Assigned By',
      'kn': '',
    },
    'd5kfl3ov': {
      'en': 'Due Date',
      'kn': '',
    },
    'dwd994i1': {
      'en': 'Priority',
      'kn': '',
    },
    'udvh433a': {
      'en': 'Status',
      'kn': '',
    },
    'gpi4m18x': {
      'en': 'Website Redesign',
      'kn': '',
    },
    'x4xtohgx': {
      'en': 'Sarah Johnson',
      'kn': '',
    },
    'j9ssb744': {
      'en': 'May 15, 2023',
      'kn': '',
    },
    'k8gppwt8': {
      'en': 'High',
      'kn': '',
    },
    'z9k8q2bn': {
      'en': 'Completed',
      'kn': '',
    },
    'tw1yfgvz': {
      'en': 'Content Creation',
      'kn': '',
    },
    '1m2gk19s': {
      'en': 'Michael Chen',
      'kn': '',
    },
    '3xg6x2js': {
      'en': 'May 20, 2023',
      'kn': '',
    },
    '6nmeetl1': {
      'en': 'Medium',
      'kn': '',
    },
    '5ckssx2a': {
      'en': 'In Progress',
      'kn': '',
    },
    '532eflrb': {
      'en': 'User Testing',
      'kn': '',
    },
    'ppqr6e30': {
      'en': 'Emily Rodriguez',
      'kn': '',
    },
    '4w3mqwu4': {
      'en': 'May 25, 2023',
      'kn': '',
    },
    'j3ua4xlc': {
      'en': 'Low',
      'kn': '',
    },
    'zxj7ikjs': {
      'en': 'Pending',
      'kn': '',
    },
    '925fim06': {
      'en': 'Database Migration',
      'kn': '',
    },
    'lcxevp7m': {
      'en': 'David Wilson',
      'kn': '',
    },
    '44dymhhk': {
      'en': 'June 1, 2023',
      'kn': '',
    },
    '9ezwfyv3': {
      'en': 'High',
      'kn': '',
    },
    'd1yyioal': {
      'en': 'In Progress',
      'kn': '',
    },
    'bovffehu': {
      'en': 'API Integration',
      'kn': '',
    },
    'wf81qrkc': {
      'en': 'Jessica Lee',
      'kn': '',
    },
    'x765b6i9': {
      'en': 'June 5, 2023',
      'kn': '',
    },
    'ltt905nq': {
      'en': 'Medium',
      'kn': '',
    },
    '1ahgv9ws': {
      'en': 'Completed',
      'kn': '',
    },
    'bsabg43g': {
      'en': 'Security Audit',
      'kn': '',
    },
    'gorgmm5y': {
      'en': 'Robert Taylor',
      'kn': '',
    },
    'y0i7rr27': {
      'en': 'June 10, 2023',
      'kn': '',
    },
    '1n7nlie0': {
      'en': 'High',
      'kn': '',
    },
    '08wvtg69': {
      'en': 'Pending',
      'kn': '',
    },
  },
  // addOBJ
  {
    'osd8sai8': {
      'en': 'Add Objective',
      'kn': '',
    },
    '3ng7pylm': {
      'en': 'Objective Title',
      'kn': '',
    },
    'kzu5dzvz': {
      'en': 'Description',
      'kn': '',
    },
    '79u0c10v': {
      'en': 'Select Start Date',
      'kn': '',
    },
    '301ep1gi': {
      'en': 'Select End Date',
      'kn': '',
    },
    '7n59k5g0': {
      'en': 'Type',
      'kn': '',
    },
    'ttklogxx': {
      'en': 'Private',
      'kn': '',
    },
    '2wmpf10k': {
      'en': 'Public',
      'kn': '',
    },
    '2fgeswwu': {
      'en': 'Private',
      'kn': '',
    },
    'x0jibsh6': {
      'en': 'Owner',
      'kn': '',
    },
    'jigql0a8': {
      'en': 'Search...',
      'kn': '',
    },
    '4s21vc93': {
      'en': 'Option 1',
      'kn': '',
    },
    'rrsony4f': {
      'en': 'Option 2',
      'kn': '',
    },
    'zhetidcg': {
      'en': 'Option 3',
      'kn': '',
    },
    '2xz2048x': {
      'en': 'Weightage',
      'kn': '',
    },
    'g1hppwoh': {
      'en': 'Enter the weightage',
      'kn': '',
    },
    'imm6kz4u': {
      'en': 'Create Objective',
      'kn': '',
    },
    '6l5msyta': {
      'en': 'Objective Title is required',
      'kn': '',
    },
    '6ycxr5h7': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'xxjbd78i': {
      'en': 'Description is required',
      'kn': '',
    },
    'f8zha1qx': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'etqe7tu4': {
      'en': 'Enter the weightage is required',
      'kn': '',
    },
    'm18gm8lv': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
  },
  // addSubOBJ
  {
    'badtg8e0': {
      'en': 'Add Child Objective',
      'kn': '',
    },
    'tjwpfrf8': {
      'en': 'Sub Objective Name',
      'kn': '',
    },
    's2sgy95z': {
      'en': 'Description',
      'kn': '',
    },
    'nji2qfzu': {
      'en': 'Owner',
      'kn': '',
    },
    'inuiz9z5': {
      'en': 'Search...',
      'kn': '',
    },
    '4rncswf5': {
      'en': 'Option 1',
      'kn': '',
    },
    '32bglzhv': {
      'en': 'Option 2',
      'kn': '',
    },
    'joz7d024': {
      'en': 'Option 3',
      'kn': '',
    },
    '4f4pujv2': {
      'en': 'Start Date',
      'kn': '',
    },
    'e8w2e3pk': {
      'en': 'Due Date',
      'kn': '',
    },
    'zueoip76': {
      'en': 'Create Objective',
      'kn': '',
    },
  },
  // createTask
  {
    '5zy4ohhn': {
      'en': 'Add Task',
      'kn': '',
    },
    't6yvwsv6': {
      'en': 'Task Title',
      'kn': '',
    },
    'hrqoqm08': {
      'en': 'Description',
      'kn': '',
    },
    'jpxtikqk': {
      'en': 'Assigned To',
      'kn': '',
    },
    '3ej0dq13': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    'zaer7hsq': {
      'en': 'Search...',
      'kn': '',
    },
    'pj8stpt9': {
      'en': 'Option 1',
      'kn': '',
    },
    'o4hylxos': {
      'en': 'Option 2',
      'kn': '',
    },
    'x5v1ox96': {
      'en': 'Option 3',
      'kn': '',
    },
    'ur3tseud': {
      'en': 'Priority',
      'kn': '',
    },
    'pkaq0wf3': {
      'en': 'Select the Priority of the task',
      'kn': '',
    },
    'pwmrsc7v': {
      'en': 'Search...',
      'kn': '',
    },
    '98mbxzig': {
      'en': 'High',
      'kn': '',
    },
    'ov8k3oz1': {
      'en': 'Medium',
      'kn': '',
    },
    'zs2bp90z': {
      'en': 'Low',
      'kn': '',
    },
    'auvxdtya': {
      'en': 'Attach Document',
      'kn': '',
    },
    'j1qc5mf2': {
      'en': 'Repetative Task',
      'kn': '',
    },
    'ccpawqvi': {
      'en': 'Start Time',
      'kn': '',
    },
    'qc1ir5ea': {
      'en': 'End Time',
      'kn': '',
    },
    'xul4lt01': {
      'en': 'Repeat Until',
      'kn': '',
    },
    'xeyclzs7': {
      'en': 'Set Schedule',
      'kn': '',
    },
    'sg83t9ap': {
      'en': 'Reviwed Task',
      'kn': '',
    },
    'lc7xiovl': {
      'en': 'Assign the reviewer',
      'kn': '',
    },
    'vdwzwh0m': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    '3netnybf': {
      'en': 'Search...',
      'kn': '',
    },
    '8qy0zbaz': {
      'en': 'Option 1',
      'kn': '',
    },
    '19yuzwks': {
      'en': 'Option 2',
      'kn': '',
    },
    'pi1991c4': {
      'en': 'Option 3',
      'kn': '',
    },
    'jt8mrfq0': {
      'en': 'Due Date',
      'kn': '',
    },
    'hf8k03gi': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // createTaskCopy
  {
    'k8ygmtxu': {
      'en': 'Add Task',
      'kn': '',
    },
    'pgjepmgo': {
      'en': 'Task Title',
      'kn': '',
    },
    'mbfhg2is': {
      'en': 'Description',
      'kn': '',
    },
    'isez6uwj': {
      'en': 'Assigned To',
      'kn': '',
    },
    '7p1fpsqu': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    '4aq663pr': {
      'en': 'Search...',
      'kn': '',
    },
    'rztz4ug8': {
      'en': 'Option 1',
      'kn': '',
    },
    '9jobz99m': {
      'en': 'Option 2',
      'kn': '',
    },
    'sib17ejq': {
      'en': 'Option 3',
      'kn': '',
    },
    'he7hvapv': {
      'en': 'Priority',
      'kn': '',
    },
    '5ly5897c': {
      'en': 'Select the Priority of the task',
      'kn': '',
    },
    'tgnp22yf': {
      'en': 'Search...',
      'kn': '',
    },
    'd4fzmltp': {
      'en': 'High',
      'kn': '',
    },
    'cu2g3who': {
      'en': 'Medium',
      'kn': '',
    },
    'i686x4kf': {
      'en': 'Low',
      'kn': '',
    },
    'rk21se3g': {
      'en': 'Attach Document',
      'kn': '',
    },
    'u04wj242': {
      'en': 'Repetative Task',
      'kn': '',
    },
    'y8nl6iwz': {
      'en': 'Due Date',
      'kn': '',
    },
    'z3sqtprs': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // addSubOBJCopy2
  {
    'ijknlqny': {
      'en': 'Add Sub Objective',
      'kn': '',
    },
    'wi8qw0qn': {
      'en': 'Sub Objective Name',
      'kn': '',
    },
    'x5yyoj43': {
      'en': 'Description',
      'kn': '',
    },
    'kwlc2b7g': {
      'en': 'Owner',
      'kn': '',
    },
    '20cl0268': {
      'en': 'Default',
      'kn': '',
    },
    'k1n2zurf': {
      'en': 'Default',
      'kn': '',
    },
    'q2d7za43': {
      'en': 'Search...',
      'kn': '',
    },
    '3dlmt674': {
      'en': 'Option 1',
      'kn': '',
    },
    '0w9ns28a': {
      'en': 'Option 2',
      'kn': '',
    },
    'sh85rxq3': {
      'en': 'Option 3',
      'kn': '',
    },
    'ch5xruj6': {
      'en': 'Start Date',
      'kn': '',
    },
    'grqo3r61': {
      'en': 'Due Date',
      'kn': '',
    },
    '8xps10cd': {
      'en': 'Create Objective',
      'kn': '',
    },
  },
  // addOBJowner
  {
    'r9wypkxj': {
      'en': 'Add Objective',
      'kn': '',
    },
    'wtqq20j5': {
      'en': 'Objective Name',
      'kn': '',
    },
    'yjm36fej': {
      'en': 'Description',
      'kn': '',
    },
    'm71fr3uy': {
      'en': 'Owner',
      'kn': '',
    },
    'xil2r4j9': {
      'en': 'Select...',
      'kn': '',
    },
    'la2lqosi': {
      'en': 'Search...',
      'kn': '',
    },
    '7bklao5x': {
      'en': 'Option 1',
      'kn': '',
    },
    '3yz5fy83': {
      'en': 'Option 2',
      'kn': '',
    },
    'ruofcqvr': {
      'en': 'Option 3',
      'kn': '',
    },
    '2pr0oem9': {
      'en': 'Start Date',
      'kn': '',
    },
    '46ksmqiv': {
      'en': 'Due Date',
      'kn': '',
    },
    'u6xc5s7q': {
      'en': 'Create Objective',
      'kn': '',
    },
  },
  // chat
  {
    '2j6sexwa': {
      'en': 'Team Chat',
      'kn': '',
    },
    'zwj1jfo5': {
      'en': 'Type a message...',
      'kn': '',
    },
  },
  // EditOBJ
  {
    'aks8l19h': {
      'en': 'Edit Objective',
      'kn': '',
    },
    'hlcqswqv': {
      'en': 'Title',
      'kn': '',
    },
    'e7me5box': {
      'en': 'Enter objective title',
      'kn': '',
    },
    '877w9jrs': {
      'en': 'Description',
      'kn': '',
    },
    '9wxmuok6': {
      'en': 'Enter objective description',
      'kn': '',
    },
    'i07lha49': {
      'en': 'Owner',
      'kn': '',
    },
    '3xm95x13': {
      'en': 'Default',
      'kn': '',
    },
    'gn3kf19r': {
      'en': 'Search...',
      'kn': '',
    },
    'vjlyvbh1': {
      'en': 'Option 1',
      'kn': '',
    },
    'o9pymzb5': {
      'en': 'Option 2',
      'kn': '',
    },
    '1uiwsbln': {
      'en': 'Option 3',
      'kn': '',
    },
    'lrivz0wb': {
      'en': 'Start Date',
      'kn': '',
    },
    '80dn0hgq': {
      'en': 'End Date',
      'kn': '',
    },
    'dome5npn': {
      'en': 'Type',
      'kn': '',
    },
    'iyrg7cgv': {
      'en': 'Public',
      'kn': '',
    },
    'wya6hws4': {
      'en': 'Private',
      'kn': '',
    },
    'apco58jy': {
      'en': 'Weightage',
      'kn': '',
    },
    'tqm4qxjd': {
      'en': 'Enter objective title',
      'kn': '',
    },
    '8ttmwr2c': {
      'en': 'Save Changes',
      'kn': '',
    },
  },
  // chatCopy
  {
    '4lqfjq71': {
      'en': 'Type a message...',
      'kn': '',
    },
  },
  // comment
  {
    'dsfhx76g': {
      'en': 'Add Comment',
      'kn': '',
    },
    'gdon78cv': {
      'en': 'Write something here',
      'kn': '',
    },
    'vuh8pbmk': {
      'en': 'Add comment',
      'kn': '',
    },
  },
  // TaskUpdate
  {
    'ne5pdpy3': {
      'en': 'Update Task Status',
      'kn': '',
    },
    'qbod09z1': {
      'en': 'Select the current status of your task',
      'kn': '',
    },
    'f332dg74': {
      'en': 'Not Started',
      'kn': '',
    },
    'fy44rlzj': {
      'en': 'In Progress',
      'kn': '',
    },
    'x76179g0': {
      'en': 'Completed',
      'kn': '',
    },
    '9nrv246m': {
      'en': 'Not Started',
      'kn': '',
    },
    'pt6yvm5x': {
      'en': 'In Progress',
      'kn': '',
    },
    'v1udyv84': {
      'en': 'Send for Review',
      'kn': '',
    },
    'fm19yp35': {
      'en': 'Update Status',
      'kn': '',
    },
  },
  // delete
  {
    'm5qanzdx': {
      'en': 'Delet Objective',
      'kn': '',
    },
    'zwfoa563': {
      'en': 'This action cannot be undone',
      'kn': '',
    },
    '1kxj9g21': {
      'en': 'Cancel',
      'kn': '',
    },
    'qd7tmz7o': {
      'en': 'Delete',
      'kn': '',
    },
  },
  // editEmployee
  {
    'rzreyn7w': {
      'en': 'Edit Employee',
      'kn': '',
    },
    '8wisxcmb': {
      'en': 'Full Name',
      'kn': '',
    },
    'cfjbyl7m': {
      'en': 'Enter employee\'s full name',
      'kn': '',
    },
    'xh66et27': {
      'en': 'Email Address',
      'kn': '',
    },
    '4hzue1bc': {
      'en': 'Enter work email address',
      'kn': '',
    },
    '9d1t14ig': {
      'en': 'Enter work email address',
      'kn': '',
    },
    'y4n5pvkj': {
      'en': 'Nano@2025',
      'kn': '',
    },
    '9fqm79fk': {
      'en': 'Enter work email address',
      'kn': '',
    },
    'qc4k6s5r': {
      'en': 'Nano@2025',
      'kn': '',
    },
    'zz2bo7po': {
      'en': 'Phone Number',
      'kn': '',
    },
    '0hxp0ozi': {
      'en': 'Enter contact number',
      'kn': '',
    },
    'f4astcst': {
      'en': 'Department',
      'kn': '',
    },
    'tleoatlx': {
      'en': 'Select Department',
      'kn': '',
    },
    'q1ig7mzp': {
      'en': 'Search...',
      'kn': '',
    },
    '8uqm5wh7': {
      'en': 'Engineer',
      'kn': '',
    },
    'lfuqrdwy': {
      'en': 'Sales',
      'kn': '',
    },
    'v1duh1kx': {
      'en': 'Data Entry',
      'kn': '',
    },
    '4gk1es0c': {
      'en': 'Designation',
      'kn': '',
    },
    'cs6bz4uf': {
      'en': 'Enter Designation',
      'kn': '',
    },
    'agi24tiz': {
      'en': 'Role',
      'kn': '',
    },
    '7r8rc86s': {
      'en': 'Select Role',
      'kn': '',
    },
    'k6z7o0ur': {
      'en': 'Search...',
      'kn': '',
    },
    'kyknag2e': {
      'en': 'Admin',
      'kn': '',
    },
    '17q9uvs3': {
      'en': 'Manager',
      'kn': '',
    },
    '10r05zyn': {
      'en': 'Employee',
      'kn': '',
    },
    'jdo57mo3': {
      'en': 'Activation Status',
      'kn': '',
    },
    'qnqhy4ke': {
      'en': 'Cancel',
      'kn': '',
    },
    'ajp2u49v': {
      'en': 'Save Changes\n',
      'kn': '',
    },
  },
  // editTask
  {
    'igjhis7h': {
      'en': 'Edit Task',
      'kn': '',
    },
    'maycpg3z': {
      'en': 'Task Title',
      'kn': '',
    },
    '5s2x2c0u': {
      'en': 'Description',
      'kn': '',
    },
    'jt9lgy90': {
      'en': 'Assigned To',
      'kn': '',
    },
    'ul3va90s': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    '212mtf1u': {
      'en': 'Search...',
      'kn': '',
    },
    '3k3htwzl': {
      'en': 'Option 1',
      'kn': '',
    },
    'atsbofc3': {
      'en': 'Option 2',
      'kn': '',
    },
    '48d5ofsb': {
      'en': 'Option 3',
      'kn': '',
    },
    'u7edknp6': {
      'en': 'Priority',
      'kn': '',
    },
    'zwv0erw2': {
      'en': 'Select the Priority of the task',
      'kn': '',
    },
    'hojf7qcj': {
      'en': 'Search...',
      'kn': '',
    },
    'egip03wj': {
      'en': 'High',
      'kn': '',
    },
    't188ndcu': {
      'en': 'Medium',
      'kn': '',
    },
    '00ov3t42': {
      'en': 'Low',
      'kn': '',
    },
    'p7xf4di1': {
      'en': 'Due Date',
      'kn': '',
    },
    '5p8xqj78': {
      'en': 'Edit Task',
      'kn': '',
    },
  },
  // chatCopyCopy
  {
    '5lrebrv5': {
      'en': 'Type a message...',
      'kn': '',
    },
  },
  // chatCopyCopyCopy
  {
    'fpke1lsi': {
      'en': 'Type a message...',
      'kn': '',
    },
  },
  // objchat
  {
    'tmr3o47a': {
      'en': 'Type a message...',
      'kn': '',
    },
  },
  // taskchat
  {
    'axp95j9f': {
      'en': 'Type a message...',
      'kn': '',
    },
  },
  // addChildObj
  {
    '1vc04gv8': {
      'en': 'Add Child Objective',
      'kn': '',
    },
    'lktii8m9': {
      'en': 'Sub Objective Name',
      'kn': '',
    },
    '5c7ed2xl': {
      'en': 'Description',
      'kn': '',
    },
    'r1ajzniw': {
      'en': 'Select Start Date',
      'kn': '',
    },
    '5ap41dgq': {
      'en': 'Select End Date',
      'kn': '',
    },
    'bm5bn72z': {
      'en': 'Owner',
      'kn': '',
    },
    'kz0hg2lj': {
      'en': 'Default',
      'kn': '',
    },
    'a5al8vmu': {
      'en': 'Search...',
      'kn': '',
    },
    'xgc8937p': {
      'en': 'Option 1',
      'kn': '',
    },
    '5v7ntd5y': {
      'en': 'Option 2',
      'kn': '',
    },
    'oug5c6dx': {
      'en': 'Option 3',
      'kn': '',
    },
    'qija6bf2': {
      'en': 'Type',
      'kn': '',
    },
    'j6m1c0a3': {
      'en': 'Private',
      'kn': '',
    },
    'o8bt41eg': {
      'en': 'Public',
      'kn': '',
    },
    'sq5aonct': {
      'en': 'Private',
      'kn': '',
    },
    'fcicebw8': {
      'en': 'Weightage',
      'kn': '',
    },
    'snm52inw': {
      'en': 'Enter the weightage',
      'kn': '',
    },
    'lg7avc8z': {
      'en': 'Create Objective',
      'kn': '',
    },
    'ei1lgyqf': {
      'en': 'Sub Obj fiels is required',
      'kn': '',
    },
    '32cmmlim': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'gwk0zcii': {
      'en': 'Field is required',
      'kn': '',
    },
    '7ocbpvkv': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'oiiiv8ta': {
      'en': 'Enter the weightage is required',
      'kn': '',
    },
    '4qnpfvfn': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
  },
  // createTaskCopyCopy
  {
    'uvkxnym2': {
      'en': 'Add Task',
      'kn': '',
    },
    'qn95123u': {
      'en': 'Task Title',
      'kn': '',
    },
    'caesvzun': {
      'en': 'Description',
      'kn': '',
    },
    'yd5gp2uj': {
      'en': 'Assigning To',
      'kn': '',
    },
    'rhd28oi9': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    '0kgkpyns': {
      'en': 'Search...',
      'kn': '',
    },
    'yy9u3hyz': {
      'en': 'Option 1',
      'kn': '',
    },
    'ph11kxr5': {
      'en': 'Option 2',
      'kn': '',
    },
    'bv3oyj0i': {
      'en': 'Option 3',
      'kn': '',
    },
    'j7i4g0kr': {
      'en': 'Priority',
      'kn': '',
    },
    'qrveeod1': {
      'en': 'Select the Priority of the task',
      'kn': '',
    },
    'd8jpbg8n': {
      'en': 'Search...',
      'kn': '',
    },
    'q0z9asfy': {
      'en': 'High',
      'kn': '',
    },
    'fnq0319g': {
      'en': 'Medium',
      'kn': '',
    },
    '1ikjb6xw': {
      'en': 'Low',
      'kn': '',
    },
    'my7b41xm': {
      'en': 'Attach Document',
      'kn': '',
    },
    'ld92cusv': {
      'en': 'Repetative Task',
      'kn': '',
    },
    'k6duvdql': {
      'en': 'Reviewable Task',
      'kn': '',
    },
    'w1fbvdv5': {
      'en': 'Assigning To',
      'kn': '',
    },
    't3p1ijbf': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    'af6lfjc4': {
      'en': 'Search...',
      'kn': '',
    },
    '0b0cpoed': {
      'en': 'Option 1',
      'kn': '',
    },
    'gwdtt8zd': {
      'en': 'Option 2',
      'kn': '',
    },
    '1lw40wy7': {
      'en': 'Option 3',
      'kn': '',
    },
    'dmnm5tf5': {
      'en': 'Due Date',
      'kn': '',
    },
    '5854p93d': {
      'en': 'Reassign Task',
      'kn': '',
    },
  },
  // deleteCopy
  {
    '9o0hsetf': {
      'en': 'Disable user',
      'kn': '',
    },
    'b4jr7l6j': {
      'en': 'This action cannot be undone',
      'kn': '',
    },
    '19daf82h': {
      'en': 'Cancel',
      'kn': '',
    },
    '0ldpmzjy': {
      'en': 'Disable',
      'kn': '',
    },
  },
  // createTaskNew
  {
    '8og87v8s': {
      'en': 'Add Task',
      'kn': '',
    },
    'r2m2sf68': {
      'en': 'Task Title',
      'kn': '',
    },
    'g9sr41et': {
      'en': 'Description',
      'kn': '',
    },
    'n5tfq1cr': {
      'en': 'Select Due Date',
      'kn': '',
    },
    'ryofeuzv': {
      'en': 'Attach Document',
      'kn': '',
    },
    'o0qj6kfa': {
      'en': 'Assigned To :',
      'kn': '',
    },
    '0wea0rlu': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    'rudkhr2v': {
      'en': 'Search...',
      'kn': '',
    },
    'tpp5p6o0': {
      'en': 'Option 1',
      'kn': '',
    },
    'ivxfuxr7': {
      'en': 'Option 2',
      'kn': '',
    },
    '5bv6fu4q': {
      'en': 'Option 3',
      'kn': '',
    },
    'nc0z64tb': {
      'en': 'Reviewable :',
      'kn': '',
    },
    'xb601lfw': {
      'en': 'Reviewer',
      'kn': '',
    },
    'y73fbf0w': {
      'en': 'Search...',
      'kn': '',
    },
    'bam1itmz': {
      'en': 'Option 1',
      'kn': '',
    },
    'nad0t725': {
      'en': 'Option 2',
      'kn': '',
    },
    '7kw1qyku': {
      'en': 'Option 3',
      'kn': '',
    },
    'ho083xn3': {
      'en': 'Priority :',
      'kn': '',
    },
    '9cq00xub': {
      'en': 'Immediate',
      'kn': '',
    },
    '3puv8bx8': {
      'en': 'Urgent',
      'kn': '',
    },
    'bw4we1zd': {
      'en': 'Important',
      'kn': '',
    },
    'imoeb9iz': {
      'en': 'Immediate',
      'kn': '',
    },
    '5lr9kfd1': {
      'en': 'Repetative',
      'kn': '',
    },
    '6hey73be': {
      'en': 'Field is required',
      'kn': '',
    },
    'uryhpfjf': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'c87b2rv3': {
      'en': 'Field is required',
      'kn': '',
    },
    'jmw2nkvu': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'qtx7b12t': {
      'en': 'Select End Rep Date',
      'kn': '',
    },
    'jfq4lm9f': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // commentssstask
  {
    '88ob2z90': {
      'en': 'Comments',
      'kn': '',
    },
    '2qb10r1e': {
      'en': 'James Wilson',
      'kn': '',
    },
    '2kbpnuyy': {
      'en': '5 hours ago',
      'kn': '',
    },
    '4ws86q6o': {
      'en':
          'Great tips on meal prep! I\'ve been looking for ways to streamline my weekly cooking routine.',
      'kn': '',
    },
    '77uutaf1': {
      'en': 'Emma Thompson',
      'kn': '',
    },
    'xy6155jm': {
      'en': '1 day ago',
      'kn': '',
    },
    'eajdnviy': {
      'en':
          'The video tutorial was super helpful! I appreciate how you broke down each step clearly.',
      'kn': '',
    },
    '11l6x425': {
      'en': 'Type your message...',
      'kn': '',
    },
  },
  // com
  {
    '2eatcjud': {
      'en': 'Hey there! Just sent you the project files.',
      'kn': '',
    },
    'nmwmuu4x': {
      'en': 'Perfect, I\'ll take a look at them now.',
      'kn': '',
    },
    '3ev37avk': {
      'en': 'Project_presentation.pdf',
      'kn': '',
    },
    'l3sexeui': {
      'en': 'Team meeting screenshot',
      'kn': '',
    },
    '30eh6dmy': {
      'en': 'Type your message...',
      'kn': '',
    },
  },
  // repetativetask
  {
    'm7vhi9gk': {
      'en': 'Schedule Task',
      'kn': '',
    },
    'ekywmbcs': {
      'en': 'Set up recurring schedule',
      'kn': '',
    },
    'wbj1p62s': {
      'en': 'Daily',
      'kn': '',
    },
    'h3trdjx1': {
      'en': 'Weekly',
      'kn': '',
    },
    '79gd5tcq': {
      'en': 'Monthly',
      'kn': '',
    },
    'z4j1szzd': {
      'en': 'Custom',
      'kn': '',
    },
    'ggjzn5f7': {
      'en': 'Start Time',
      'kn': '',
    },
    '83kst07m': {
      'en': 'End Time',
      'kn': '',
    },
    'k397n5yp': {
      'en': 'Repeat Until',
      'kn': '',
    },
    '0lint5ms': {
      'en': 'Set Schedule',
      'kn': '',
    },
  },
  // assigntrask
  {
    'kmyqrki6': {
      'en': 'Assign Task',
      'kn': '',
    },
    '6w06ads0': {
      'en': 'Task Title',
      'kn': '',
    },
    'ug4dfu1e': {
      'en': 'Description',
      'kn': '',
    },
    'kyf6uwbu': {
      'en': 'Assigned To',
      'kn': '',
    },
    '319v16fp': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    'ny4wkofl': {
      'en': 'Search...',
      'kn': '',
    },
    '0cpux4m9': {
      'en': 'Option 1',
      'kn': '',
    },
    '3nt0mck3': {
      'en': 'Option 2',
      'kn': '',
    },
    '8seroqzm': {
      'en': 'Option 3',
      'kn': '',
    },
    't2n79glc': {
      'en': 'Priority',
      'kn': '',
    },
    '8i0lvvh9': {
      'en': 'Select the Priority of the task',
      'kn': '',
    },
    'x1ww22nz': {
      'en': 'Search...',
      'kn': '',
    },
    'bt86uhx4': {
      'en': 'High',
      'kn': '',
    },
    'ypabiov4': {
      'en': 'Medium',
      'kn': '',
    },
    'jit0ksj7': {
      'en': 'Low',
      'kn': '',
    },
    'w1saxxw3': {
      'en': 'Attach Document',
      'kn': '',
    },
    '7l1plhal': {
      'en': 'Repetative Task',
      'kn': '',
    },
    'shp0bjji': {
      'en': 'Due Date',
      'kn': '',
    },
    '8f9norkz': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // rasksel
  {
    'hh82drao': {
      'en': 'Task Type',
      'kn': '',
    },
    'isl4sdtu': {
      'en': 'Repetitive Task',
      'kn': '',
    },
    'x12zfz1e': {
      'en': 'Normal Task',
      'kn': '',
    },
  },
  // tasksel
  {
    'x9v4oopf': {
      'en': 'Task Type',
      'kn': '',
    },
    'butyosow': {
      'en': 'Choose the type of task you want to create',
      'kn': '',
    },
    'hykk7nzb': {
      'en': 'Repetitive Task',
      'kn': '',
    },
    '3vmvko39': {
      'en': 'Occurs regularly',
      'kn': '',
    },
    'tejsu9em': {
      'en': 'Normal Task',
      'kn': '',
    },
    'p1t6mhl2': {
      'en': 'One-time task',
      'kn': '',
    },
  },
  // comp
  {
    't6oucl5a': {
      'en': 'TextField',
      'kn': '',
    },
  },
  // total
  {
    'w0kojsu0': {
      'en': 'TextField',
      'kn': '',
    },
  },
  // addChildObjCopy
  {
    'r4pixdov': {
      'en': 'Add Child Objective',
      'kn': '',
    },
    'd73eghtc': {
      'en': 'Sub Objective Name',
      'kn': '',
    },
    '8vq92i65': {
      'en': 'Description',
      'kn': '',
    },
    'dyp9z0o4': {
      'en': 'Owner',
      'kn': '',
    },
    '5n8c6md0': {
      'en': 'Default',
      'kn': '',
    },
    'fwtan169': {
      'en': 'Search...',
      'kn': '',
    },
    'jkt55fjs': {
      'en': 'Option 1',
      'kn': '',
    },
    'vly8x0qk': {
      'en': 'Option 2',
      'kn': '',
    },
    'x41eq7k3': {
      'en': 'Option 3',
      'kn': '',
    },
    'q6k15map': {
      'en': 'Start Date',
      'kn': '',
    },
    '0k7nd8yq': {
      'en': 'Due Date',
      'kn': '',
    },
    '19w4oqtk': {
      'en': 'Create Objective',
      'kn': '',
    },
  },
  // gogleint
  {
    '8h1ktme0': {
      'en': 'Add Task',
      'kn': '',
    },
    'cih3xzb3': {
      'en': 'Task Title',
      'kn': '',
    },
    'eubah9hb': {
      'en': 'Description',
      'kn': '',
    },
    'qd1b28nd': {
      'en': 'Due Date',
      'kn': '',
    },
    '6dx6iiyp': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // EditEmp
  {
    '21bqkrsc': {
      'en': 'Edit Employee',
      'kn': '',
    },
    'kpohay7y': {
      'en': 'Cancel',
      'kn': '',
    },
    '5zxgeku4': {
      'en': 'Full Name',
      'kn': '',
    },
    'ywl460ij': {
      'en': 'Name',
      'kn': '',
    },
    'r1t9yt8h': {
      'en': 'Staff Number',
      'kn': '',
    },
    'a30frc7u': {
      'en': 'Department',
      'kn': '',
    },
    'xxv0jqvf': {
      'en': 'Select Department...',
      'kn': '',
    },
    '00e3509t': {
      'en': 'Search...',
      'kn': '',
    },
    '5ajgmcz0': {
      'en': 'Option 1',
      'kn': '',
    },
    'db2606my': {
      'en': 'Option 2',
      'kn': '',
    },
    '9wimz09u': {
      'en': 'Option 3',
      'kn': '',
    },
    'h4w4a5tr': {
      'en': 'Position',
      'kn': '',
    },
    '6dj57s11': {
      'en': 'Select Position...',
      'kn': '',
    },
    'kxgf7ffl': {
      'en': 'Search...',
      'kn': '',
    },
    's7re182g': {
      'en': 'Staff',
      'kn': '',
    },
    'nrx0hrl8': {
      'en': 'Manager',
      'kn': '',
    },
    '320kb160': {
      'en': 'HR',
      'kn': '',
    },
    'cur3n4qg': {
      'en': 'Admin',
      'kn': '',
    },
    '96fiwbbe': {
      'en': 'Phone Number',
      'kn': '',
    },
    'ri8ptzwk': {
      'en': 'Phone Number',
      'kn': '',
    },
    'gy3ow0jl': {
      'en': 'Email ID',
      'kn': '',
    },
    '7tgm5plp': {
      'en': 'TextField',
      'kn': '',
    },
    'sbnd892h': {
      'en': 'Nano@2025',
      'kn': '',
    },
    'e79tmu1y': {
      'en': 'TextField',
      'kn': '',
    },
    'gznpr6g4': {
      'en': 'Nano@2025',
      'kn': '',
    },
    '2hewjw1g': {
      'en': 'Activation Status',
      'kn': '',
    },
    'z0bxqops': {
      'en': 'Employee can review tasks',
      'kn': '',
    },
    'pgtlce9k': {
      'en': 'Name is required',
      'kn': '',
    },
    'fucgrne2': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'nnbalufk': {
      'en': 'Field is required',
      'kn': '',
    },
    '3dliykcf': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'cn0lfz4u': {
      'en': 'Field is required',
      'kn': '',
    },
    '5rbvs1w8': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'knmmfalw': {
      'en': 'Field is required',
      'kn': '',
    },
    'j2j94a4o': {
      'en': 'Email is required',
      'kn': '',
    },
    'xlxrz8r5': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'ggs6160g': {
      'en': 'Nano@2025 is required',
      'kn': '',
    },
    'nydpmznm': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'd4pen3nn': {
      'en': 'Nano@2025 is required',
      'kn': '',
    },
    'inj8qmk8': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'i7vuf5tc': {
      'en': 'Update Employee',
      'kn': '',
    },
  },
  // createTaskNewCopy
  {
    '6mszt2m5': {
      'en': 'Add Task',
      'kn': '',
    },
    '9xcmwb5u': {
      'en': 'Task Title',
      'kn': '',
    },
    'irx5wwrh': {
      'en': 'Description',
      'kn': '',
    },
    'dtsf79ah': {
      'en': 'Assigned To',
      'kn': '',
    },
    'slgwdqrt': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    '37s74wz4': {
      'en': 'Search...',
      'kn': '',
    },
    'm34krwgq': {
      'en': 'Option 1',
      'kn': '',
    },
    'mjb4pmc7': {
      'en': 'Option 2',
      'kn': '',
    },
    'dze9mfbz': {
      'en': 'Option 3',
      'kn': '',
    },
    's99wobdg': {
      'en': 'Priority',
      'kn': '',
    },
    'f3c7trbt': {
      'en': 'Select the Priority of the task',
      'kn': '',
    },
    '31q32u2s': {
      'en': 'Search...',
      'kn': '',
    },
    'ove2rxg3': {
      'en': 'Urgent',
      'kn': '',
    },
    'moq35hip': {
      'en': 'Important',
      'kn': '',
    },
    'lbutnrz8': {
      'en': 'Not important',
      'kn': '',
    },
    'kwj5mt1c': {
      'en': 'Attach Document',
      'kn': '',
    },
    'xwfbj0vj': {
      'en': 'Reviewable',
      'kn': '',
    },
    'jetpopyg': {
      'en': 'Reviewer',
      'kn': '',
    },
    'il3qt0xs': {
      'en': 'Search...',
      'kn': '',
    },
    'mdkqgfkq': {
      'en': 'Option 1',
      'kn': '',
    },
    'g0ipi6s0': {
      'en': 'Option 2',
      'kn': '',
    },
    'j0xhcs5z': {
      'en': 'Option 3',
      'kn': '',
    },
    '7ep8qw53': {
      'en': 'Repetative',
      'kn': '',
    },
    'wln8nux0': {
      'en': 'Daily',
      'kn': '',
    },
    'iqv5285g': {
      'en': 'Weekly',
      'kn': '',
    },
    '3tprj851': {
      'en': 'Monthly',
      'kn': '',
    },
    '8ov1po1i': {
      'en': 'Half Yearly',
      'kn': '',
    },
    'vssxobag': {
      'en': 'Due Date',
      'kn': '',
    },
    '1spek05p': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // AddObjectiveManager
  {
    '6upzw0ai': {
      'en': 'Add New Objective',
      'kn': '',
    },
    'wrga374q': {
      'en': 'Objective Name',
      'kn': '',
    },
    '0a47cmqz': {
      'en': '*',
      'kn': '',
    },
    'sppec51d': {
      'en': 'Enter objective name (max 100 characters)',
      'kn': '',
    },
    'qb30ld75': {
      'en': 'Description',
      'kn': '',
    },
    'do7jv0kl': {
      'en': 'Describe your objective (max 250 words)',
      'kn': '',
    },
    'ba1kz8dj': {
      'en': 'Start Date',
      'kn': '',
    },
    'mku5jacd': {
      'en': '*',
      'kn': '',
    },
    'xcja48ao': {
      'en': 'Select Start Date',
      'kn': '',
    },
    'dpqua3ha': {
      'en': 'End Date',
      'kn': '',
    },
    'sduqdy1d': {
      'en': '*',
      'kn': '',
    },
    '94847rqe': {
      'en': 'Select End Date',
      'kn': '',
    },
    'oi78im51': {
      'en': 'Owner',
      'kn': '',
    },
    'pa3gvrdq': {
      'en': '*',
      'kn': '',
    },
    '4fsrho8v': {
      'en': 'Default',
      'kn': '',
    },
    'dzcgk1zv': {
      'en': 'Default',
      'kn': '',
    },
    '1x4b74o9': {
      'en': 'Search...',
      'kn': '',
    },
    'cun8maj3': {
      'en': 'Option 1',
      'kn': '',
    },
    'iksf7ave': {
      'en': 'Option 2',
      'kn': '',
    },
    'wwtab6fm': {
      'en': 'Option 3',
      'kn': '',
    },
    'vz5pybdq': {
      'en': 'Objective Type:',
      'kn': '',
    },
    'gbt8ewv9': {
      'en': 'Private',
      'kn': '',
    },
    '7dsuep7b': {
      'en': 'Public',
      'kn': '',
    },
    'b0fqr5yr': {
      'en': 'Weightage',
      'kn': '',
    },
    'okjj9n00': {
      'en': '*',
      'kn': '',
    },
    '76rmjf8g': {
      'en': 'Enter weightage (1-100)',
      'kn': '',
    },
    'b46keve7': {
      'en': 'Cancel',
      'kn': '',
    },
    'qi45ozz1': {
      'en': 'Add Objective',
      'kn': '',
    },
  },
  // AddObjectiveManagerCopy
  {
    'mxg749gk': {
      'en': 'Add New Objective',
      'kn': '',
    },
    'xcw2dksp': {
      'en': 'Basic Information',
      'kn': '',
    },
    'y0sp7zr3': {
      'en': 'Objective Name',
      'kn': '',
    },
    'iyqzwz7i': {
      'en': '*',
      'kn': '',
    },
    'vriejyox': {
      'en': 'Enter objective name (max 100 characters)',
      'kn': '',
    },
    '5stb0gmn': {
      'en': 'Description',
      'kn': '',
    },
    'q0w0fee2': {
      'en': 'Describe your objective (max 250 words)',
      'kn': '',
    },
    '8pxv0wqg': {
      'en': 'Timeline & Ownership',
      'kn': '',
    },
    'fngq0pph': {
      'en': 'Start Date',
      'kn': '',
    },
    'yo1q9qcr': {
      'en': '*',
      'kn': '',
    },
    '0q9qkoz6': {
      'en': 'Select Start Date',
      'kn': '',
    },
    '7pq4n2he': {
      'en': 'End Date',
      'kn': '',
    },
    'ay4nli9m': {
      'en': '*',
      'kn': '',
    },
    'u4sye3wi': {
      'en': 'Select End Date',
      'kn': '',
    },
    'asu4sewh': {
      'en': 'Parent Objective',
      'kn': '',
    },
    'za4xjijc': {
      'en': 'Select Parent Objective',
      'kn': '',
    },
    'l3bfz4ey': {
      'en': 'Owner',
      'kn': '',
    },
    'mvxwages': {
      'en': '*',
      'kn': '',
    },
    '45y7rona': {
      'en': 'Select Owner',
      'kn': '',
    },
    'xt3vwz79': {
      'en': 'Settings & Metrics',
      'kn': '',
    },
    '974sns0f': {
      'en': 'Privacy Setting',
      'kn': '',
    },
    'ooevj5px': {
      'en': 'Private',
      'kn': '',
    },
    'twnkycw2': {
      'en': 'Public',
      'kn': '',
    },
    '7xzfafoi': {
      'en': 'Status',
      'kn': '',
    },
    '4js2qpou': {
      'en': 'Green',
      'kn': '',
    },
    '0tm4h2ae': {
      'en': 'Yellow',
      'kn': '',
    },
    '0gmtxox5': {
      'en': 'Red',
      'kn': '',
    },
    '48btnzwg': {
      'en': 'Weightage',
      'kn': '',
    },
    'cx41z93w': {
      'en': '*',
      'kn': '',
    },
    'ahxh75ex': {
      'en': 'Enter weightage (1-100)',
      'kn': '',
    },
    'mwfwsxz5': {
      'en': 'Cancel',
      'kn': '',
    },
    't9vvhtgl': {
      'en': 'Add Objective',
      'kn': '',
    },
  },
  // changepass
  {
    '93mpk6xx': {
      'en': 'Change Password',
      'kn': '',
    },
    'ggqbzpc8': {
      'en': 'Current Password',
      'kn': '',
    },
    '439lw3h6': {
      'en': 'New Password',
      'kn': '',
    },
    'tdlhhz86': {
      'en': 'Confirm New Password',
      'kn': '',
    },
    '5p8j3pt0': {
      'en': 'Update Password',
      'kn': '',
    },
  },
  // EditObjective
  {
    '98ji7292': {
      'en': 'Edit New Objective',
      'kn': '',
    },
    '2ku9wcng': {
      'en': 'Objective Name',
      'kn': '',
    },
    'd8g3ivvh': {
      'en': '*',
      'kn': '',
    },
    '9a7nlule': {
      'en': 'Enter objective name (max 100 characters)',
      'kn': '',
    },
    'gcwr1h3z': {
      'en': 'Description',
      'kn': '',
    },
    'a35h7wwi': {
      'en': 'Describe your objective (max 250 words)',
      'kn': '',
    },
    'd4yoolwq': {
      'en': 'Start Date',
      'kn': '',
    },
    'hidplmd3': {
      'en': '*',
      'kn': '',
    },
    'kozu44c2': {
      'en': 'End Date',
      'kn': '',
    },
    'xs00ngjy': {
      'en': '*',
      'kn': '',
    },
    'gmq1nr88': {
      'en': 'Owner',
      'kn': '',
    },
    '5gv1xxbc': {
      'en': '*',
      'kn': '',
    },
    'hyhv8yux': {
      'en': 'Default',
      'kn': '',
    },
    'kkxw2ilq': {
      'en': 'Default',
      'kn': '',
    },
    's3vf624i': {
      'en': 'Search...',
      'kn': '',
    },
    '8l5c8226': {
      'en': 'Option 1',
      'kn': '',
    },
    'vvtcd6jp': {
      'en': 'Option 2',
      'kn': '',
    },
    'eho3j65r': {
      'en': 'Option 3',
      'kn': '',
    },
    'te2p0vc3': {
      'en': 'Objective Type:',
      'kn': '',
    },
    'u2oano89': {
      'en': 'Private',
      'kn': '',
    },
    'xsc1q9ou': {
      'en': 'Public',
      'kn': '',
    },
    'gui23whf': {
      'en': 'Weightage',
      'kn': '',
    },
    '7hzt5esy': {
      'en': '*',
      'kn': '',
    },
    '75p6yech': {
      'en': 'Enter weightage (1-100)',
      'kn': '',
    },
    'vka9vwje': {
      'en': 'Cancel',
      'kn': '',
    },
    'yu4ixjrf': {
      'en': 'Add Objective',
      'kn': '',
    },
  },
  // adduser
  {
    'spzcaq42': {
      'en': 'Add Employee',
      'kn': '',
    },
    'dmveqh6d': {
      'en': 'Cancel',
      'kn': '',
    },
    'vodjs95t': {
      'en': 'Full Name',
      'kn': '',
    },
    'le32hif5': {
      'en': 'Name',
      'kn': '',
    },
    'f2no7e0y': {
      'en': 'Staff Number',
      'kn': '',
    },
    'm544uoew': {
      'en': 'Enter staff number',
      'kn': '',
    },
    'htvdu8vo': {
      'en': 'Department',
      'kn': '',
    },
    'qen043s4': {
      'en': 'Select Department...',
      'kn': '',
    },
    'xifdrfj9': {
      'en': 'Search...',
      'kn': '',
    },
    'tv13oi2c': {
      'en': 'Option 1',
      'kn': '',
    },
    'uhz3owwo': {
      'en': 'Option 2',
      'kn': '',
    },
    '1cimhz91': {
      'en': 'Option 3',
      'kn': '',
    },
    '4bktaske': {
      'en': 'Position',
      'kn': '',
    },
    'jpn9eirq': {
      'en': 'Select Position...',
      'kn': '',
    },
    'hzmr2ww9': {
      'en': 'Search...',
      'kn': '',
    },
    'cverygve': {
      'en': 'Staff',
      'kn': '',
    },
    'he5c7ola': {
      'en': 'Manager',
      'kn': '',
    },
    '42dnbj6d': {
      'en': 'HR',
      'kn': '',
    },
    'jy0dher5': {
      'en': 'Admin',
      'kn': '',
    },
    'r1hy9bci': {
      'en': 'Phone Number',
      'kn': '',
    },
    '2tyusnul': {
      'en': 'Enter phone number',
      'kn': '',
    },
    'nxw466u9': {
      'en': 'Email ID',
      'kn': '',
    },
    '6yyihmo2': {
      'en': 'Enter email id',
      'kn': '',
    },
    '8pobb7zq': {
      'en': 'Enter email id',
      'kn': '',
    },
    'fkl7x7ve': {
      'en': 'TextField',
      'kn': '',
    },
    'm2hx76r1': {
      'en': 'Nano@2025',
      'kn': '',
    },
    '9p3s3cnm': {
      'en': 'TextField',
      'kn': '',
    },
    'ecizq1lq': {
      'en': 'Nano@2025',
      'kn': '',
    },
    'ji9laepg': {
      'en': 'Activation Status',
      'kn': '',
    },
    'j6xpz1vu': {
      'en': 'Employee can review tasks',
      'kn': '',
    },
    '5gb85bb0': {
      'en': 'Name is required',
      'kn': '',
    },
    'ztpcd79h': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    '7n2pl0hz': {
      'en': 'Field is required',
      'kn': '',
    },
    'aqotuiyl': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'fd2zarl7': {
      'en': 'Field is required',
      'kn': '',
    },
    'rapoe967': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    '5tyta4mc': {
      'en': 'Field is required',
      'kn': '',
    },
    'cb4qufai': {
      'en': 'Email is required',
      'kn': '',
    },
    'gz6w457c': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'pppsdk0t': {
      'en': 'Nano@2025 is required',
      'kn': '',
    },
    '9cjly9x5': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'vzuxffee': {
      'en': 'Nano@2025 is required',
      'kn': '',
    },
    'lqzuwyha': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'hknsh6bj': {
      'en': 'Add Employee',
      'kn': '',
    },
  },
  // Notes
  {
    'hsv64xqs': {
      'en': 'My Notes',
      'kn': '',
    },
    '07p8vryw': {
      'en': 'Note...',
      'kn': '',
    },
  },
  // AddObjectiveCHild
  {
    'gppxv1z8': {
      'en': 'Add New Objective',
      'kn': '',
    },
    'dovpp6hw': {
      'en': 'Objective Name',
      'kn': '',
    },
    'qxb6vho8': {
      'en': '*',
      'kn': '',
    },
    's8tlmb2x': {
      'en': 'Enter objective name (max 100 characters)',
      'kn': '',
    },
    's2utc3va': {
      'en': 'Description',
      'kn': '',
    },
    'sun7hi5h': {
      'en': 'Describe your objective (max 250 words)',
      'kn': '',
    },
    'evxkjv9o': {
      'en': 'Start Date',
      'kn': '',
    },
    '6wy1jdwu': {
      'en': '*',
      'kn': '',
    },
    'sgivbbw5': {
      'en': 'Select Start Date',
      'kn': '',
    },
    '8k4yeg6i': {
      'en': 'End Date',
      'kn': '',
    },
    'm435exs3': {
      'en': '*',
      'kn': '',
    },
    'kjbwej7o': {
      'en': 'Select End Date',
      'kn': '',
    },
    'l6lxxhp1': {
      'en': 'Owner',
      'kn': '',
    },
    'k2n7omly': {
      'en': '*',
      'kn': '',
    },
    'cre51xxu': {
      'en': 'Default',
      'kn': '',
    },
    'y3l3eljs': {
      'en': 'Default',
      'kn': '',
    },
    'l6cst0al': {
      'en': 'Search...',
      'kn': '',
    },
    'pkp1yucp': {
      'en': 'Option 1',
      'kn': '',
    },
    'vm8ck8ut': {
      'en': 'Option 2',
      'kn': '',
    },
    'jrzunau3': {
      'en': 'Option 3',
      'kn': '',
    },
    'u4rqhy3u': {
      'en': 'Objective Type:',
      'kn': '',
    },
    '27r14nl2': {
      'en': 'Private',
      'kn': '',
    },
    'e96wmtsa': {
      'en': 'Public',
      'kn': '',
    },
    'n0z0klhf': {
      'en': 'Weightage',
      'kn': '',
    },
    'hios54fv': {
      'en': '*',
      'kn': '',
    },
    'wu4pawqn': {
      'en': 'Enter weightage (1-100)',
      'kn': '',
    },
    '623ruox7': {
      'en': 'Cancel',
      'kn': '',
    },
    'rdhp6883': {
      'en': 'Add Objective',
      'kn': '',
    },
  },
  // edituser2
  {
    'h1i0x79x': {
      'en': 'Edit Employee',
      'kn': '',
    },
    'u722gl28': {
      'en': 'Full Name',
      'kn': '',
    },
    'sv809pdg': {
      'en': 'Email Address',
      'kn': '',
    },
    'dxxgutwh': {
      'en': 'Enter work email address',
      'kn': '',
    },
    'pxsz79a2': {
      'en': 'Enter work email address',
      'kn': '',
    },
    'tl66kfiw': {
      'en': 'Nano@2025',
      'kn': '',
    },
    'x02sqhgy': {
      'en': 'Enter work email address',
      'kn': '',
    },
    'lqp9s6jm': {
      'en': 'Nano@2025',
      'kn': '',
    },
    'e2po8z8n': {
      'en': 'Phone Number',
      'kn': '',
    },
    'tqyrkfiz': {
      'en': 'Enter contact number',
      'kn': '',
    },
    'iuks3u6k': {
      'en': 'Department',
      'kn': '',
    },
    '5vhx1aoh': {
      'en': 'Select Department',
      'kn': '',
    },
    'dtee08mc': {
      'en': 'Search...',
      'kn': '',
    },
    'ubmc36bz': {
      'en': 'Engineer',
      'kn': '',
    },
    'gjuop9fs': {
      'en': 'Sales',
      'kn': '',
    },
    '43thc4wy': {
      'en': 'Data Entry',
      'kn': '',
    },
    '7306ct03': {
      'en': 'Designation',
      'kn': '',
    },
    'b6rela6c': {
      'en': 'Enter Designation',
      'kn': '',
    },
    'myms70yd': {
      'en': 'Role',
      'kn': '',
    },
    '6lb4o7kb': {
      'en': 'Select Role',
      'kn': '',
    },
    '9vdf7ijn': {
      'en': 'Search...',
      'kn': '',
    },
    'ibxrx03c': {
      'en': 'Admin',
      'kn': '',
    },
    'bkx123ki': {
      'en': 'Manager',
      'kn': '',
    },
    'kzc3tpu0': {
      'en': 'Employee',
      'kn': '',
    },
    '95i7w2uo': {
      'en': 'Activation Status',
      'kn': '',
    },
    'idxyk37w': {
      'en': 'Cancel',
      'kn': '',
    },
    '67ffn6mo': {
      'en': 'Save Changes\n',
      'kn': '',
    },
  },
  // EditEmpCopy
  {
    'kygpqhlc': {
      'en': 'Edit Employee',
      'kn': '',
    },
    'lsta6tla': {
      'en': 'Cancel',
      'kn': '',
    },
    '681iu6by': {
      'en': 'Full Name',
      'kn': '',
    },
    '1paydssr': {
      'en': 'Name',
      'kn': '',
    },
    '10i85u1n': {
      'en': 'Staff Number',
      'kn': '',
    },
    'gf413g6e': {
      'en': 'Staff Number',
      'kn': '',
    },
    'ueweb7md': {
      'en': 'Department',
      'kn': '',
    },
    'zee967ui': {
      'en': 'Select Department...',
      'kn': '',
    },
    'lyusr01x': {
      'en': 'Search...',
      'kn': '',
    },
    'dgnh1ix8': {
      'en': 'Option 1',
      'kn': '',
    },
    '75i32w75': {
      'en': 'Option 2',
      'kn': '',
    },
    'eze764c7': {
      'en': 'Option 3',
      'kn': '',
    },
    'kdy4oyti': {
      'en': 'Position',
      'kn': '',
    },
    'h3bzzi5h': {
      'en': 'Select Position...',
      'kn': '',
    },
    'oyhbci73': {
      'en': 'Search...',
      'kn': '',
    },
    '55vme3ji': {
      'en': 'Staff',
      'kn': '',
    },
    '1uy2gflj': {
      'en': 'Manager',
      'kn': '',
    },
    '5ut8zvpd': {
      'en': 'HR',
      'kn': '',
    },
    'u5zjjl3y': {
      'en': 'Admin',
      'kn': '',
    },
    'qqjr1847': {
      'en': 'Phone Number',
      'kn': '',
    },
    '2nfk1s4u': {
      'en': 'Email ID',
      'kn': '',
    },
    'hy3ze3i9': {
      'en': 'TextField',
      'kn': '',
    },
    'rmlv2w3j': {
      'en': 'Nano@2025',
      'kn': '',
    },
    '88q0ex5q': {
      'en': 'TextField',
      'kn': '',
    },
    '7aqlpis3': {
      'en': 'Nano@2025',
      'kn': '',
    },
    '5qzsgro6': {
      'en': 'Activation Status',
      'kn': '',
    },
    '8xgch4xa': {
      'en': 'Employee can review tasks',
      'kn': '',
    },
    'kum0xiah': {
      'en': 'Name is required',
      'kn': '',
    },
    'bdqnp3bj': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'klcj2emq': {
      'en': 'Field is required',
      'kn': '',
    },
    'uqdpu7se': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'g760jayy': {
      'en': 'Field is required',
      'kn': '',
    },
    'fo09hzhd': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    '0f2k6r6h': {
      'en': 'Field is required',
      'kn': '',
    },
    '8q0e1urk': {
      'en': 'Email is required',
      'kn': '',
    },
    'vwfi7qp0': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'zaifhmwp': {
      'en': 'Nano@2025 is required',
      'kn': '',
    },
    'xq3bgmx2': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'g511q1n9': {
      'en': 'Nano@2025 is required',
      'kn': '',
    },
    'agx03fm0': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'zfeqz783': {
      'en': 'Update Employee',
      'kn': '',
    },
  },
  // EditUserPage
  {
    'dqd5avmr': {
      'en': 'Edit Employee',
      'kn': '',
    },
    'dbymnfjw': {
      'en': 'Cancel',
      'kn': '',
    },
    '4w73tkos': {
      'en': 'Full Name',
      'kn': '',
    },
    'tgs4uyfi': {
      'en': 'Enter name',
      'kn': '',
    },
    'tvulougs': {
      'en': 'Staff Number',
      'kn': '',
    },
    'yr20jkzi': {
      'en': 'Enter staff number',
      'kn': '',
    },
    'lgf5by7c': {
      'en': 'Department',
      'kn': '',
    },
    'tapm45xz': {
      'en': 'Software',
      'kn': '',
    },
    '4t2qan58': {
      'en': 'Marketing',
      'kn': '',
    },
    '5yi51085': {
      'en': 'HR',
      'kn': '',
    },
    'n4megdig': {
      'en': 'Sales',
      'kn': '',
    },
    'rpougciv': {
      'en': 'Position',
      'kn': '',
    },
    'ciupkh2a': {
      'en': 'Manager',
      'kn': '',
    },
    'l9xry5y4': {
      'en': 'Admin',
      'kn': '',
    },
    'xe03i2cg': {
      'en': 'HR',
      'kn': '',
    },
    'cqd3tbn8': {
      'en': 'Staff',
      'kn': '',
    },
    'q5vj45l1': {
      'en': 'Phone Number',
      'kn': '',
    },
    'xxx3em6x': {
      'en': 'Enter phone number',
      'kn': '',
    },
    'f7pps8uc': {
      'en': 'Email ID',
      'kn': '',
    },
    '5abyedvz': {
      'en': 'Enter email',
      'kn': '',
    },
    '0x543edr': {
      'en': 'Activation Status',
      'kn': '',
    },
    '0jp14tgr': {
      'en': 'Employee can review tasks',
      'kn': '',
    },
    'u3kfxep5': {
      'en': 'Update Employee',
      'kn': '',
    },
  },
  // AddUserPage
  {
    '3tci68k2': {
      'en': 'Add Employee',
      'kn': '',
    },
    'g7knkfuf': {
      'en': 'Cancel',
      'kn': '',
    },
    'l9l8on84': {
      'en': 'Full Name',
      'kn': '',
    },
    'hb9530go': {
      'en': 'Enter name',
      'kn': '',
    },
    'mbijlocl': {
      'en': 'Staff Number',
      'kn': '',
    },
    'fbay4q7b': {
      'en': 'Enter staff number',
      'kn': '',
    },
    '081os71h': {
      'en': 'Department',
      'kn': '',
    },
    'kb3m0swb': {
      'en': 'Select Department...',
      'kn': '',
    },
    'o93gdxbd': {
      'en': 'Software',
      'kn': '',
    },
    'ibam94hw': {
      'en': 'Sales',
      'kn': '',
    },
    'tndguf21': {
      'en': 'Marketing',
      'kn': '',
    },
    '605eyzqf': {
      'en': 'HR',
      'kn': '',
    },
    'uysjdoiw': {
      'en': 'Position',
      'kn': '',
    },
    'wymsc876': {
      'en': 'Select Position...',
      'kn': '',
    },
    'o7vkkh0z': {
      'en': 'Admin',
      'kn': '',
    },
    'mltlnf8h': {
      'en': 'Manager',
      'kn': '',
    },
    'ru8ei05q': {
      'en': 'HR',
      'kn': '',
    },
    'ql3sb4di': {
      'en': 'Staff',
      'kn': '',
    },
    'b665p49a': {
      'en': 'Phone Number',
      'kn': '',
    },
    'wvnn2zeb': {
      'en': 'Enter phone number',
      'kn': '',
    },
    'w1akghxg': {
      'en': 'Email ID',
      'kn': '',
    },
    'fu4sx9vb': {
      'en': 'Enter email',
      'kn': '',
    },
    'trznwd88': {
      'en': 'Activation Status',
      'kn': '',
    },
    '7a4lngmp': {
      'en': 'Employee can review tasks',
      'kn': '',
    },
    'lw56ddzz': {
      'en': 'Enter Pass',
      'kn': '',
    },
    'bnsxw6w7': {
      'en': 'Nano@2025',
      'kn': '',
    },
    '7zn7o3io': {
      'en': 'Add User',
      'kn': '',
    },
    'c1u1czn6': {
      'en': 'Enter name is required',
      'kn': '',
    },
    'v35at55k': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'xkuc1t3k': {
      'en': 'Enter staff number is required',
      'kn': '',
    },
    'c35sehaw': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    '56aj3s1o': {
      'en': 'Enter phone number is required',
      'kn': '',
    },
    'rgpk4a3q': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    '9egujp1i': {
      'en': 'Enter email is required',
      'kn': '',
    },
    'j05jkyqz': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'bkrlifzy': {
      'en': 'Nano@2025 is required',
      'kn': '',
    },
    'cawjdory': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
  },
  // createPublicTask
  {
    'yuzksopk': {
      'en': 'Add Task',
      'kn': '',
    },
    'g6blvg3q': {
      'en': 'Task Title',
      'kn': '',
    },
    '2num741n': {
      'en': 'Description',
      'kn': '',
    },
    'qen0j1vq': {
      'en': 'Assigned To',
      'kn': '',
    },
    'zzobvsbw': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    'rjjqloyy': {
      'en': 'Search...',
      'kn': '',
    },
    '4ov7byhz': {
      'en': 'Option 1',
      'kn': '',
    },
    'j2fu5s0n': {
      'en': 'Option 2',
      'kn': '',
    },
    'x4sw591b': {
      'en': 'Option 3',
      'kn': '',
    },
    '70sjezv9': {
      'en': 'Priority',
      'kn': '',
    },
    'fax3ptsw': {
      'en': 'Select the Priority of the task',
      'kn': '',
    },
    '7qyodbki': {
      'en': 'Search...',
      'kn': '',
    },
    '481ffp1f': {
      'en': 'Urgent',
      'kn': '',
    },
    'u5aiwxqe': {
      'en': 'Important',
      'kn': '',
    },
    '23d9bo3f': {
      'en': 'Immediate',
      'kn': '',
    },
    '66zoursf': {
      'en': 'Attach Document',
      'kn': '',
    },
    'sd97d4bf': {
      'en': 'Due Date',
      'kn': '',
    },
    'gpaqilga': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // googleintegration
  {
    'ho3if92l': {
      'en': 'Schedule Task',
      'kn': '',
    },
    'llxxqc1s': {
      'en': 'Task Title',
      'kn': '',
    },
    'c6p6js8q': {
      'en': 'Enter task title',
      'kn': '',
    },
    'k7hty83t': {
      'en': 'Task Description',
      'kn': '',
    },
    '4ajknde9': {
      'en': 'Enter task description',
      'kn': '',
    },
    'e56u2nt9': {
      'en': 'Start Date',
      'kn': '',
    },
    '1pi26gaq': {
      'en': 'End Date',
      'kn': '',
    },
    'vta1i0jq': {
      'en': 'Schedule Task',
      'kn': '',
    },
  },
  // TaskUpdateCopy
  {
    '977m8wtv': {
      'en': 'Update Task Status',
      'kn': '',
    },
    's2w4rh9y': {
      'en': 'Select the current status of your task',
      'kn': '',
    },
    'hofr9lm6': {
      'en': 'Not Started',
      'kn': '',
    },
    '2xbdet9g': {
      'en': 'In Progress',
      'kn': '',
    },
    'b1zh0ito': {
      'en': 'Completed',
      'kn': '',
    },
    'ug8xpfp4': {
      'en': 'Update Status',
      'kn': '',
    },
  },
  // editObjective1
  {
    'ohtcwb8k': {
      'en': 'Add Objective',
      'kn': '',
    },
    'k7otitxe': {
      'en': 'Objective Name',
      'kn': '',
    },
    'mf1mejfw': {
      'en': 'Description',
      'kn': '',
    },
    'v1rf35s4': {
      'en': 'Select Start Date',
      'kn': '',
    },
    '9zt5u6jj': {
      'en': 'Select End Date',
      'kn': '',
    },
    'nnfpwss0': {
      'en': 'Type',
      'kn': '',
    },
    'aknngdqc': {
      'en': 'Public',
      'kn': '',
    },
    'esoaywhk': {
      'en': 'Private',
      'kn': '',
    },
    'mj9qtw02': {
      'en': 'Owner',
      'kn': '',
    },
    'onnjcdw0': {
      'en': 'Default',
      'kn': '',
    },
    '95yjynyw': {
      'en': 'Search...',
      'kn': '',
    },
    '7t7btyqd': {
      'en': 'Option 1',
      'kn': '',
    },
    'vmo6cxuj': {
      'en': 'Option 2',
      'kn': '',
    },
    'l0e8rgfa': {
      'en': 'Option 3',
      'kn': '',
    },
    '4n6kz2to': {
      'en': 'Weightage',
      'kn': '',
    },
    '9z0bdh56': {
      'en': 'Enter the weightage',
      'kn': '',
    },
    'awqidxzi': {
      'en': 'Create Objective',
      'kn': '',
    },
  },
  // updatepass
  {
    'txznkwgj': {
      'en': 'Update Password',
      'kn': '',
    },
    'z89afmi8': {
      'en': 'Current Password',
      'kn': '',
    },
    'rtspt3pn': {
      'en': 'New Password',
      'kn': '',
    },
    'z17gulvr': {
      'en': 'Confirm New Password',
      'kn': '',
    },
    '7sjjs9xn': {
      'en': 'Update Password',
      'kn': '',
    },
  },
  // Editsubobj
  {
    'uabe6bqe': {
      'en': 'Edit Objective',
      'kn': '',
    },
    'i48m4vgx': {
      'en': 'Title',
      'kn': '',
    },
    'wo5uvti7': {
      'en': 'Enter objective title',
      'kn': '',
    },
    'wikw3a4x': {
      'en': 'Description',
      'kn': '',
    },
    'hby476v8': {
      'en': 'Enter objective description',
      'kn': '',
    },
    'n5rztdy0': {
      'en': 'Owner',
      'kn': '',
    },
    'y74kyt9b': {
      'en': 'Default',
      'kn': '',
    },
    '0hsw32mu': {
      'en': 'Search...',
      'kn': '',
    },
    '3lcfnenh': {
      'en': 'Option 1',
      'kn': '',
    },
    'cbfcph5b': {
      'en': 'Option 2',
      'kn': '',
    },
    '2k8vdeag': {
      'en': 'Option 3',
      'kn': '',
    },
    'sjpci7jk': {
      'en': 'Start Date',
      'kn': '',
    },
    'uvdei48r': {
      'en': 'End Date',
      'kn': '',
    },
    '9fabdu7g': {
      'en': 'Type',
      'kn': '',
    },
    'fecqydbr': {
      'en': 'Public',
      'kn': '',
    },
    'qrwdioz9': {
      'en': 'Private',
      'kn': '',
    },
    'fcrxxejt': {
      'en': 'Weightage',
      'kn': '',
    },
    'rh0mheb8': {
      'en': 'Enter objective title',
      'kn': '',
    },
    '7rv6tax1': {
      'en': 'Save Changes',
      'kn': '',
    },
  },
  // notesog
  {
    '1ovrej8v': {
      'en': 'My Notes',
      'kn': '',
    },
    'euollp3b': {
      'en': 'Add a note...',
      'kn': '',
    },
  },
  // edittaskogg
  {
    'yxiu866l': {
      'en': '-Update Task-',
      'kn': '',
    },
    'x05g6s7g': {
      'en': 'Task Title',
      'kn': '',
    },
    '2lovcads': {
      'en': 'Description',
      'kn': '',
    },
    'zzmoev8u': {
      'en': 'Attach Document',
      'kn': '',
    },
    'iuc8jpmv': {
      'en': 'Assigne To :',
      'kn': '',
    },
    'z62q7v0d': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    'cgh5gagc': {
      'en': 'Search...',
      'kn': '',
    },
    '5uaf0bqv': {
      'en': 'Option 1',
      'kn': '',
    },
    '7kkckmvt': {
      'en': 'Option 2',
      'kn': '',
    },
    'dfpj7ctu': {
      'en': 'Option 3',
      'kn': '',
    },
    '3ki7y5qz': {
      'en': 'Priority',
      'kn': '',
    },
    'nq1as2mt': {
      'en': 'Immediate',
      'kn': '',
    },
    '5baykvhd': {
      'en': 'Urgent',
      'kn': '',
    },
    '9ynd7nam': {
      'en': 'Important',
      'kn': '',
    },
    'k0pf1bo5': {
      'en': 'Reviewable',
      'kn': '',
    },
    '19a11ajx': {
      'en': 'Repetative',
      'kn': '',
    },
    'vlb3fd7n': {
      'en': 'Daily',
      'kn': '',
    },
    '0m8xafx5': {
      'en': 'Weekly',
      'kn': '',
    },
    'n8jn3iln': {
      'en': 'Monthly',
      'kn': '',
    },
    'ae5ocdda': {
      'en': 'Half Yearly',
      'kn': '',
    },
    'zv5onchc': {
      'en': 'Reviewer',
      'kn': '',
    },
    'viua5lhl': {
      'en': 'Search...',
      'kn': '',
    },
    'oqch1eet': {
      'en': 'Option 1',
      'kn': '',
    },
    '19y7a0gv': {
      'en': 'Option 2',
      'kn': '',
    },
    '54xdwnix': {
      'en': 'Option 3',
      'kn': '',
    },
    '4kqekpuu': {
      'en': 'Select End Rep Date',
      'kn': '',
    },
    'zysaxqxl': {
      'en': 'Update Task',
      'kn': '',
    },
  },
  // options
  {
    'your900g': {
      'en': 'Cancel',
      'kn': '',
    },
    'duwgl9i0': {
      'en': 'Text',
      'kn': '',
    },
    '0mbjcoul': {
      'en': 'Voice',
      'kn': '',
    },
    'ayehof2r': {
      'en': 'Image',
      'kn': '',
    },
    'yh6pf6zq': {
      'en': 'Video',
      'kn': '',
    },
    're6xbkzv': {
      'en': 'Scribble',
      'kn': '',
    },
  },
  // Scribble
  {
    'ise99mkb': {
      'en': 'New Jam Entry',
      'kn': '',
    },
    '45whkci8': {
      'en': 'Note (Optional)',
      'kn': '',
    },
    '0utdihb6': {
      'en': 'Add a note to your jam entry...',
      'kn': '',
    },
    'nmve06k9': {
      'en': 'Save Entry',
      'kn': '',
    },
  },
  // Jamusing
  {
    '3yo61s1b': {
      'en': 'Create New Jam',
      'kn': '',
    },
    'el4rphsu': {
      'en': 'Image Upload',
      'kn': '',
    },
    'bun84jdf': {
      'en': 'Choose Image',
      'kn': '',
    },
    'ekd8dqwq': {
      'en': 'Add a note about this image...',
      'kn': '',
    },
    '7k0actl6': {
      'en': 'Voice Recording',
      'kn': '',
    },
    'lwaiuff2': {
      'en': 'Add a note about this recording...',
      'kn': '',
    },
    '32ys92ee': {
      'en': 'Text Note',
      'kn': '',
    },
    'eerclnd1': {
      'en': 'Type your note here...',
      'kn': '',
    },
    'uax4aufr': {
      'en': 'Save Jam',
      'kn': '',
    },
  },
  // createTaskNewCopy2
  {
    'nv01qzkb': {
      'en': 'Add Task',
      'kn': '',
    },
    '4axusxu9': {
      'en': 'Task Title',
      'kn': '',
    },
    'w5x8cxy3': {
      'en': 'Description',
      'kn': '',
    },
    '2arpjqtj': {
      'en': 'Select Due Date',
      'kn': '',
    },
    'xt15gpgc': {
      'en': 'Attach Document',
      'kn': '',
    },
    'f6ri46o1': {
      'en': 'Assigne To :',
      'kn': '',
    },
    'je52kvo8': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    'iottips9': {
      'en': 'Search...',
      'kn': '',
    },
    'ywpamm2l': {
      'en': 'Option 1',
      'kn': '',
    },
    'bchcuyic': {
      'en': 'Option 2',
      'kn': '',
    },
    'b5mc6oeg': {
      'en': 'Option 3',
      'kn': '',
    },
    '9mupp9s2': {
      'en': 'Priority',
      'kn': '',
    },
    'rapm180v': {
      'en': 'Immediate',
      'kn': '',
    },
    'szplwl8d': {
      'en': 'Urgent',
      'kn': '',
    },
    'v6jyzj0z': {
      'en': 'Important',
      'kn': '',
    },
    '0v1hoi3b': {
      'en': 'Immediate',
      'kn': '',
    },
    'ckl4ohhf': {
      'en': 'Reviewable',
      'kn': '',
    },
    'oyjes64v': {
      'en': 'Repetative',
      'kn': '',
    },
    'wfhwvf1l': {
      'en': 'Daily',
      'kn': '',
    },
    '584z4j2i': {
      'en': 'Weekly',
      'kn': '',
    },
    '8tdl08tx': {
      'en': 'Monthly',
      'kn': '',
    },
    'xakjmrgg': {
      'en': 'Half Yearly',
      'kn': '',
    },
    '0kaahw9r': {
      'en': 'Reviewer',
      'kn': '',
    },
    'c9pfg9d7': {
      'en': 'Search...',
      'kn': '',
    },
    'ws0ywv54': {
      'en': 'Option 1',
      'kn': '',
    },
    '0b3nz5ez': {
      'en': 'Option 2',
      'kn': '',
    },
    'yd7q1ztw': {
      'en': 'Option 3',
      'kn': '',
    },
    'ftiw05j7': {
      'en': 'Field is required',
      'kn': '',
    },
    '9urh4jje': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'iwynkz14': {
      'en': 'Field is required',
      'kn': '',
    },
    'o2fbdjxz': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'qnaxd3u3': {
      'en': 'Select End Rep Date',
      'kn': '',
    },
    'c5newctd': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // taskPublic
  {
    'rhr62yia': {
      'en': 'Add Task',
      'kn': '',
    },
    'jp6jybgq': {
      'en': 'Task Title',
      'kn': '',
    },
    'xm24fcmu': {
      'en': 'Description',
      'kn': '',
    },
    'gh5ucgya': {
      'en': 'Select Due Date',
      'kn': '',
    },
    'uco572it': {
      'en': 'Attach Document',
      'kn': '',
    },
    'o2jk0li6': {
      'en': 'Priority :',
      'kn': '',
    },
    '1bjvpelu': {
      'en': 'Immediate',
      'kn': '',
    },
    'niqw064o': {
      'en': 'Urgent',
      'kn': '',
    },
    'ijyg4312': {
      'en': 'Important',
      'kn': '',
    },
    '1g073kje': {
      'en': 'Immediate',
      'kn': '',
    },
    '7ptipapq': {
      'en': 'Reviewable',
      'kn': '',
    },
    'sgmfrnkj': {
      'en': 'Repetative',
      'kn': '',
    },
    'if1b5unq': {
      'en': 'Daily',
      'kn': '',
    },
    '8bpferfn': {
      'en': 'Weekly',
      'kn': '',
    },
    '31hj8fvp': {
      'en': 'Monthly',
      'kn': '',
    },
    'fs540w1x': {
      'en': 'Half Yearly',
      'kn': '',
    },
    'ljbhgfa7': {
      'en': 'Reviewer',
      'kn': '',
    },
    'mj1pkzm0': {
      'en': 'Search...',
      'kn': '',
    },
    's7bdsae7': {
      'en': 'Option 1',
      'kn': '',
    },
    'j8ngpexd': {
      'en': 'Option 2',
      'kn': '',
    },
    'yptd9g78': {
      'en': 'Option 3',
      'kn': '',
    },
    '7faxudf7': {
      'en': 'Field is required',
      'kn': '',
    },
    'tt8j5rbm': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    '49h6rtds': {
      'en': 'Field is required',
      'kn': '',
    },
    'a8vcjo3r': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'i2yv0kkw': {
      'en': 'Select End Rep Date',
      'kn': '',
    },
    '8k8llzb6': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // Voice
  {
    '4979w9se': {
      'en': 'New Jam Entry',
      'kn': '',
    },
    'dxjzbtnz': {
      'en': 'Voice Recording',
      'kn': '',
    },
    'vfae7xja': {
      'en': 'Note (Optional)',
      'kn': '',
    },
    'fgoepuul': {
      'en': 'Add a note to your jam entry...',
      'kn': '',
    },
    'bls6wxdz': {
      'en': 'Save Entry',
      'kn': '',
    },
  },
  // uploadimage
  {
    'n118pf6t': {
      'en': 'New Jam Entry',
      'kn': '',
    },
    'r9h7frjz': {
      'en': 'Image Upload',
      'kn': '',
    },
    '4afvqi3d': {
      'en': 'Choose Image',
      'kn': '',
    },
    'ofwwwdth': {
      'en': 'Note (Optional)',
      'kn': '',
    },
    '245j6fer': {
      'en': 'Add a note to your jam entry...',
      'kn': '',
    },
    'hktspcb3': {
      'en': 'Save Entry',
      'kn': '',
    },
  },
  // textJam
  {
    'h5dblas4': {
      'en': 'New Jam Entry',
      'kn': '',
    },
    '0p4ghtv9': {
      'en': 'Note ',
      'kn': '',
    },
    'a1n2rf9o': {
      'en': 'Add a note to your jam entry...',
      'kn': '',
    },
    'unwy6448': {
      'en': 'Save Entry',
      'kn': '',
    },
  },
  // textProf
  {
    '59s4qsdn': {
      'en': 'New Jam Entry',
      'kn': '',
    },
    'n1a57rjt': {
      'en': 'Note ',
      'kn': '',
    },
    'i865g7c0': {
      'en': 'Add Task',
      'kn': '',
    },
  },
  // imageProf
  {
    '3bf4z9ue': {
      'en': 'New Jam Entry',
      'kn': '',
    },
    'qyz6i9jr': {
      'en': 'Image Upload',
      'kn': '',
    },
    'd4r8h7i5': {
      'en': 'Note ',
      'kn': '',
    },
    'dpv62es1': {
      'en': 'Save Entry',
      'kn': '',
    },
  },
  // VoiceProf
  {
    '4nzumwhq': {
      'en': 'New Jam Entry',
      'kn': '',
    },
    'hj1idfw9': {
      'en': 'Voice Recording',
      'kn': '',
    },
    'br16qhmy': {
      'en': 'Note (Optional)',
      'kn': '',
    },
    'ixkgoyli': {
      'en': 'Add Task',
      'kn': '',
    },
  },
  // taskassigneechatphone
  {
    'j6jpl2n8': {
      'en': 'Comments',
      'kn': '',
    },
    'dhpwhloj': {
      'en': 'Attachment',
      'kn': '',
    },
    'e4cr3eh8': {
      'en': 'Type a comment or attach a document....',
      'kn': '',
    },
  },
  // forgotpass
  {
    'ijn13rc5': {
      'en': 'Reset Password',
      'kn': '',
    },
    '080bt8ec': {
      'en':
          'Enter the email associated with your account and we\'ll send you instructions to reset your password.',
      'kn': '',
    },
    '3qqx4h9w': {
      'en': 'Email Address',
      'kn': '',
    },
    'f20q2rxm': {
      'en': 'Enter your email...',
      'kn': '',
    },
    'q7pfwdx1': {
      'en': 'Reset',
      'kn': '',
    },
    'g6ea9v58': {
      'en': 'Remember your password? ',
      'kn': '',
    },
    '7caq3b7q': {
      'en': 'Sign In',
      'kn': '',
    },
  },
  // addOBJCopy
  {
    'ntqryb55': {
      'en': 'Add Objective',
      'kn': '',
    },
    'wooc1nxb': {
      'en': 'Objective Name',
      'kn': '',
    },
    'a01hpvsv': {
      'en': 'Description',
      'kn': '',
    },
    'uw4swujr': {
      'en': 'Select Start Date',
      'kn': '',
    },
    'wkx4uyhx': {
      'en': 'Select End Date',
      'kn': '',
    },
    'epi44csd': {
      'en': 'Type',
      'kn': '',
    },
    '6c9gln35': {
      'en': 'Private',
      'kn': '',
    },
    'pmb1emmw': {
      'en': 'Public',
      'kn': '',
    },
    '1c18xt4n': {
      'en': 'Private',
      'kn': '',
    },
    '5424jnlo': {
      'en': 'Owner',
      'kn': '',
    },
    'rsg3qb9p': {
      'en': 'Default',
      'kn': '',
    },
    '2m1hdg5f': {
      'en': 'Default',
      'kn': '',
    },
    'g1xprym3': {
      'en': 'Search...',
      'kn': '',
    },
    'bxnlis5p': {
      'en': 'Option 1',
      'kn': '',
    },
    'qocjzft1': {
      'en': 'Option 2',
      'kn': '',
    },
    '7sruxgdj': {
      'en': 'Option 3',
      'kn': '',
    },
    '2ieehv8n': {
      'en': 'Weightage',
      'kn': '',
    },
    '7ahexb9i': {
      'en': 'Enter the weightage',
      'kn': '',
    },
    '3rtdsn82': {
      'en': 'Create Objective',
      'kn': '',
    },
  },
  // uploadvideo
  {
    '17k4yyei': {
      'en': 'New Jam Entry',
      'kn': '',
    },
    'qjkelxnt': {
      'en': 'Video Upload',
      'kn': '',
    },
    'igpvvojn': {
      'en': 'Record Video',
      'kn': '',
    },
    '6b6eql7y': {
      'en': 'Note (Optional)',
      'kn': '',
    },
    'mmjm6v4g': {
      'en': 'Add a note to your jam entry...',
      'kn': '',
    },
    '1vlxrxnz': {
      'en': 'Save Entry',
      'kn': '',
    },
  },
  // videoProf
  {
    'k9kcw318': {
      'en': 'New Jam Entry',
      'kn': '',
    },
    'zstgefk5': {
      'en': 'Video Upload',
      'kn': '',
    },
    'tcql6trj': {
      'en': 'Note ',
      'kn': '',
    },
    '44rlq9bs': {
      'en': 'Tag jam to Task: ',
      'kn': '',
    },
    'mxuci3j9': {
      'en': 'Use jam content: ',
      'kn': '',
    },
    '3c6y1ogn': {
      'en': 'Save Entry',
      'kn': '',
    },
  },
  // addOBJMain
  {
    '3jz471uc': {
      'en': 'Add Objective',
      'kn': '',
    },
    'yqpwidi0': {
      'en': 'Objective Title',
      'kn': '',
    },
    'w0ycyxsc': {
      'en': 'Description',
      'kn': '',
    },
    'vd1jp0ak': {
      'en': 'Has a Parent Objective:',
      'kn': '',
    },
    'nke5f5wm': {
      'en': 'Select parent objective',
      'kn': '',
    },
    'rluc58oj': {
      'en': 'Search...',
      'kn': '',
    },
    'slzhqmzs': {
      'en': 'Option 1',
      'kn': '',
    },
    'zqkl0hf0': {
      'en': 'Option 2',
      'kn': '',
    },
    'xoeqp5rd': {
      'en': 'Option 3',
      'kn': '',
    },
    'gpiuqj70': {
      'en': 'Select Start Date',
      'kn': '',
    },
    'knx7tl10': {
      'en': 'Select End Date',
      'kn': '',
    },
    '4c9t2kr5': {
      'en': 'Type',
      'kn': '',
    },
    'bwys9px1': {
      'en': 'Private',
      'kn': '',
    },
    'i0mxejtf': {
      'en': 'Public',
      'kn': '',
    },
    'p6l7bxks': {
      'en': 'Private',
      'kn': '',
    },
    'i0a6w4jy': {
      'en': 'Owner',
      'kn': '',
    },
    'kyst9iin': {
      'en': 'Search...',
      'kn': '',
    },
    'wpr11scp': {
      'en': 'Option 1',
      'kn': '',
    },
    'e5qs89k8': {
      'en': 'Option 2',
      'kn': '',
    },
    'ozo4bc11': {
      'en': 'Option 3',
      'kn': '',
    },
    'dlzdo506': {
      'en': 'Weightage',
      'kn': '',
    },
    'w9nfp3mx': {
      'en': 'Enter the weightage',
      'kn': '',
    },
    '3gpuzvkg': {
      'en': 'Objective Title is required',
      'kn': '',
    },
    '8wrehus3': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'wznk0djh': {
      'en': 'Description is required',
      'kn': '',
    },
    'xyg52bsk': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    '058xbbkb': {
      'en': 'Enter the weightage is required',
      'kn': '',
    },
    'qam7vrup': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    '2j4grb4b': {
      'en': 'Create Objective',
      'kn': '',
    },
  },
  // createTaskNewMain
  {
    'uzihevio': {
      'en': 'Add Task',
      'kn': '',
    },
    'ik2wtsdv': {
      'en': 'Task Title',
      'kn': '',
    },
    '53o5uqqs': {
      'en': 'Description',
      'kn': '',
    },
    'bkma8vqb': {
      'en': 'Select Due Date',
      'kn': '',
    },
    '8nao47gu': {
      'en': 'Attach Document',
      'kn': '',
    },
    'hy6l5l8g': {
      'en': 'Objective :',
      'kn': '',
    },
    '1zgf7u96': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    'ej75h0qu': {
      'en': 'Search...',
      'kn': '',
    },
    'na17266h': {
      'en': 'Option 1',
      'kn': '',
    },
    'nopgmgf8': {
      'en': 'Option 2',
      'kn': '',
    },
    '3ts2vjv7': {
      'en': 'Option 3',
      'kn': '',
    },
    'gen4gdy4': {
      'en': 'Assigne To :',
      'kn': '',
    },
    'feqspezx': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    'nbob4h40': {
      'en': 'Search...',
      'kn': '',
    },
    'b3k3lt19': {
      'en': 'Option 1',
      'kn': '',
    },
    '91nmnvuy': {
      'en': 'Option 2',
      'kn': '',
    },
    'sa2cuzfw': {
      'en': 'Option 3',
      'kn': '',
    },
    'drhz9xb3': {
      'en': 'Reviewable :',
      'kn': '',
    },
    'afo71pk0': {
      'en': 'Reviewer',
      'kn': '',
    },
    'atcvf4qk': {
      'en': 'Search...',
      'kn': '',
    },
    '9klfrzsz': {
      'en': 'Option 1',
      'kn': '',
    },
    '867sl65w': {
      'en': 'Option 2',
      'kn': '',
    },
    'jb5iqfkk': {
      'en': 'Option 3',
      'kn': '',
    },
    '7felcitq': {
      'en': 'Priority :',
      'kn': '',
    },
    '53uzm4d4': {
      'en': 'Immediate',
      'kn': '',
    },
    '79s6zhbt': {
      'en': 'Urgent',
      'kn': '',
    },
    'gn4xkw9x': {
      'en': 'Important',
      'kn': '',
    },
    '59oska9z': {
      'en': 'Immediate',
      'kn': '',
    },
    '0nnp6qpt': {
      'en': 'Repetative',
      'kn': '',
    },
    'g3syei9m': {
      'en': 'Daily',
      'kn': '',
    },
    '6vbv4enn': {
      'en': 'Weekly',
      'kn': '',
    },
    '68u3qkil': {
      'en': 'Monthly',
      'kn': '',
    },
    '570wsfnj': {
      'en': 'Half Yearly',
      'kn': '',
    },
    'n7d9psqj': {
      'en': 'Field is required',
      'kn': '',
    },
    'g3tx0v2d': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    's39h0gub': {
      'en': 'Field is required',
      'kn': '',
    },
    'v6viv2gv': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'q9b4mfmv': {
      'en': 'Select End Rep Date',
      'kn': '',
    },
    'uojevtk7': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // DEACTIVATE
  {
    'n037w76g': {
      'en': 'Are you sure you want to deactivate this objective?',
      'kn': '',
    },
    'ugvgjzxd': {
      'en':
          'This action cannot be undone. The objective will be marked as inactive and removed from active tracking.',
      'kn': '',
    },
    'emxwsocc': {
      'en': 'Cancel',
      'kn': '',
    },
    'cfm6dz82': {
      'en': 'Deactivate',
      'kn': '',
    },
  },
  // chooseOBJ
  {
    '622qv7ck': {
      'en': 'Select Objetive to Add Task',
      'kn': '',
    },
    'v3pzpvxx': {
      'en': 'Department :',
      'kn': '',
    },
    'tztziwnn': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    '0ah6w9wt': {
      'en': 'Search...',
      'kn': '',
    },
    '7p0rk5rz': {
      'en': 'Software',
      'kn': '',
    },
    'mvynf1k4': {
      'en': 'Sales',
      'kn': '',
    },
    '6hmf0be4': {
      'en': 'HR',
      'kn': '',
    },
    '9wi6536l': {
      'en': 'Marketing',
      'kn': '',
    },
    'afernwef': {
      'en': 'Person :',
      'kn': '',
    },
    '2yjec00x': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    '2vpp27uc': {
      'en': 'Search...',
      'kn': '',
    },
    'qqke73rx': {
      'en': 'Option 1',
      'kn': '',
    },
    'z6bzq69l': {
      'en': 'Option 2',
      'kn': '',
    },
    'e8856no7': {
      'en': 'Option 3',
      'kn': '',
    },
    'j4ymi26b': {
      'en': 'Objetive :',
      'kn': '',
    },
    'zf36elqk': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    'zgqzc65m': {
      'en': 'Search...',
      'kn': '',
    },
    'auq8jy1b': {
      'en': 'Option 1',
      'kn': '',
    },
    '3h08mgbw': {
      'en': 'Option 2',
      'kn': '',
    },
    '4aaiu9pz': {
      'en': 'Option 3',
      'kn': '',
    },
    'meeu0285': {
      'en': 'Repetative',
      'kn': '',
    },
    'dpbdf3ha': {
      'en': 'Daily',
      'kn': '',
    },
    'lc60rx3d': {
      'en': 'Weekly',
      'kn': '',
    },
    '7o7rte2e': {
      'en': 'Monthly',
      'kn': '',
    },
    '90gk5kai': {
      'en': 'Half Yearly',
      'kn': '',
    },
    'p0bb1dhp': {
      'en': 'Field is required',
      'kn': '',
    },
    'ipquwxd7': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'ojnvl47d': {
      'en': 'Field is required',
      'kn': '',
    },
    '7fufdvxt': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    '7w76ns7o': {
      'en': 'Select End Rep Date',
      'kn': '',
    },
    'cnu70dbq': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // tasknewcreateChoices
  {
    'y5fvtyl4': {
      'en': 'Task Creation Options',
      'kn': '',
    },
    'apb2etch': {
      'en': 'Select Task Type',
      'kn': '',
    },
    'l70n9svi': {
      'en': 'Objective Based',
      'kn': '',
    },
    'oxeen0qr': {
      'en': 'Department/Person Based',
      'kn': '',
    },
    'uspht7bj': {
      'en': 'Objective Based',
      'kn': '',
    },
    '4g3x7yvf': {
      'en': 'Task Details',
      'kn': '',
    },
    '0sgmseql': {
      'en': 'Software',
      'kn': '',
    },
    'qk1vxg6x': {
      'en': 'Select Department',
      'kn': '',
    },
    'yq5ifhf3': {
      'en': 'Search...',
      'kn': '',
    },
    'cgee4ez3': {
      'en': 'Software',
      'kn': '',
    },
    '65038o6r': {
      'en': 'Sales',
      'kn': '',
    },
    'a7500m2r': {
      'en': 'Marketing',
      'kn': '',
    },
    'xem4fm3l': {
      'en': 'HR',
      'kn': '',
    },
    '1gpnbghk': {
      'en': 'Select user',
      'kn': '',
    },
    '4bs7f0fz': {
      'en': 'Search...',
      'kn': '',
    },
    'zt3oyrzr': {
      'en': 'Option 1',
      'kn': '',
    },
    '5gbg69y3': {
      'en': 'Option 2',
      'kn': '',
    },
    'ajonjeo3': {
      'en': 'Option 3',
      'kn': '',
    },
    '448kfqbd': {
      'en': 'Select objective',
      'kn': '',
    },
    'fqjxlpiz': {
      'en': 'Search...',
      'kn': '',
    },
    'fijmoqlq': {
      'en': 'Option 1',
      'kn': '',
    },
    'z2j1igx2': {
      'en': 'Option 2',
      'kn': '',
    },
    'ijqzh0zr': {
      'en': 'Option 3',
      'kn': '',
    },
    '9wrbw0nj': {
      'en': 'Task Details',
      'kn': '',
    },
    'xvlgqjos': {
      'en': 'Select objective',
      'kn': '',
    },
    'zk3px494': {
      'en': 'Search...',
      'kn': '',
    },
    '10uwpl1z': {
      'en': 'Option 1',
      'kn': '',
    },
    '1in6su64': {
      'en': 'Option 2',
      'kn': '',
    },
    '304ihr0x': {
      'en': 'Option 3',
      'kn': '',
    },
    'xzpybeg2': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // createTaskNewMainCopy
  {
    '4f081onf': {
      'en': 'Add Task',
      'kn': '',
    },
    '6wvdu4uq': {
      'en': 'Task Title',
      'kn': '',
    },
    'rcnviw5y': {
      'en': 'Description',
      'kn': '',
    },
    '0skye4xm': {
      'en': 'Select Due Date',
      'kn': '',
    },
    '5oluxxem': {
      'en': 'Attach Document',
      'kn': '',
    },
    '81g16ejw': {
      'en': 'Objective :',
      'kn': '',
    },
    'hls66fw2': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    '0x55pwtw': {
      'en': 'Search...',
      'kn': '',
    },
    'pfjr12m1': {
      'en': 'Option 1',
      'kn': '',
    },
    'jm7euvuo': {
      'en': 'Option 2',
      'kn': '',
    },
    'glg2xcbq': {
      'en': 'Option 3',
      'kn': '',
    },
    'cc8srv3f': {
      'en': 'Assigne To :',
      'kn': '',
    },
    'z7ou6a9o': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    'kd52z3lx': {
      'en': 'Search...',
      'kn': '',
    },
    't7ii0qct': {
      'en': 'Option 1',
      'kn': '',
    },
    '9qt82v3s': {
      'en': 'Option 2',
      'kn': '',
    },
    '13be07mh': {
      'en': 'Option 3',
      'kn': '',
    },
    'm7onxbnw': {
      'en': 'Reviewable :',
      'kn': '',
    },
    'xxcwqefs': {
      'en': 'Reviewer',
      'kn': '',
    },
    '5haggaqm': {
      'en': 'Search...',
      'kn': '',
    },
    'r1ay2y1a': {
      'en': 'Option 1',
      'kn': '',
    },
    '8etocecq': {
      'en': 'Option 2',
      'kn': '',
    },
    'zm3d6jmy': {
      'en': 'Option 3',
      'kn': '',
    },
    '7aec04o0': {
      'en': 'Priority :',
      'kn': '',
    },
    'p0hofmlt': {
      'en': 'Immediate',
      'kn': '',
    },
    '6i79cpuz': {
      'en': 'Urgent',
      'kn': '',
    },
    'v6qiic1g': {
      'en': 'Important',
      'kn': '',
    },
    'y78qmkss': {
      'en': 'Immediate',
      'kn': '',
    },
    'qprbs0pp': {
      'en': 'Repetative',
      'kn': '',
    },
    'a2jwbydp': {
      'en': 'Daily',
      'kn': '',
    },
    'vrybn0pz': {
      'en': 'Weekly',
      'kn': '',
    },
    'i0bygfwf': {
      'en': 'Monthly',
      'kn': '',
    },
    'v0cycz37': {
      'en': 'Half Yearly',
      'kn': '',
    },
    'v1itpgwa': {
      'en': 'Field is required',
      'kn': '',
    },
    'bgpgnd5i': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'dxqac30b': {
      'en': 'Field is required',
      'kn': '',
    },
    '39wsk29n': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'rbae7wqn': {
      'en': 'Select End Rep Date',
      'kn': '',
    },
    '1gnd4xvt': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // createTaskNewCopy3
  {
    '3u010kmu': {
      'en': 'Add Task',
      'kn': '',
    },
    '4nz9n6se': {
      'en': 'Task Title',
      'kn': '',
    },
    '5aey89zi': {
      'en': 'Description',
      'kn': '',
    },
    'aw8abpqh': {
      'en': 'Select Due Date',
      'kn': '',
    },
    'jgj77nm1': {
      'en': 'Attach Document',
      'kn': '',
    },
    'cf2p3i14': {
      'en': 'Assigne To :',
      'kn': '',
    },
    'dx95qu8z': {
      'en': 'Please select who is responsible for the task',
      'kn': '',
    },
    'ij0sgdu0': {
      'en': 'Search...',
      'kn': '',
    },
    '8vnzk825': {
      'en': 'Option 1',
      'kn': '',
    },
    '9964a1mr': {
      'en': 'Option 2',
      'kn': '',
    },
    'ytca0ujn': {
      'en': 'Option 3',
      'kn': '',
    },
    'jxqi2vmb': {
      'en': 'Reviewable :',
      'kn': '',
    },
    '5mxkzhlz': {
      'en': 'Reviewer',
      'kn': '',
    },
    'lkix7123': {
      'en': 'Search...',
      'kn': '',
    },
    'azgyxsyb': {
      'en': 'Option 1',
      'kn': '',
    },
    'kvepv8lg': {
      'en': 'Option 2',
      'kn': '',
    },
    'wk5ifibt': {
      'en': 'Option 3',
      'kn': '',
    },
    '9gag67tw': {
      'en': 'Priority :',
      'kn': '',
    },
    'hyju7msj': {
      'en': 'Immediate',
      'kn': '',
    },
    'mvgvcam3': {
      'en': 'Urgent',
      'kn': '',
    },
    'jn8ekw3k': {
      'en': 'Important',
      'kn': '',
    },
    'ejauye8e': {
      'en': 'Immediate',
      'kn': '',
    },
    'x4lm6gf5': {
      'en': 'Repetative',
      'kn': '',
    },
    '5jswuwss': {
      'en': 'Field is required',
      'kn': '',
    },
    '0wu7rc03': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    '1t8jpr7e': {
      'en': 'Field is required',
      'kn': '',
    },
    'ahtou4j1': {
      'en': 'Please choose an option from the dropdown',
      'kn': '',
    },
    'de7vpwfr': {
      'en': 'Select End Rep Date',
      'kn': '',
    },
    'on7yen5o': {
      'en': 'Create Task',
      'kn': '',
    },
  },
  // Miscellaneous
  {
    'vddbipzp': {
      'en': '',
      'kn': '',
    },
    '246empc9': {
      'en': '',
      'kn': '',
    },
    'lc2syoz2': {
      'en': '',
      'kn': '',
    },
    '9p0dmorh': {
      'en': 'Please Allow us to send you Notification',
      'kn': '',
    },
    's70e3uqf': {
      'en': '',
      'kn': '',
    },
    'xx6ptrki': {
      'en': '',
      'kn': '',
    },
    'azdf74nr': {
      'en': '',
      'kn': '',
    },
    'iiba0f1s': {
      'en': '',
      'kn': '',
    },
    'xz5u1w83': {
      'en': '',
      'kn': '',
    },
    'gq562y4w': {
      'en': '',
      'kn': '',
    },
    '0brutcsx': {
      'en': '',
      'kn': '',
    },
    'xrs85lcr': {
      'en': '',
      'kn': '',
    },
    '42vuuoq0': {
      'en': '',
      'kn': '',
    },
    'rayru1mn': {
      'en': '',
      'kn': '',
    },
    'uyullce9': {
      'en': '',
      'kn': '',
    },
    'djicedno': {
      'en': '',
      'kn': '',
    },
    'dri5enst': {
      'en': '',
      'kn': '',
    },
    '0xyd9m2p': {
      'en': '',
      'kn': '',
    },
    'xy71w1hp': {
      'en': '',
      'kn': '',
    },
    'q18kvnll': {
      'en': '',
      'kn': '',
    },
    '5lhmtg77': {
      'en': '',
      'kn': '',
    },
    'hwkdxiy1': {
      'en': '',
      'kn': '',
    },
    'tfgidhvs': {
      'en': '',
      'kn': '',
    },
    'hl9jq1d5': {
      'en': '',
      'kn': '',
    },
    '4260e3wi': {
      'en': '',
      'kn': '',
    },
    'p6zlmwoq': {
      'en': '',
      'kn': '',
    },
    'ejx8qpwz': {
      'en': '',
      'kn': '',
    },
    'r1pvl4kx': {
      'en': '',
      'kn': '',
    },
    '64vuej7c': {
      'en': '',
      'kn': '',
    },
  },
].reduce((a, b) => a..addAll(b));
